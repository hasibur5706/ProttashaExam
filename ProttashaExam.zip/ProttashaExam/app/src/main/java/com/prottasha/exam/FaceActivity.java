package com.prottasha.exam;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class FaceActivity extends Activity {
    private boolean finished = false;
    private WebView web;

    /* renamed from: com.prottasha.exam.FaceActivity$1, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass1 extends WebChromeClient {
        AnonymousClass1() {
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public static /* synthetic */ void lambda$onPermissionRequest$0(PermissionRequest permissionRequest) {
            permissionRequest.grant(permissionRequest.getResources());
        }

        @Override // android.webkit.WebChromeClient
        public void onPermissionRequest(PermissionRequest permissionRequest) {
            FaceActivity.this.runOnUiThread(new FaceActivity$1$$ExternalSyntheticLambda0(permissionRequest));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public class Bridge {
        public static /* synthetic */ void $r8$lambda$24LmmoeJ3mw1FbiYwfcelWuVVh4(Bridge bridge, String str) {
            bridge.lambda$fail$1(str);
        }

        public static /* synthetic */ void $r8$lambda$jvlPwYCBQjHH1mx_04PWM0jOigg(Bridge bridge) {
            bridge.lambda$cancel$2();
        }

        /* renamed from: $r8$lambda$mRQv3jqm-33LVXLT2OSa-F082Is, reason: not valid java name */
        public static /* synthetic */ void m1$r8$lambda$mRQv3jqm33LVXLT2OSaF082Is(Bridge bridge, String str) {
            bridge.lambda$done$0(str);
        }

        private Bridge() {
        }

        private /* synthetic */ void lambda$cancel$2() {
            FaceActivity.m0$$Nest$mfinishWith(FaceActivity.this, 0, "");
        }

        private /* synthetic */ void lambda$done$0(String str) {
            FaceActivity.m0$$Nest$mfinishWith(FaceActivity.this, -1, str);
        }

        private /* synthetic */ void lambda$fail$1(String str) {
            FaceActivity.m0$$Nest$mfinishWith(FaceActivity.this, 0, str);
        }

        @JavascriptInterface
        public void cancel() {
            FaceActivity.this.runOnUiThread(new FaceActivity$Bridge$$ExternalSyntheticLambda2(this));
        }

        @JavascriptInterface
        public String config() {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("base", Api.base);
                jSONObject.put("token", Api.token == null ? "" : Api.token);
                jSONObject.put("mode", FaceActivity.this.getIntent().getStringExtra("mode"));
                jSONObject.put("examId", FaceActivity.this.getIntent().getIntExtra("exam_id", 0));
                return jSONObject.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void done(String str) {
            FaceActivity.this.runOnUiThread(new FaceActivity$Bridge$$ExternalSyntheticLambda1(this, str));
        }

        @JavascriptInterface
        public void fail(String str) {
            FaceActivity.this.runOnUiThread(new FaceActivity$Bridge$$ExternalSyntheticLambda0(this, str));
        }
    }

    /* renamed from: -$$Nest$mfinishWith, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m0$$Nest$mfinishWith(FaceActivity faceActivity, int i, String str) {
        faceActivity.finishWith(i, str);
    }

    private void finishWith(int i, String str) {
        if (this.finished) {
            return;
        }
        this.finished = true;
        Intent intent = new Intent();
        intent.putExtra("message", str);
        setResult(i, intent);
        finish();
    }

    private void start() {
        try {
            InputStream open = getAssets().open("face.html");
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[4096];
            while (true) {
                int read = open.read(bArr);
                if (read <= 0) {
                    open.close();
                    this.web.loadDataWithBaseURL("https://face.local/", byteArrayOutputStream.toString("UTF-8"), "text/html", "utf-8", null);
                    return;
                }
                byteArrayOutputStream.write(bArr, 0, read);
            }
        } catch (Exception e) {
            finishWith(0, "ফেস স্ক্রিন খোলা যায়নি।");
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.web = new WebView(this);
        setContentView(this.web);
        WebSettings settings = this.web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(0);
        this.web.addJavascriptInterface(new Bridge(), "Android");
        this.web.setWebChromeClient(new AnonymousClass1());
        if (checkSelfPermission("android.permission.CAMERA") == 0) {
            start();
        } else {
            requestPermissions(new String[]{"android.permission.CAMERA"}, 1);
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        if (this.web != null) {
            this.web.loadUrl("about:blank");
            this.web.destroy();
        }
        super.onDestroy();
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (iArr.length <= 0 || iArr[0] != 0) {
            finishWith(0, "ক্যামেরার অনুমতি দেওয়া হয়নি।");
        } else {
            start();
        }
    }
}
