package com.prottasha.exam;

import android.os.Handler;
import android.os.Looper;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Optional fallback: calls Gemini straight from the app when the server has no AI route yet.
 * It only works if a Gemini key was added at build time (GitHub secret GEMINI_API_KEY).
 * A key inside an app can be extracted, so the server route is the safer long-term choice.
 */
final class GeminiDirect {
    interface Done {
        void ok(String text);

        void fail(String message);
    }

    private GeminiDirect() {
    }

    static boolean available() {
        return BuildConfig.GEMINI_API_KEY != null && !BuildConfig.GEMINI_API_KEY.isEmpty();
    }

    static void ask(final String system, final String user, final Done done) {
        final Handler main = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection c = null;
                String text = null;
                String error = null;
                try {
                    URL u = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + BuildConfig.GEMINI_MODEL + ":generateContent");
                    c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(40000);
                    c.setRequestProperty("Content-Type", "application/json");
                    c.setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY);
                    c.setDoOutput(true);
                    JSONObject body = new JSONObject();
                    body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
                    body.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", new JSONArray().put(new JSONObject().put("text", user)))));
                    body.put("generationConfig", new JSONObject().put("maxOutputTokens", 2048).put("temperature", 0.4));
                    OutputStream os = c.getOutputStream();
                    os.write(body.toString().getBytes("UTF-8"));
                    os.close();
                    int code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while (in != null && (n = in.read(buf)) > 0) {
                        bo.write(buf, 0, n);
                    }
                    String raw = bo.toString("UTF-8");
                    if (code >= 400) {
                        error = code == 429 ? "AI-এর ব্যবহারের সীমা শেষ। একটু পরে চেষ্টা করো।" : "AI এখন উত্তর দিতে পারছে না (কোড " + code + ")।";
                    } else {
                        JSONObject data = new JSONObject(raw);
                        if (data.has("promptFeedback") && data.getJSONObject("promptFeedback").has("blockReason")) {
                            error = "এই প্রশ্নের ব্যাখ্যা AI দিতে পারছে না।";
                        } else {
                            JSONArray cands = data.optJSONArray("candidates");
                            StringBuilder sb = new StringBuilder();
                            if (cands != null && cands.length() > 0) {
                                JSONArray parts = cands.getJSONObject(0).getJSONObject("content").optJSONArray("parts");
                                for (int i = 0; parts != null && i < parts.length(); i++) {
                                    JSONObject p = parts.getJSONObject(i);
                                    if (p.has("text") && !p.optBoolean("thought")) {
                                        sb.append(p.getString("text")).append('\n');
                                    }
                                }
                            }
                            text = sb.toString().trim();
                            if (text.isEmpty()) {
                                error = "AI থেকে উত্তর পাওয়া যায়নি।";
                            }
                        }
                    }
                } catch (Exception e) {
                    error = "ইন্টারনেট বা AI সংযোগে সমস্যা হয়েছে।";
                } finally {
                    if (c != null) {
                        c.disconnect();
                    }
                }
                final String ft = text;
                final String fe = error;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (fe != null) {
                            done.fail(fe);
                        } else {
                            done.ok(ft);
                        }
                    }
                });
            }
        }).start();
    }
}
