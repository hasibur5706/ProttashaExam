package com.prottasha.exam;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;
import java.util.Random;

/** Animated background: a soft glow, expanding rings and floating particles. */
final class SplashArt extends View {
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private final float focusY;
    private final boolean strong;
    private final float[] bx;
    private final float[] speed;
    private final float[] offset;
    private final float[] size;
    private final float[] drift;
    private ValueAnimator anim;
    private float t = 0f;

    SplashArt(Context c, boolean strong, float focusY, int particles) {
        super(c);
        this.density = c.getResources().getDisplayMetrics().density;
        this.strong = strong;
        this.focusY = focusY;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(1.5f * density);
        Random r = new Random(11);
        bx = new float[particles];
        speed = new float[particles];
        offset = new float[particles];
        size = new float[particles];
        drift = new float[particles];
        for (int i = 0; i < particles; i++) {
            bx[i] = r.nextFloat();
            speed[i] = 1f + r.nextInt(3);
            offset[i] = r.nextFloat();
            size[i] = 1.2f + r.nextFloat() * 2.6f;
            drift[i] = 6f + r.nextFloat() * 14f;
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(7000);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                t = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        if (w == 0f || h == 0f) {
            return;
        }
        float cx = w / 2f;
        float cy = h * focusY;
        // pulsing glow behind the logo
        float pulse = 0.75f + 0.25f * (float) Math.sin(t * 2d * Math.PI * 2d);
        float gr = (strong ? 190f : 130f) * density;
        int a = (int) ((strong ? 70f : 45f) * pulse);
        glow.setShader(new RadialGradient(cx, cy, gr, (a << 24) | 0xFFB020, 0x00FFB020, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, gr, glow);
        // expanding rings
        for (int k = 0; k < 4; k++) {
            float phase = (t * 2f + k / 4f) % 1f;
            float radius = (strong ? 70f : 50f) * density + phase * (strong ? 250f : 170f) * density;
            int alpha = (int) ((1f - phase) * (strong ? 70f : 38f));
            ring.setColor((alpha << 24) | 0xFFFFFF);
            canvas.drawCircle(cx, cy, radius, ring);
        }
        // floating particles
        for (int i = 0; i < bx.length; i++) {
            float p = (t * speed[i] + offset[i]) % 1f;
            float x = bx[i] * w + (float) Math.sin((t * speed[i] * 2d + offset[i]) * 2d * Math.PI) * drift[i] * density;
            float y = h * (1f - p);
            int alpha = (int) (Math.sin(Math.PI * p) * 150d);
            dot.setColor((alpha << 24) | (i % 3 == 0 ? 0xFFB020 : 0xFFFFFF));
            canvas.drawCircle(x, y, size[i] * density, dot);
        }
    }
}
