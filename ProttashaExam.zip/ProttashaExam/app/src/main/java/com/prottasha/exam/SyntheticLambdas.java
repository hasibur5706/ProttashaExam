package com.prottasha.exam;

import android.content.DialogInterface;
import android.net.Uri;
import android.view.View;
import android.webkit.PermissionRequest;
import android.widget.CheckBox;
import android.widget.EditText;
import com.prottasha.exam.Api;
import com.prottasha.exam.FaceActivity;
import com.prottasha.exam.MainActivity;
import org.json.JSONArray;
import org.json.JSONObject;

// Small click/callback helper classes recovered from the original app.
/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class Api$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ Api.Callback f$0;
    public final /* synthetic */ JSONObject f$1;

    public /* synthetic */ Api$$ExternalSyntheticLambda0(Api.Callback callback, JSONObject jSONObject) {
        this.f$0 = callback;
        this.f$1 = jSONObject;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$send$3(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class Api$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ boolean f$0;
    public final /* synthetic */ Api.Callback f$1;
    public final /* synthetic */ String f$2;
    public final /* synthetic */ String f$3;
    public final /* synthetic */ int f$4;

    public /* synthetic */ Api$$ExternalSyntheticLambda1(boolean z, Api.Callback callback, String str, String str2, int i) {
        this.f$0 = z;
        this.f$1 = callback;
        this.f$2 = str;
        this.f$3 = str2;
        this.f$4 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$send$4(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class Api$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ JSONObject f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ String f$2;
    public final /* synthetic */ Api.Callback f$3;

    public /* synthetic */ Api$$ExternalSyntheticLambda2(JSONObject jSONObject, String str, String str2, Api.Callback callback) {
        this.f$0 = jSONObject;
        this.f$1 = str;
        this.f$2 = str2;
        this.f$3 = callback;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$call$0(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class Api$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ byte[] f$1;
    public final /* synthetic */ String f$2;
    public final /* synthetic */ Api.Callback f$3;

    public /* synthetic */ Api$$ExternalSyntheticLambda3(String str, byte[] bArr, String str2, Api.Callback callback) {
        this.f$0 = str;
        this.f$1 = bArr;
        this.f$2 = str2;
        this.f$3 = callback;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$upload$1(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class Api$$ExternalSyntheticLambda4 implements Runnable {
    public final /* synthetic */ Api.Callback f$0;

    public /* synthetic */ Api$$ExternalSyntheticLambda4(Api.Callback callback) {
        this.f$0 = callback;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$networkError$2(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class FaceActivity$1$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ PermissionRequest f$0;

    public /* synthetic */ FaceActivity$1$$ExternalSyntheticLambda0(PermissionRequest permissionRequest) {
        this.f$0 = permissionRequest;
    }

    @Override // java.lang.Runnable
    public final void run() {
        FaceActivity.AnonymousClass1.lambda$onPermissionRequest$0(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class FaceActivity$Bridge$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ FaceActivity.Bridge f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ FaceActivity$Bridge$$ExternalSyntheticLambda0(FaceActivity.Bridge bridge, String str) {
        this.f$0 = bridge;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        FaceActivity.Bridge.$r8$lambda$24LmmoeJ3mw1FbiYwfcelWuVVh4(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class FaceActivity$Bridge$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ FaceActivity.Bridge f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ FaceActivity$Bridge$$ExternalSyntheticLambda1(FaceActivity.Bridge bridge, String str) {
        this.f$0 = bridge;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        FaceActivity.Bridge.m1$r8$lambda$mRQv3jqm33LVXLT2OSaF082Is(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class FaceActivity$Bridge$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ FaceActivity.Bridge f$0;

    public /* synthetic */ FaceActivity$Bridge$$ExternalSyntheticLambda2(FaceActivity.Bridge bridge) {
        this.f$0 = bridge;
    }

    @Override // java.lang.Runnable
    public final void run() {
        FaceActivity.Bridge.$r8$lambda$jvlPwYCBQjHH1mx_04PWM0jOigg(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda0 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda0(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$Ze2qsh0MVUgLzps6erGHVkt_LRU(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda1(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$jLV7OY3lV5mzNXRgu8L_0VqoNno(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda10 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ boolean f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda10(MainActivity mainActivity, boolean z) {
        this.f$0 = mainActivity;
        this.f$1 = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m4$r8$lambda$632dv2nMGr1zXabSDFH18vfcI(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda11 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda11(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$JGgkIQzIdNuWS23rFHPpsXutOu0(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda12 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda12(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$0OEj7dKd0zu2PAixBGRK6kHfBaE(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda13 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda13(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$riu3oR40kA9mVCKP44SG4N5s8RU(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda14 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda14(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$DO6I05IqB376oIaWUR6BgC86ZNM(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda15 implements DialogInterface.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ EditText f$2;
    public final /* synthetic */ EditText f$3;
    public final /* synthetic */ EditText f$4;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda15(MainActivity mainActivity, int i, EditText editText, EditText editText2, EditText editText3) {
        this.f$0 = mainActivity;
        this.f$1 = i;
        this.f$2 = editText;
        this.f$3 = editText2;
        this.f$4 = editText3;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        MainActivity.m19$r8$lambda$cs10DC3fvVoonhtamO3lspOEt0(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4, dialogInterface, i);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda16 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda16(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$SH8noAFID_O0BuQz9Lw8JAPPeHc(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda17 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda17(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m6$r8$lambda$8LnNpkNKxYu0ldXa76galWmy50(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda18 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda18(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$GDd17EW5TLWPkvDx9qUQ3ld4lhM(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda19 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda19(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m18$r8$lambda$_4uEYGmKVgRhEtDc1ceJ9JUcWg(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda2(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m11$r8$lambda$PHII347s9pSC38oIdmUjWYXl2c(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda20 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda20(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$m56PDYpOHzMlyez64Y0GOL4J8II(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda21 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ double f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda21(MainActivity mainActivity, double d, int i) {
        this.f$0 = mainActivity;
        this.f$1 = d;
        this.f$2 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$ZgCiawqiwpAD6CpZhGR4SOQRnOk(this.f$0, this.f$1, this.f$2, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda22 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda22(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m10$r8$lambda$KcrZ568C6_YqQkjE_BT9I5CaV8(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda23 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda23(MainActivity mainActivity, String str) {
        this.f$0 = mainActivity;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m15$r8$lambda$VoN2_idDPiHzvSZKKzZhY652OE(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda24 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda24(MainActivity mainActivity, String str) {
        this.f$0 = mainActivity;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m9$r8$lambda$GpRM_2g0vbMijSLgiiFSAPSWts(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda25 implements DialogInterface.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda25(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        MainActivity.m22$r8$lambda$grqvxgZm8Wux5U3GsP7fGqhZNA(this.f$0, dialogInterface, i);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda26 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ EditText f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda26(MainActivity mainActivity, EditText editText) {
        this.f$0 = mainActivity;
        this.f$1 = editText;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$bmOBIZ_aaIgB68UYWe31XriW0HI(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda27 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda27(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$i9wDYbEnR6egWPxOiSZN0aVN9wQ(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda28 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda28(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$goFvspdIAKQ0J2QLw1FjdMzUNSc(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda29 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Uri f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda29(MainActivity mainActivity, Uri uri, int i) {
        this.f$0 = mainActivity;
        this.f$1 = uri;
        this.f$2 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m25$r8$lambda$m3lsu8G5HNpHUYYndr85xWmR9A(this.f$0, this.f$1, this.f$2);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda3(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m8$r8$lambda$GJ8NtPPFwJ6mOwfQwZmXRWJaBc(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda30 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda30(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.m7$r8$lambda$Dm5TF_3CxGQRi0Hw6au09EP7aU(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda31 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda31(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$VXqgE3Of5YEIrR21VHh_UkXEKSg(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda32 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda32(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.m20$r8$lambda$d_rrHNGyE_CVF6jsZTY0m5UlHI(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda33 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda33(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.m12$r8$lambda$RqDm6IYbsDR8fkCq32wooGfnU8(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda34 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda34(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.m21$r8$lambda$enRZ7raUuFhBo5wBzmsLL37hio(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda35 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda35(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$snoPc7xct8tE9DiCVLIdxBBocYc(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda36 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda36(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$Pmrfax10MWZ9MctYRIBATkT5nmM(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda37 implements DialogInterface.OnClickListener {
    public final /* synthetic */ Runnable f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda37(Runnable runnable) {
        this.f$0 = runnable;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        MainActivity.lambda$confirm$0(this.f$0, dialogInterface, i);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda38 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda38(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$4XHB5HzSgsqCtpmdAofTcbJGFGQ(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda39 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda39(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m14$r8$lambda$TLivfhk5khvbWTi0IX8Z35Sd9o(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda4 implements MainActivity.Submitter {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ JSONArray f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda4(MainActivity mainActivity, int i, JSONArray jSONArray) {
        this.f$0 = mainActivity;
        this.f$1 = i;
        this.f$2 = jSONArray;
    }

    @Override // com.prottasha.exam.MainActivity.Submitter
    public final void submit(JSONArray jSONArray, Runnable runnable) {
        MainActivity.$r8$lambda$gbbgxHTyCeYasOVpfPS09Vx_rgM(this.f$0, this.f$1, this.f$2, jSONArray, runnable);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda40 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda40(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$uO_c6ZwX47u8NeWxxojOvjddZh0(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda41 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ JSONObject f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda41(MainActivity mainActivity, JSONObject jSONObject) {
        this.f$0 = mainActivity;
        this.f$1 = jSONObject;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$R3nYBJ5Xonc1jWDDT6yaOTV3clU(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda42 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda42(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$iI7GoOSRifm92vNceksnLbGJWZU(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda43 implements MainActivity.Submitter {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda43(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // com.prottasha.exam.MainActivity.Submitter
    public final void submit(JSONArray jSONArray, Runnable runnable) {
        MainActivity.m17$r8$lambda$XKEyic2ZQOEoqtfDd1qRVcjFOY(this.f$0, this.f$1, jSONArray, runnable);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda44 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda44(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m26$r8$lambda$myy9qwAU3ATs3vv_W5rsVpbHns(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda45 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda45(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m3$r8$lambda$5IYASNKnkgczOClLMNBsr5PmGs(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda46 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda46(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$b05wwUpMHHlQr2kXp5qkJJknm24(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda47 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda47(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$ptoRKQreobGPaEca0trCMcf7IPs(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda48 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda48(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$yMVZ_58o5d6h0ytsvBH0P7p3kpw(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda49 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda49(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$pEmwZsAaw8ftfF6rZarYd0ory40(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda5 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda5(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m23$r8$lambda$i_a6AvNDiBXxTZKTm78au_6bNw(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda50 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda50(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$FOqj_vqLcgdpgBGxTInD6QyGsZY(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda51 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ boolean f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda51(MainActivity mainActivity, int i, boolean z) {
        this.f$0 = mainActivity;
        this.f$1 = i;
        this.f$2 = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$MHuJ9acgGyk41x2qTtrp6kkTrGw(this.f$0, this.f$1, this.f$2, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda52 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda52(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m13$r8$lambda$S9MdXG1xkBWEx8rJVpQmbC139Y(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda53 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda53(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m5$r8$lambda$7qRkEDomPAPkQTd2pSV4Kw5wVs(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda54 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda54(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$qlnM2nkUQ8JhlqZAfyJk2fThPOc(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda55 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda55(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$FXu1EG0effOMM2vOiHTxCaWDabk(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda56 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda56(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$uiUPA8FJbr1k_X6OJlPzFiqk2do(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda57 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda57(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$ChFWKTh2xO8SsTViHaLbt2tkChE(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda58 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ CheckBox f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda58(MainActivity mainActivity, CheckBox checkBox) {
        this.f$0 = mainActivity;
        this.f$1 = checkBox;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$7JGreejyIeiVV7BwLVdK2je2WB8(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda59 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda59(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m2$r8$lambda$0pdPFnjySiMIo1DUmzHBygt3jU(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda6 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda6(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$3CUt1mfsNra54BH3U5de0lAIZx0(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda60 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda60(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$uvT9rO7jFFZ8VBzxrKIhbp9jivA(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda61 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda61(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$JyyR3iFiYuA4ToeoNRZ6zn47KJo(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda62 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda62(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$zgO_gN3t5W85FjtHqs8UPu7hWyA(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda63 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda63(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.m24$r8$lambda$jJPEH3PcXkDqIzTxV9Fhl_EeBE(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda64 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda64(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.m16$r8$lambda$WBkjzsgSEOsS48Yw4GufOtN9bg(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda65 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda65(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$D1UXKjZufLmeYjUxTLdyJJdlnTk(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda66 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda66(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$pFqfxWgSoQFHZ96W4XRx_ElOtRo(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda67 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda67(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.m28$r8$lambda$vz_I9ZY5P7ilFAaEXOGVA5ZjyI(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda68 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda68(MainActivity mainActivity, String str) {
        this.f$0 = mainActivity;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m27$r8$lambda$ntH3IHAktNMLi4Dw8zPrwXNpNM(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda69 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda69(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$ghBSQe4aQEnmye8llwJ9O_1Fg3I(this.f$0, jSONObject);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda7 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda7(MainActivity mainActivity, String str) {
        this.f$0 = mainActivity;
        this.f$1 = str;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$t3EL8yGV6KLbWym2tWM9A__glhE(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda70 implements View.OnClickListener {
    public final /* synthetic */ Runnable f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda70(Runnable runnable) {
        this.f$0 = runnable;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.lambda$errorPage$5(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda8 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda8(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$u7CpVbkWwcleUspyqLyngtnNYfQ(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$$ExternalSyntheticLambda9 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ EditText f$1;
    public final /* synthetic */ EditText f$2;
    public final /* synthetic */ EditText f$3;
    public final /* synthetic */ boolean f$4;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda9(MainActivity mainActivity, EditText editText, EditText editText2, EditText editText3, boolean z) {
        this.f$0 = mainActivity;
        this.f$1 = editText;
        this.f$2 = editText2;
        this.f$3 = editText3;
        this.f$4 = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$6iRiYq6NpkAe9QLuvTHCBzE8np8(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$4$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ MainActivity.AnonymousClass4 f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$4$$ExternalSyntheticLambda0(MainActivity.AnonymousClass4 anonymousClass4, int i) {
        this.f$0 = anonymousClass4;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.AnonymousClass4.m53$r8$lambda$JAaHTqzE0bf48l2W_drKkmQ_I(this.f$0, this.f$1);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda0(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.ExamSession.$r8$lambda$TQ4HJs73AYRZ34HRNuMpVHpo_pk(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda1(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.ExamSession.$r8$lambda$mQoBjXZTcQFu5bBsTSIaibPbn9k(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda2 implements View.OnClickListener {
    public final /* synthetic */ MainActivity.ExamSession f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda2(MainActivity.ExamSession examSession, String str) {
        this.f$0 = examSession;
        this.f$1 = str;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.ExamSession.m55$r8$lambda$VpxKYt0kCGE45BJRgYHCxqmwo(this.f$0, this.f$1, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda3 implements View.OnClickListener {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda3(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.ExamSession.m56$r8$lambda$Wx834LsSewkvmCEfPT5B8lbGik(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda4 implements View.OnClickListener {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda4(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.ExamSession.m54$r8$lambda$KNCn3zuCcqtPownWtty6VRyz8(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda5 implements View.OnClickListener {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda5(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.ExamSession.$r8$lambda$avDm8t2pdgJxQ6PtYA709Gqundg(this.f$0, view);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda6 implements Runnable {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda6(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.ExamSession.m57$r8$lambda$pzdFBhXLHO01zlxwvsgxVCwfGM(this.f$0);
    }
}

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda7 implements Runnable {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda7(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.doSubmit();
    }
}
