package com.prottasha.exam;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** A circular progress ring with a big label in the middle. It animates in when shown. */
final class RingView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float frac = 0f;
    private float shown = 0f;
    private String bigText = "";
    private String smallText = "";

    RingView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(10f * d);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(10f * d);
        arc.setStrokeCap(Paint.Cap.ROUND);
        big.setTextAlign(Paint.Align.CENTER);
        big.setTypeface(Typeface.DEFAULT_BOLD);
        big.setTextSize(26f * d);
        small.setTextAlign(Paint.Align.CENTER);
        small.setTextSize(11f * d);
    }

    void setData(float fraction, String bigLabel, String smallLabel, int trackColor, int arcColor, int textColor, int subColor) {
        this.frac = Math.max(0f, Math.min(1f, fraction));
        this.bigText = bigLabel;
        this.smallText = smallLabel;
        track.setColor(trackColor);
        arc.setColor(arcColor);
        big.setColor(textColor);
        small.setColor(subColor);
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ValueAnimator a = ValueAnimator.ofFloat(0f, frac);
        a.setDuration(1200);
        a.setStartDelay(250);
        a.setInterpolator(new DecelerateInterpolator());
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                shown = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        shown = 0f;
        a.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float pad = track.getStrokeWidth() / 2f + 2f;
        rect.set(pad, pad, getWidth() - pad, getHeight() - pad);
        canvas.drawArc(rect, 0f, 360f, false, track);
        canvas.drawArc(rect, -90f, 360f * shown, false, arc);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        canvas.drawText(bigText, cx, cy + big.getTextSize() * 0.15f, big);
        canvas.drawText(smallText, cx, cy + big.getTextSize() * 0.15f + small.getTextSize() * 1.5f, small);
    }
}
