package com.prottasha.exam;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Circular countdown with the remaining time in the middle. Pulses when time is almost over. */
final class TimerRing extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float frac = 1f;
    private int color = 0xFF0B8A63;
    private String label = "";
    private boolean pulse = false;

    TimerRing(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(7f * d);
        track.setColor(0xFFECEAF8);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(7f * d);
        arc.setStrokeCap(Paint.Cap.ROUND);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Ui.display(c));
        text.setTextSize(14.5f * d);
        text.setColor(0xFF17153B);
    }

    void set(float fraction, String lbl, int c, boolean p) {
        this.frac = Math.max(0f, Math.min(1f, fraction));
        this.label = lbl;
        this.color = c;
        this.pulse = p;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float pad = track.getStrokeWidth() / 2f + 1f;
        rect.set(pad, pad, getWidth() - pad, getHeight() - pad);
        canvas.drawArc(rect, 0f, 360f, false, track);
        int alpha = 255;
        if (pulse) {
            alpha = (int) (165 + 90 * Math.sin(System.currentTimeMillis() / 170.0));
        }
        arc.setColor(color);
        arc.setAlpha(alpha);
        canvas.drawArc(rect, -90f, 360f * frac, false, arc);
        text.setColor(pulse ? color : 0xFF17153B);
        canvas.drawText(label, getWidth() / 2f, getHeight() / 2f + text.getTextSize() * 0.35f, text);
        if (pulse) {
            postInvalidateOnAnimation();
        }
    }
}
