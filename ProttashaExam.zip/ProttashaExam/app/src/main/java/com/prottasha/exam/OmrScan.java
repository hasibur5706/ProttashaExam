package com.prottasha.exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * On-device OMR pre-check. Pure Java (no Android classes) so it can be unit tested.
 * It measures how good the photo is and counts the question rows and marked bubbles it can see.
 * It assumes the common layout: each question is a row of option bubbles side by side.
 */
final class OmrScan {
    static final class Mark {
        float x;
        float y;
        float r;
        boolean multiple;
    }

    static final class Result {
        int width;
        int height;
        double brightness;
        double contrast;
        double sharpness;
        double glare;
        double unevenness;
        double skewDeg;
        boolean sheetFound;
        int groups;
        int options;
        int answered;
        int blank;
        int multiple;
        int unreadable;
        final List<Mark> marks = new ArrayList<>();
    }

    private OmrScan() {
    }

    private static final class Comp {
        int minx, maxx, miny, maxy, count;
        float cx, cy;
        float rx, ry;
        double fill;
        int w() {
            return maxx - minx + 1;
        }
        int h() {
            return maxy - miny + 1;
        }
    }

    static Result analyze(int[] g, int w, int h) {
        Result r = new Result();
        r.width = w;
        r.height = h;
        int n = w * h;

        // ---- exposure and contrast
        double sum = 0;
        double sum2 = 0;
        for (int i = 0; i < n; i++) {
            sum += g[i];
            sum2 += (double) g[i] * g[i];
        }
        double mean = sum / n;
        r.brightness = mean;
        r.contrast = Math.sqrt(Math.max(0, sum2 / n - mean * mean));

        // ---- sharpness: variance of the Laplacian
        double ls = 0;
        double ls2 = 0;
        long cnt = 0;
        for (int y = 1; y < h - 1; y++) {
            int row = y * w;
            for (int x = 1; x < w - 1; x++) {
                int c = g[row + x];
                double lap = 4.0 * c - g[row + x - 1] - g[row + x + 1] - g[row - w + x] - g[row + w + x];
                ls += lap;
                ls2 += lap * lap;
                cnt++;
            }
        }
        double lm = ls / Math.max(1, cnt);
        r.sharpness = ls2 / Math.max(1, cnt) - lm * lm;

        // ---- glare and uneven light, using blocks
        int bs = Math.max(8, Math.min(w, h) / 40);
        int bx = w / bs;
        int by = h / bs;
        int blown = 0;
        int blocks = 0;
        double[][] bm = new double[6][6];
        int[][] bc = new int[6][6];
        for (int j = 0; j < by; j++) {
            for (int i = 0; i < bx; i++) {
                double s = 0;
                for (int y = j * bs; y < (j + 1) * bs; y++) {
                    for (int x = i * bs; x < (i + 1) * bs; x++) {
                        s += g[y * w + x];
                    }
                }
                double m = s / (bs * bs);
                blocks++;
                if (m >= 250) {
                    blown++;
                }
                int gi = Math.min(5, i * 6 / Math.max(1, bx));
                int gj = Math.min(5, j * 6 / Math.max(1, by));
                bm[gj][gi] += m;
                bc[gj][gi]++;
            }
        }
        r.glare = blocks == 0 ? 0 : (double) blown / blocks;
        double mx = 0;
        double mn = 255;
        for (int j = 1; j < 5; j++) {
            for (int i = 1; i < 5; i++) {
                if (bc[j][i] > 0) {
                    double v = bm[j][i] / bc[j][i];
                    mx = Math.max(mx, v);
                    mn = Math.min(mn, v);
                }
            }
        }
        r.unevenness = mx <= 0 ? 0 : (mx - mn) / mx;

        // ---- adaptive threshold with an integral image
        long[] integral = new long[(w + 1) * (h + 1)];
        for (int y = 0; y < h; y++) {
            long rowSum = 0;
            for (int x = 0; x < w; x++) {
                rowSum += g[y * w + x];
                integral[(y + 1) * (w + 1) + x + 1] = integral[y * (w + 1) + x + 1] + rowSum;
            }
        }
        int half = Math.max(8, w / 50);
        boolean[] dark0 = new boolean[n];
        for (int y = 0; y < h; y++) {
            int y0 = Math.max(0, y - half);
            int y1 = Math.min(h, y + half + 1);
            for (int x = 0; x < w; x++) {
                int x0 = Math.max(0, x - half);
                int x1 = Math.min(w, x + half + 1);
                long s = integral[y1 * (w + 1) + x1] - integral[y0 * (w + 1) + x1] - integral[y1 * (w + 1) + x0] + integral[y0 * (w + 1) + x0];
                double lmean = (double) s / ((x1 - x0) * (y1 - y0));
                dark0[y * w + x] = g[y * w + x] < lmean - 16 && g[y * w + x] < 205;
            }
        }
        // close tiny gaps in thin printed circles (3x3 dilation)
        boolean[] dark = new boolean[n];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (!dark0[y * w + x]) {
                    continue;
                }
                for (int yy = Math.max(0, y - 1); yy <= Math.min(h - 1, y + 1); yy++) {
                    for (int xx = Math.max(0, x - 1); xx <= Math.min(w - 1, x + 1); xx++) {
                        dark[yy * w + xx] = true;
                    }
                }
            }
        }

        // ---- connected components
        boolean[] seen = new boolean[n];
        int[] stack = new int[n];
        List<Comp> comps = new ArrayList<>();
        int maxSide = (int) (0.08 * w);
        for (int start = 0; start < n; start++) {
            if (!dark[start] || seen[start]) {
                continue;
            }
            int sp = 0;
            stack[sp++] = start;
            seen[start] = true;
            Comp c = new Comp();
            c.minx = Integer.MAX_VALUE;
            c.miny = Integer.MAX_VALUE;
            c.maxx = -1;
            c.maxy = -1;
            while (sp > 0) {
                int p = stack[--sp];
                int px = p % w;
                int py = p / w;
                c.count++;
                if (px < c.minx) c.minx = px;
                if (px > c.maxx) c.maxx = px;
                if (py < c.miny) c.miny = py;
                if (py > c.maxy) c.maxy = py;
                if (px > 0 && dark[p - 1] && !seen[p - 1]) { seen[p - 1] = true; stack[sp++] = p - 1; }
                if (px < w - 1 && dark[p + 1] && !seen[p + 1]) { seen[p + 1] = true; stack[sp++] = p + 1; }
                if (py > 0 && dark[p - w] && !seen[p - w]) { seen[p - w] = true; stack[sp++] = p - w; }
                if (py < h - 1 && dark[p + w] && !seen[p + w]) { seen[p + w] = true; stack[sp++] = p + w; }
            }
            if (c.count >= 10 && c.w() <= maxSide && c.h() <= maxSide) {
                c.cx = (c.minx + c.maxx) / 2f;
                c.cy = (c.miny + c.maxy) / 2f;
                comps.add(c);
            }
        }

        // ---- typical bubble size: the most common near-square width
        int bin = Math.max(1, Math.round(w * 0.0015f));
        int[] hist = new int[(int) (0.08 * w) / bin + 3];
        List<Comp> roundish = new ArrayList<>();
        for (Comp c : comps) {
            double asp = (double) c.w() / c.h();
            if (asp > 0.78 && asp < 1.28 && c.w() >= 0.008 * w && c.w() <= 0.06 * w) {
                hist[c.w() / bin]++;
                roundish.add(c);
            }
        }
        int bestBin = -1;
        int bestCount = 0;
        for (int i = 1; i < hist.length - 1; i++) {
            int v = hist[i - 1] + hist[i] + hist[i + 1];
            if (v > bestCount) {
                bestCount = v;
                bestBin = i;
            }
        }
        if (bestBin < 0 || bestCount < 8) {
            r.sheetFound = false;
            return r;
        }
        double d0 = (bestBin + 0.5) * bin;
        List<Comp> bubbles = new ArrayList<>();
        for (Comp c : roundish) {
            if (Math.abs(c.w() - d0) <= 0.3 * d0 && Math.abs(c.h() - d0) <= 0.3 * d0) {
                // how dark is the centre of the bubble?
                int rad = Math.max(2, (int) (0.40 * d0));
                int dk = 0;
                int tot = 0;
                for (int yy = -rad; yy <= rad; yy++) {
                    for (int xx = -rad; xx <= rad; xx++) {
                        if (xx * xx + yy * yy <= rad * rad) {
                            int px = Math.round(c.cx) + xx;
                            int py = Math.round(c.cy) + yy;
                            if (px >= 0 && px < w && py >= 0 && py < h) {
                                tot++;
                                if (dark0[py * w + px]) {
                                    dk++;
                                }
                            }
                        }
                    }
                }
                c.fill = tot == 0 ? 0 : (double) dk / tot;
                bubbles.add(c);
            }
        }
        if (bubbles.size() < 8) {
            r.sheetFound = false;
            return r;
        }

        // ---- skew: angle between each bubble and its nearest neighbour on the right
        List<Double> angles = new ArrayList<>();
        for (Comp a : bubbles) {
            Comp best = null;
            double bestDx = 1e9;
            for (Comp b : bubbles) {
                double dx = b.cx - a.cx;
                double dy = b.cy - a.cy;
                if (dx > 1.3 * d0 && dx < 3.6 * d0 && Math.abs(dy) < 0.9 * d0 && dx < bestDx) {
                    best = b;
                    bestDx = dx;
                }
            }
            if (best != null) {
                angles.add(Math.atan2(best.cy - a.cy, best.cx - a.cx));
            }
        }
        double theta = 0;
        if (angles.size() >= 6) {
            Collections.sort(angles);
            theta = angles.get(angles.size() / 2);
        }
        r.skewDeg = Math.toDegrees(theta);
        double ct = Math.cos(theta);
        double st = Math.sin(theta);
        for (Comp c : bubbles) {
            c.rx = (float) (c.cx * ct + c.cy * st);
            c.ry = (float) (-c.cx * st + c.cy * ct);
        }

        // ---- rows
        Collections.sort(bubbles, (a, b) -> Float.compare(a.ry, b.ry));
        List<List<Comp>> rows = new ArrayList<>();
        List<Comp> cur = new ArrayList<>();
        double curY = 0;
        for (Comp c : bubbles) {
            if (cur.isEmpty()) {
                cur.add(c);
                curY = c.ry;
            } else if (c.ry - curY > 0.55 * d0) {
                rows.add(cur);
                cur = new ArrayList<>();
                cur.add(c);
                curY = c.ry;
            } else {
                cur.add(c);
                curY = (curY * (cur.size() - 1) + c.ry) / cur.size();
            }
        }
        rows.add(cur);
        List<Float> gaps = new ArrayList<>();
        for (List<Comp> row : rows) {
            Collections.sort(row, (a, b) -> Float.compare(a.rx, b.rx));
            for (int i = 1; i < row.size(); i++) {
                gaps.add(row.get(i).rx - row.get(i - 1).rx);
            }
        }
        if (gaps.size() < 5) {
            r.sheetFound = false;
            return r;
        }
        Collections.sort(gaps);
        float q1 = gaps.get(gaps.size() / 4);
        float splitAt = q1 * 1.8f;

        // ---- groups (one group = one question)
        List<List<Comp>> groups = new ArrayList<>();
        for (List<Comp> row : rows) {
            if (row.size() < 2) {
                continue;
            }
            List<Comp> g1 = new ArrayList<>();
            g1.add(row.get(0));
            for (int i = 1; i < row.size(); i++) {
                if (row.get(i).rx - row.get(i - 1).rx > splitAt) {
                    groups.add(g1);
                    g1 = new ArrayList<>();
                }
                g1.add(row.get(i));
            }
            groups.add(g1);
        }
        int[] sizeCount = new int[12];
        for (List<Comp> gr : groups) {
            if (gr.size() < sizeCount.length) {
                sizeCount[gr.size()]++;
            }
        }
        int k = 0;
        for (int s = 2; s < sizeCount.length; s++) {
            if (sizeCount[s] > sizeCount[k]) {
                k = s;
            }
        }
        if (k < 2 || sizeCount[k] < 4) {
            r.sheetFound = false;
            return r;
        }
        r.options = k;
        for (List<Comp> gr : groups) {
            if (gr.size() != k) {
                if (gr.size() >= 2) {
                    r.unreadable++;
                }
                continue;
            }
            r.groups++;
            int filled = 0;
            for (Comp c : gr) {
                if (c.fill >= 0.55) {
                    filled++;
                }
            }
            if (filled == 0) {
                r.blank++;
            } else if (filled == 1) {
                r.answered++;
            } else {
                r.multiple++;
            }
            for (Comp c : gr) {
                if (c.fill >= 0.55) {
                    Mark m = new Mark();
                    m.x = c.cx;
                    m.y = c.cy;
                    m.r = (float) (0.75 * d0);
                    m.multiple = filled > 1;
                    r.marks.add(m);
                }
            }
        }
        r.sheetFound = r.groups >= 4;
        return r;
    }
}
