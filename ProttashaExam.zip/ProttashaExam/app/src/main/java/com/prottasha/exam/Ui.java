package com.prottasha.exam;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared look and feel: colours, rounded cards, buttons and small animations. */
final class Ui {
    static final int INK = 0xFF17153B;
    static final int INDIGO = 0xFF4A3FD1;
    static final int BG = 0xFFF3F2FA;
    static final int SOFT = 0xFFE4E1FF;
    static final int MUTED = 0xFF55527A;
    static final int LINE = 0xFFE2DFF3;
    static final int TRACK = 0xFFECEAF8;
    static final int GREEN = 0xFF0B8A63;
    static final int GREEN_BG = 0xFFD9F5EA;
    static final int RED = 0xFFD6393F;
    static final int RED_BG = 0xFFFFE1DC;
    static final int AMBER = 0xFFB7791F;
    static final int AMBER_BG = 0xFFFFEFC9;
    static final int ACCENT = 0xFFFFB020;
    static final int ON_INK = 0xFFC9C6F2;
    static final int WHITE = -1;
    static final int MATCH = -1;
    static final int WRAP = -2;

    Ui() {
    }

    static int dp(Context c, float v) {
        return Math.round(c.getResources().getDisplayMetrics().density * v);
    }

    static GradientDrawable box(Context c, int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) {
            g.setStroke(dp(c, 1.5f), stroke);
        }
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(0f, 1.15f);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    static TextView pill(Context c, String s, int bg, int fg) {
        TextView t = tv(c, s, 12f, fg, true);
        t.setBackground(box(c, bg, 0, 14f));
        t.setPadding(dp(c, 10f), dp(c, 5f), dp(c, 10f), dp(c, 5f));
        return t;
    }

    static Button btn(Context c, String label, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16.0f);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setBackground(box(c, bg, bg == WHITE ? LINE : 0, 16.0f));
        b.setPadding(dp(c, 16.0f), dp(c, 12.0f), dp(c, 16.0f), dp(c, 12.0f));
        b.setMinHeight(0);
        b.setMinimumHeight(dp(c, 50.0f));
        b.setOnClickListener(l);
        press(b);
        return b;
    }

    static Button primary(Context c, String label, View.OnClickListener l) {
        return btn(c, label, INDIGO, WHITE, l);
    }

    static Button secondary(Context c, String label, View.OnClickListener l) {
        return btn(c, label, SOFT, INDIGO, l);
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(16);
        return l;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(box(c, WHITE, 0, 22.0f));
        l.setPadding(dp(c, 16.0f), dp(c, 16.0f), dp(c, 16.0f), dp(c, 16.0f));
        l.setElevation(dp(c, 1.5f));
        return l;
    }

    static void add(ViewGroup parent, View v) {
        add(parent, v, 10);
    }

    static void add(ViewGroup parent, View v, int bottomDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(parent.getContext(), bottomDp);
        parent.addView(v, lp);
    }

    static EditText input(Context c, String hint, int inputType) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setTextSize(16.0f);
        e.setTextColor(INK);
        e.setHintTextColor(MUTED);
        e.setBackground(box(c, WHITE, LINE, 14.0f));
        e.setPadding(dp(c, 14.0f), dp(c, 14.0f), dp(c, 14.0f), dp(c, 14.0f));
        return e;
    }

    static View bar(Context c, double frac, int color) {
        LinearLayout track = new LinearLayout(c);
        track.setBackground(box(c, TRACK, 0, 6.0f));
        View fill = new View(c);
        fill.setBackground(box(c, color, 0, 6.0f));
        float f = (float) Math.max(0.02d, Math.min(1.0d, frac));
        track.addView(fill, new LinearLayout.LayoutParams(0, dp(c, 10.0f), f));
        track.addView(new View(c), new LinearLayout.LayoutParams(0, dp(c, 10.0f), 1.0f - f));
        return track;
    }

    /** Small press animation for tappable views. */
    static void press(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                }
                return false;
            }
        });
    }

    /** Fade and slide a view in. */
    static void rise(View v, int delayMs) {
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 22f));
        v.animate().alpha(1f).translationY(0f).setStartDelay(delayMs).setDuration(450)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    static int color(String hex) {
        return Color.parseColor(hex);
    }
}
