package com.prottasha.exam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import java.util.Calendar;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.prottasha.exam.Api;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class MainActivity extends Activity {
    private static final int REQ_CAM = 21;
    private static final int REQ_CAM_PERM = 24;
    private static final int REQ_FACE = 23;
    private static final int REQ_PICK = 22;
    private Runnable afterFace;
    private TextView backBtn;
    private AlertDialog busyDialog;
    private Uri camUri;
    private FrameLayout content;
    private LinearLayout header;
    private LinearLayout nav;
    private Runnable onBack;
    private int pendingOmrExam;
    private SharedPreferences prefs;
    private Runnable refreshAction;
    private CountDownTimer timer;
    private TextView titleView;
    private static final String[][] TABS = {
            {"home", "ic_home", "হোম"},
            {"exams", "ic_exam", "পরীক্ষা"},
            {"practice", "ic_practice", "প্র্যাকটিস"},
            {"batches", "ic_batch", "ব্যাচ"},
            {"more", "ic_more", "আরও"}};
    private static final boolean FIXED_SERVER = !"https://prottashaacademy.com".isEmpty();
    private TextView[] navItems = new TextView[TABS.length];
    private String tab = "home";
    private int screenToken = 0;

    /* renamed from: com.prottasha.exam.MainActivity$1, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass1 implements Api.Callback {
        final /* synthetic */ Ok val$ok;

        AnonymousClass1(Ok ok) {
            this.val$ok = ok;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            MainActivity.m43$$Nest$mshowError(MainActivity.this, str);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            try {
                this.val$ok.run(jSONObject);
            } catch (Exception e) {
                MainActivity.m43$$Nest$mshowError(MainActivity.this, "সমস্যা হয়েছে: " + e.getMessage());
            }
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$2, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass2 implements Api.Callback {
        final /* synthetic */ Ok val$ok;
        final /* synthetic */ Runnable val$retry;
        final /* synthetic */ int val$tok;

        AnonymousClass2(int i, Ok ok, Runnable runnable) {
            this.val$tok = i;
            this.val$ok = ok;
            this.val$retry = runnable;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            if (this.val$tok != MainActivity.m30$$Nest$fgetscreenToken(MainActivity.this)) {
                return;
            }
            MainActivity.m38$$Nest$merrorPage(MainActivity.this, str, this.val$retry);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            if (this.val$tok != MainActivity.m30$$Nest$fgetscreenToken(MainActivity.this)) {
                return;
            }
            try {
                this.val$ok.run(jSONObject);
            } catch (Exception e) {
                MainActivity.m38$$Nest$merrorPage(MainActivity.this, "দেখাতে সমস্যা হয়েছে: " + e.getMessage(), this.val$retry);
            }
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$3, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass3 implements Api.Callback {
        final /* synthetic */ String val$old;
        final /* synthetic */ String val$url;

        AnonymousClass3(String str, String str2) {
            this.val$url = str;
            this.val$old = str2;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            Api.base = this.val$old;
            MainActivity.m43$$Nest$mshowError(MainActivity.this, "এই ঠিকানায় পরীক্ষা সার্ভার পাওয়া যায়নি।\n" + str);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            if (!this.val$url.equals(this.val$old)) {
                MainActivity.m34$$Nest$mclearLogin(MainActivity.this);
            }
            MainActivity.m29$$Nest$fgetprefs(MainActivity.this).edit().putString("server", this.val$url).apply();
            MainActivity.m41$$Nest$mroute(MainActivity.this);
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$4, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass4 implements Api.Callback {
        final /* synthetic */ int val$id;

        /* renamed from: $r8$lambda$JAaHTqzE0bf48l2W_drKkmQ--_I, reason: not valid java name */
        public static /* synthetic */ void m53$r8$lambda$JAaHTqzE0bf48l2W_drKkmQ_I(AnonymousClass4 anonymousClass4, int i) {
            anonymousClass4.lambda$onErr$0(i);
        }

        AnonymousClass4(int i) {
            this.val$id = i;
        }

        private /* synthetic */ void lambda$onErr$0(int i) {
            MainActivity.m48$$Nest$mstartLive(MainActivity.this, i);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            if ("FACE_REQUIRED".equals(str2)) {
                MainActivity.m47$$Nest$mstartFace(MainActivity.this, "verify", this.val$id, new MainActivity$4$$ExternalSyntheticLambda0(this, this.val$id));
            } else {
                MainActivity.m43$$Nest$mshowError(MainActivity.this, str);
            }
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            MainActivity.m40$$Nest$mopenLive(MainActivity.this, jSONObject);
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$5, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass5 implements Api.Callback {
        final /* synthetic */ Runnable val$onFail;

        AnonymousClass5(Runnable runnable) {
            this.val$onFail = runnable;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            this.val$onFail.run();
            MainActivity.m43$$Nest$mshowError(MainActivity.this, str);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            if (jSONObject.optBoolean("result_hidden")) {
                MainActivity.m45$$Nest$mshowReceipt(MainActivity.this, jSONObject.optString("message"));
            } else {
                MainActivity.m46$$Nest$mshowResult(MainActivity.this, "ফলাফল", jSONObject, MainActivity.m49$$Nest$smarr(jSONObject, "results"));
            }
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$6, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass6 implements Api.Callback {
        final /* synthetic */ Runnable val$onFail;
        final /* synthetic */ JSONArray val$qs;

        AnonymousClass6(JSONArray jSONArray, Runnable runnable) {
            this.val$qs = jSONArray;
            this.val$onFail = runnable;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            this.val$onFail.run();
            MainActivity.m43$$Nest$mshowError(MainActivity.this, str);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            JSONArray m49$$Nest$smarr = MainActivity.m49$$Nest$smarr(jSONObject, "results");
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < m49$$Nest$smarr.length(); i++) {
                JSONObject m50$$Nest$smat = MainActivity.m50$$Nest$smat(m49$$Nest$smarr, i);
                JSONObject jSONObject2 = null;
                for (int i2 = 0; i2 < this.val$qs.length(); i2++) {
                    if (MainActivity.m50$$Nest$smat(this.val$qs, i2).optInt("id") == m50$$Nest$smat.optInt("question_id")) {
                        jSONObject2 = MainActivity.m50$$Nest$smat(this.val$qs, i2);
                    }
                }
                if (jSONObject2 != null) {
                    try {
                        m50$$Nest$smat.put("options", MainActivity.m51$$Nest$smjson(new Object[]{"a", jSONObject2.optString("option_a"), "b", jSONObject2.optString("option_b"), "c", jSONObject2.optString("option_c"), "d", jSONObject2.optString("option_d")}));
                    } catch (Exception e) {
                    }
                }
                jSONArray.put(m50$$Nest$smat);
            }
            MainActivity.m46$$Nest$mshowResult(MainActivity.this, "প্র্যাকটিসের ফলাফল", jSONObject, jSONArray);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public class ExamSession {
        LinearLayout body;
        final int n;
        Button next;
        Button prev;
        TextView progressView;
        final JSONArray qs;
        final int remaining;
        final String[] sel;
        Button send;
        final long[] spent;
        final Submitter submitter;
        ScrollView sv;
        TextView timerView;
        final String title;
        int idx = 0;
        long shown = System.currentTimeMillis();
        boolean busy = false;

        /* renamed from: com.prottasha.exam.MainActivity$ExamSession$1, reason: invalid class name */
        /* loaded from: classes2.dex */
        class AnonymousClass1 extends CountDownTimer {
            AnonymousClass1(long j, long j2) {
                super(j, j2);
            }

            @Override // android.os.CountDownTimer
            public void onFinish() {
                ExamSession.this.timerView.setText("⏱ 00:00");
                ExamSession.this.doSubmit();
            }

            @Override // android.os.CountDownTimer
            public void onTick(long j) {
                int i = (int) (j / 1000);
                ExamSession.this.timerView.setText("⏱ " + MainActivity.m35$$Nest$mclock(MainActivity.this, i));
                ExamSession.this.timerView.setTextColor(i < 60 ? 0xFFD6393F : 0xFF4A3FD1);
            }
        }

        /* renamed from: $r8$lambda$KNCn3zu-CcqtPownWtty6VR-yz8, reason: not valid java name */
        public static /* synthetic */ void m54$r8$lambda$KNCn3zuCcqtPownWtty6VRyz8(ExamSession examSession, View view) {
            examSession.lambda$show$1(view);
        }

        public static /* synthetic */ void $r8$lambda$TQ4HJs73AYRZ34HRNuMpVHpo_pk(ExamSession examSession) {
            examSession.lambda$show$3();
        }

        /* renamed from: $r8$lambda$V-pxKYt0kCGE45B-JRgYHCxqmwo, reason: not valid java name */
        public static /* synthetic */ void m55$r8$lambda$VpxKYt0kCGE45BJRgYHCxqmwo(ExamSession examSession, String str, View view) {
            examSession.lambda$renderQ$5(str, view);
        }

        /* renamed from: $r8$lambda$Wx834LsSewkvmCE-fPT5B8lbGik, reason: not valid java name */
        public static /* synthetic */ void m56$r8$lambda$Wx834LsSewkvmCEfPT5B8lbGik(ExamSession examSession, View view) {
            examSession.lambda$show$0(view);
        }

        public static /* synthetic */ void $r8$lambda$avDm8t2pdgJxQ6PtYA709Gqundg(ExamSession examSession, View view) {
            examSession.lambda$show$2(view);
        }

        public static /* synthetic */ void $r8$lambda$mQoBjXZTcQFu5bBsTSIaibPbn9k(ExamSession examSession) {
            examSession.lambda$doSubmit$6();
        }

        /* renamed from: $r8$lambda$pz-dFBhXLHO01zlxwvsgxVCwfGM, reason: not valid java name */
        public static /* synthetic */ void m57$r8$lambda$pzdFBhXLHO01zlxwvsgxVCwfGM(ExamSession examSession) {
            examSession.lambda$show$4();
        }

        ExamSession(String str, JSONArray jSONArray, int i, Submitter submitter) {
            this.title = str;
            this.qs = jSONArray;
            this.remaining = i;
            this.submitter = submitter;
            this.n = jSONArray.length();
            this.sel = new String[this.n];
            this.spent = new long[this.n];
        }

        private /* synthetic */ void lambda$doSubmit$6() {
            this.busy = false;
        }

        private /* synthetic */ void lambda$renderQ$5(String str, View view) {
            this.sel[this.idx] = str.equals(this.sel[this.idx]) ? null : str;
            renderQ();
        }

        private /* synthetic */ void lambda$show$0(View view) {
            go(this.idx - 1);
        }

        private /* synthetic */ void lambda$show$1(View view) {
            go(this.idx + 1);
        }

        private /* synthetic */ void lambda$show$2(View view) {
            askSubmit();
        }

        private /* synthetic */ void lambda$show$3() {
            MainActivity.m44$$Nest$mshowMain(MainActivity.this, MainActivity.m31$$Nest$fgettab(MainActivity.this));
        }

        private /* synthetic */ void lambda$show$4() {
            MainActivity.m36$$Nest$mconfirm(MainActivity.this, "পরীক্ষা থেকে বের হবে?", this.remaining >= 0 ? "উত্তর জমা হবে না। পরে আবার এসে বাকি সময় থেকে চালিয়ে যেতে পারবে।" : "এই প্র্যাকটিসের উত্তর হারিয়ে যাবে।", new MainActivity$ExamSession$$ExternalSyntheticLambda0(this));
        }

        void askSubmit() {
            if (this.busy) {
                return;
            }
            int i = 0;
            for (String str : this.sel) {
                if (str == null) {
                    i++;
                }
            }
            MainActivity.m36$$Nest$mconfirm(MainActivity.this, "উত্তর জমা দেবে?", i > 0 ? i + " টি প্রশ্নের উত্তর দাওনি। তবুও জমা দেবে?" : "সব প্রশ্নের উত্তর দেওয়া হয়েছে।", new MainActivity$ExamSession$$ExternalSyntheticLambda7(this));
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void doSubmit() {
            if (this.busy) {
                return;
            }
            this.busy = true;
            leave();
            this.shown = System.currentTimeMillis();
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < this.n; i++) {
                jSONArray.put(MainActivity.m51$$Nest$smjson(new Object[]{"question_id", Integer.valueOf(MainActivity.m50$$Nest$smat(this.qs, i).optInt("id")), "selected_option", this.sel[i] == null ? JSONObject.NULL : this.sel[i], "time_taken_seconds", Long.valueOf(this.spent[i])}));
            }
            MainActivity.m33$$Nest$mbusy(MainActivity.this, "জমা হচ্ছে…");
            this.submitter.submit(jSONArray, new MainActivity$ExamSession$$ExternalSyntheticLambda1(this));
        }

        void go(int i) {
            if (i < 0 || i >= this.n) {
                return;
            }
            leave();
            this.idx = i;
            this.shown = System.currentTimeMillis();
            renderQ();
            this.sv.scrollTo(0, 0);
        }

        void leave() {
            long[] jArr = this.spent;
            int i = this.idx;
            jArr[i] = jArr[i] + ((System.currentTimeMillis() - this.shown) / 1000);
        }

        void renderQ() {
            int i;
            int i2;
            int i3 = 0;
            for (String str : this.sel) {
                if (str != null) {
                    i3++;
                }
            }
            this.progressView.setText("প্রশ্ন " + (this.idx + 1) + " / " + this.n + "  ·  উত্তর " + i3);
            this.prev.setEnabled(this.idx > 0);
            this.next.setEnabled(this.idx < this.n - 1);
            this.body.removeAllViews();
            JSONObject m50$$Nest$smat = MainActivity.m50$$Nest$smat(this.qs, this.idx);
            if (!MainActivity.m52$$Nest$smstr(m50$$Nest$smat, "topic_name").isEmpty()) {
                Ui.add(this.body, Ui.tv(MainActivity.this, m50$$Nest$smat.optString("topic_name"), 12.0f, 0xFF55527A, true), 4);
            }
            Ui.add(this.body, Ui.tv(MainActivity.this, m50$$Nest$smat.optString("question_text"), 18.0f, 0xFF17153B, true), 14);
            String[] strArr = {"a", "b", "c", "d"};
            for (int i4 = 0; i4 < 4; i4++) {
                String str2 = strArr[i4];
                boolean equals = str2.equals(this.sel[this.idx]);
                TextView tv = Ui.tv(MainActivity.this, str2.toUpperCase() + ".   " + m50$$Nest$smat.optString("option_" + str2), 16.0f, 0xFF17153B, equals);
                tv.setPadding(MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f));
                MainActivity mainActivity = MainActivity.this;
                if (equals) {
                    i = 0xFFE4E1FF;
                    i2 = 0xFF4A3FD1;
                } else {
                    i = -1;
                    i2 = 0xFFE2DFF3;
                }
                tv.setBackground(Ui.box(mainActivity, i, i2, 12.0f));
                tv.setOnClickListener(new MainActivity$ExamSession$$ExternalSyntheticLambda2(this, str2));
                Ui.add(this.body, tv, 10);
            }
        }

        void show() {
            LinearLayout vbox = Ui.vbox(MainActivity.this);
            LinearLayout hbox = Ui.hbox(MainActivity.this);
            hbox.setBackgroundColor(0xFFE4E1FF);
            hbox.setPadding(MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 8.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 8.0f));
            this.progressView = Ui.tv(MainActivity.this, "", 14.0f, 0xFF17153B, true);
            hbox.addView(this.progressView, new LinearLayout.LayoutParams(0, -2, 1.0f));
            this.timerView = Ui.tv(MainActivity.this, this.remaining >= 0 ? "⏱ " + MainActivity.m35$$Nest$mclock(MainActivity.this, this.remaining) : "", 16.0f, 0xFF4A3FD1, true);
            hbox.addView(this.timerView);
            vbox.addView(hbox, new LinearLayout.LayoutParams(-1, -2));
            this.sv = new ScrollView(MainActivity.this);
            this.body = Ui.vbox(MainActivity.this);
            this.body.setPadding(MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 14.0f));
            this.sv.addView(this.body, new FrameLayout.LayoutParams(-1, -2));
            vbox.addView(this.sv, new LinearLayout.LayoutParams(-1, 0, 1.0f));
            LinearLayout vbox2 = Ui.vbox(MainActivity.this);
            vbox2.setBackgroundColor(-1);
            vbox2.setPadding(MainActivity.m37$$Nest$mdp(MainActivity.this, 12.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 8.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 12.0f), MainActivity.m37$$Nest$mdp(MainActivity.this, 8.0f));
            LinearLayout hbox2 = Ui.hbox(MainActivity.this);
            this.prev = Ui.secondary(MainActivity.this, "← আগের", new MainActivity$ExamSession$$ExternalSyntheticLambda3(this));
            this.next = Ui.secondary(MainActivity.this, "পরের →", new MainActivity$ExamSession$$ExternalSyntheticLambda4(this));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
            layoutParams.rightMargin = MainActivity.m37$$Nest$mdp(MainActivity.this, 6.0f);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
            layoutParams2.leftMargin = MainActivity.m37$$Nest$mdp(MainActivity.this, 6.0f);
            hbox2.addView(this.prev, layoutParams);
            hbox2.addView(this.next, layoutParams2);
            Ui.add(vbox2, hbox2, 8);
            this.send = Ui.primary(MainActivity.this, "উত্তর জমা দাও", new MainActivity$ExamSession$$ExternalSyntheticLambda5(this));
            Ui.add(vbox2, this.send, 0);
            vbox.addView(vbox2, new LinearLayout.LayoutParams(-1, -2));
            MainActivity.m42$$Nest$msetScreen(MainActivity.this, this.title, vbox, false, new MainActivity$ExamSession$$ExternalSyntheticLambda6(this), null);
            renderQ();
            if (this.remaining >= 0) {
                MainActivity.m32$$Nest$fputtimer(MainActivity.this, new AnonymousClass1(1000 * this.remaining, 1000L).start());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public interface Ok {
        void run(JSONObject jSONObject) throws Exception;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public interface Submitter {
        void submit(JSONArray jSONArray, Runnable runnable);
    }

    public static /* synthetic */ void $r8$lambda$0OEj7dKd0zu2PAixBGRK6kHfBaE(MainActivity mainActivity, View view) {
        mainActivity.lambda$showAuth$11(view);
    }

    /* renamed from: $r8$lambda$0pdPFnjySiMIo-1DUmzHBygt3jU, reason: not valid java name */
    public static /* synthetic */ void m2$r8$lambda$0pdPFnjySiMIo1DUmzHBygt3jU(MainActivity mainActivity, View view) {
        mainActivity.lambda$showFace$59(view);
    }

    public static /* synthetic */ void $r8$lambda$3CUt1mfsNra54BH3U5de0lAIZx0(MainActivity mainActivity, View view) {
        mainActivity.lambda$buildChrome$3(view);
    }

    public static /* synthetic */ void $r8$lambda$4XHB5HzSgsqCtpmdAofTcbJGFGQ(MainActivity mainActivity) {
        mainActivity.lambda$onCreate$1();
    }

    /* renamed from: $r8$lambda$5IYA-SNKnkgczOClLMNBsr5PmGs, reason: not valid java name */
    public static /* synthetic */ void m3$r8$lambda$5IYASNKnkgczOClLMNBsr5PmGs(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$18(i, view);
    }

    /* renamed from: $r8$lambda$63-2dv2nMGr1z-XabSDFH18vfcI, reason: not valid java name */
    public static /* synthetic */ void m4$r8$lambda$632dv2nMGr1zXabSDFH18vfcI(MainActivity mainActivity, boolean z, View view) {
        mainActivity.lambda$showAuth$10(z, view);
    }

    public static /* synthetic */ void $r8$lambda$6iRiYq6NpkAe9QLuvTHCBzE8np8(MainActivity mainActivity, EditText editText, EditText editText2, EditText editText3, boolean z, View view) {
        mainActivity.lambda$showAuth$9(editText, editText2, editText3, z, view);
    }

    public static /* synthetic */ void $r8$lambda$7JGreejyIeiVV7BwLVdK2je2WB8(MainActivity mainActivity, CheckBox checkBox, View view) {
        mainActivity.lambda$showFace$58(checkBox, view);
    }

    /* renamed from: $r8$lambda$7qRkEDomPAPkQ-Td2pSV4Kw5wVs, reason: not valid java name */
    public static /* synthetic */ void m5$r8$lambda$7qRkEDomPAPkQTd2pSV4Kw5wVs(MainActivity mainActivity, View view) {
        mainActivity.lambda$showMore$49(view);
    }

    /* renamed from: $r8$lambda$8LnNpkNKxYu0ldXa76galWmy-50, reason: not valid java name */
    public static /* synthetic */ void m6$r8$lambda$8LnNpkNKxYu0ldXa76galWmy50(MainActivity mainActivity, View view) {
        mainActivity.lambda$showAdminNote$13(view);
    }

    public static /* synthetic */ void $r8$lambda$ChFWKTh2xO8SsTViHaLbt2tkChE(MainActivity mainActivity, View view) {
        mainActivity.lambda$showMore$54(view);
    }

    public static /* synthetic */ void $r8$lambda$D1UXKjZufLmeYjUxTLdyJJdlnTk(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadPractice$41(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$DO6I05IqB376oIaWUR6BgC86ZNM(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showFace$60(jSONObject);
    }

    /* renamed from: $r8$lambda$Dm5TF_3CxGQRi0Hw6au09EP7a-U, reason: not valid java name */
    public static /* synthetic */ void m7$r8$lambda$Dm5TF_3CxGQRi0Hw6au09EP7aU(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showPaper$33(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$FOqj_vqLcgdpgBGxTInD6QyGsZY(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$25(i, view);
    }

    public static /* synthetic */ void $r8$lambda$FXu1EG0effOMM2vOiHTxCaWDabk(MainActivity mainActivity) {
        mainActivity.showLeaderboard();
    }

    public static /* synthetic */ void $r8$lambda$GDd17EW5TLWPkvDx9qUQ3ld4lhM(MainActivity mainActivity, int i) {
        mainActivity.lambda$examCard$21(i);
    }

    /* renamed from: $r8$lambda$GJ8NtPPFwJ-6mOwfQwZmXRWJaBc, reason: not valid java name */
    public static /* synthetic */ void m8$r8$lambda$GJ8NtPPFwJ6mOwfQwZmXRWJaBc(MainActivity mainActivity, int i) {
        mainActivity.lambda$examCard$19(i);
    }

    /* renamed from: $r8$lambda$Gp-RM_2g0vbMijSLgiiFSAPSWts, reason: not valid java name */
    public static /* synthetic */ void m9$r8$lambda$GpRM_2g0vbMijSLgiiFSAPSWts(MainActivity mainActivity, String str) {
        mainActivity.lambda$showMain$15(str);
    }

    public static /* synthetic */ void $r8$lambda$JGgkIQzIdNuWS23rFHPpsXutOu0(MainActivity mainActivity) {
        mainActivity.lambda$showFace$57();
    }

    public static /* synthetic */ void $r8$lambda$JyyR3iFiYuA4ToeoNRZ6zn47KJo(MainActivity mainActivity, View view) {
        mainActivity.lambda$showReceipt$30(view);
    }

    /* renamed from: $r8$lambda$KcrZ568C6_-YqQkjE_BT9I5CaV8, reason: not valid java name */
    public static /* synthetic */ void m10$r8$lambda$KcrZ568C6_YqQkjE_BT9I5CaV8(MainActivity mainActivity) {
        mainActivity.showFace();
    }

    public static /* synthetic */ void $r8$lambda$MHuJ9acgGyk41x2qTtrp6kkTrGw(MainActivity mainActivity, int i, boolean z, View view) {
        mainActivity.lambda$examCard$26(i, z, view);
    }

    /* renamed from: $r8$lambda$P-HII347s9pSC38oIdmUjWYXl2c, reason: not valid java name */
    public static /* synthetic */ void m11$r8$lambda$PHII347s9pSC38oIdmUjWYXl2c(MainActivity mainActivity) {
        mainActivity.lambda$showResult$37();
    }

    public static /* synthetic */ void $r8$lambda$Pmrfax10MWZ9MctYRIBATkT5nmM(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$paymentDialog$47(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$R3nYBJ5Xonc1jWDDT6yaOTV3clU(MainActivity mainActivity, JSONObject jSONObject, View view) {
        mainActivity.lambda$loadPractice$40(jSONObject, view);
    }

    /* renamed from: $r8$lambda$RqDm6IYbsDR8fkCq-32wooGfnU8, reason: not valid java name */
    public static /* synthetic */ void m12$r8$lambda$RqDm6IYbsDR8fkCq32wooGfnU8(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showFace$63(jSONObject);
    }

    /* renamed from: $r8$lambda$S9MdXG1xkBWEx8rJVpQ-mbC139Y, reason: not valid java name */
    public static /* synthetic */ void m13$r8$lambda$S9MdXG1xkBWEx8rJVpQmbC139Y(MainActivity mainActivity, View view) {
        mainActivity.lambda$examCard$27(view);
    }

    public static /* synthetic */ void $r8$lambda$SH8noAFID_O0BuQz9Lw8JAPPeHc(MainActivity mainActivity, View view) {
        mainActivity.lambda$showAdminNote$12(view);
    }

    /* renamed from: $r8$lambda$TL-ivfhk5khvbWTi0IX8Z35Sd9o, reason: not valid java name */
    public static /* synthetic */ void m14$r8$lambda$TLivfhk5khvbWTi0IX8Z35Sd9o(MainActivity mainActivity, View view) {
        mainActivity.lambda$loadPractice$38(view);
    }

    public static /* synthetic */ void $r8$lambda$VXqgE3Of5YEIrR21VHh_UkXEKSg(MainActivity mainActivity) {
        mainActivity.lambda$uploadOmr$65();
    }

    /* renamed from: $r8$lambda$VoN2_idDPiHzvSZKKzZhY652-OE, reason: not valid java name */
    public static /* synthetic */ void m15$r8$lambda$VoN2_idDPiHzvSZKKzZhY652OE(MainActivity mainActivity, String str) {
        mainActivity.lambda$showMain$14(str);
    }

    /* renamed from: $r8$lambda$WBkjzsgSEOsS48Yw4-GufOtN9bg, reason: not valid java name */
    public static /* synthetic */ void m16$r8$lambda$WBkjzsgSEOsS48Yw4GufOtN9bg(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$openReview$35(jSONObject);
    }

    /* renamed from: $r8$lambda$XKEyic2ZQOEoqtf-Dd1qRVcjFOY, reason: not valid java name */
    public static /* synthetic */ void m17$r8$lambda$XKEyic2ZQOEoqtfDd1qRVcjFOY(MainActivity mainActivity, int i, JSONArray jSONArray, Runnable runnable) {
        mainActivity.lambda$openLive$29(i, jSONArray, runnable);
    }

    public static /* synthetic */ void $r8$lambda$Ze2qsh0MVUgLzps6erGHVkt_LRU(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadBatches$44(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$ZgCiawqiwpAD6CpZhGR4SOQRnOk(MainActivity mainActivity, double d, int i, View view) {
        mainActivity.lambda$loadBatches$45(d, i, view);
    }

    /* renamed from: $r8$lambda$_4uEYGmKVgRhEtDc1c-eJ9JUcWg, reason: not valid java name */
    public static /* synthetic */ void m18$r8$lambda$_4uEYGmKVgRhEtDc1ceJ9JUcWg(MainActivity mainActivity) {
        mainActivity.lambda$showFace$61();
    }

    public static /* synthetic */ void $r8$lambda$b05wwUpMHHlQr2kXp5qkJJknm24(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$20(i, view);
    }

    public static /* synthetic */ void $r8$lambda$bmOBIZ_aaIgB68UYWe31XriW0HI(MainActivity mainActivity, EditText editText, View view) {
        mainActivity.lambda$showServerSetup$6(editText, view);
    }

    /* renamed from: $r8$lambda$cs10DC3fvVo-onhtamO3lspOEt0, reason: not valid java name */
    public static /* synthetic */ void m19$r8$lambda$cs10DC3fvVoonhtamO3lspOEt0(MainActivity mainActivity, int i, EditText editText, EditText editText2, EditText editText3, DialogInterface dialogInterface, int i2) {
        mainActivity.lambda$paymentDialog$48(i, editText, editText2, editText3, dialogInterface, i2);
    }

    /* renamed from: $r8$lambda$d_rrHNGyE_-CVF6jsZTY0m5UlHI, reason: not valid java name */
    public static /* synthetic */ void m20$r8$lambda$d_rrHNGyE_CVF6jsZTY0m5UlHI(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$uploadOmr$66(jSONObject);
    }

    /* renamed from: $r8$lambda$enRZ7raUuFhBo5wBzms-LL37hio, reason: not valid java name */
    public static /* synthetic */ void m21$r8$lambda$enRZ7raUuFhBo5wBzmsLL37hio(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.openPractice(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$gbbgxHTyCeYasOVpfPS09Vx_rgM(MainActivity mainActivity, int i, JSONArray jSONArray, JSONArray jSONArray2, Runnable runnable) {
        mainActivity.lambda$openPractice$42(i, jSONArray, jSONArray2, runnable);
    }

    public static /* synthetic */ void $r8$lambda$ghBSQe4aQEnmye8llwJ9O_1Fg3I(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadExams$16(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$goFvspdIAKQ0J2QLw1FjdMzUNSc(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showAuth$8(jSONObject);
    }

    /* renamed from: $r8$lambda$grqvxgZm8-Wux5U3GsP7fGqhZNA, reason: not valid java name */
    public static /* synthetic */ void m22$r8$lambda$grqvxgZm8Wux5U3GsP7fGqhZNA(MainActivity mainActivity, DialogInterface dialogInterface, int i) {
        mainActivity.lambda$pickOmrImage$64(dialogInterface, i);
    }

    public static /* synthetic */ void $r8$lambda$i9wDYbEnR6egWPxOiSZN0aVN9wQ(MainActivity mainActivity) {
        mainActivity.lambda$showServerSetup$7();
    }

    public static /* synthetic */ void $r8$lambda$iI7GoOSRifm92vNceksnLbGJWZU(MainActivity mainActivity, int i) {
        mainActivity.lambda$examCard$17(i);
    }

    /* renamed from: $r8$lambda$i_a6AvNDiBXxTZKTm78au_6b-Nw, reason: not valid java name */
    public static /* synthetic */ void m23$r8$lambda$i_a6AvNDiBXxTZKTm78au_6bNw(MainActivity mainActivity, View view) {
        mainActivity.lambda$buildChrome$2(view);
    }

    /* renamed from: $r8$lambda$jJPEH3-PcXkDqIzTxV9Fhl_EeBE, reason: not valid java name */
    public static /* synthetic */ void m24$r8$lambda$jJPEH3PcXkDqIzTxV9Fhl_EeBE(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$openReview$34(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$jLV7OY3lV5mzNXRgu8L_0VqoNno(MainActivity mainActivity, View view) {
        mainActivity.lambda$showResult$36(view);
    }

    /* renamed from: $r8$lambda$m3lsu8G5HN-pHUYYndr85xWmR9A, reason: not valid java name */
    public static /* synthetic */ void m25$r8$lambda$m3lsu8G5HNpHUYYndr85xWmR9A(MainActivity mainActivity, Uri uri, int i) {
        mainActivity.lambda$uploadOmr$67(uri, i);
    }

    public static /* synthetic */ void $r8$lambda$m56PDYpOHzMlyez64Y0GOL4J8II(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadDashboard$43(jSONObject);
    }

    /* renamed from: $r8$lambda$myy9qwAU3ATs3vv_W-5rsVpbHns, reason: not valid java name */
    public static /* synthetic */ void m26$r8$lambda$myy9qwAU3ATs3vv_W5rsVpbHns(MainActivity mainActivity) {
        mainActivity.lambda$showLeaderboard$55();
    }

    /* renamed from: $r8$lambda$ntH3IHAktNMLi4Dw8zPr-wXNpNM, reason: not valid java name */
    public static /* synthetic */ void m27$r8$lambda$ntH3IHAktNMLi4Dw8zPrwXNpNM(MainActivity mainActivity, String str) {
        mainActivity.lambda$showPaper$32(str);
    }

    public static /* synthetic */ void $r8$lambda$pEmwZsAaw8ftfF6rZarYd0ory40(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$24(i, view);
    }

    public static /* synthetic */ void $r8$lambda$pFqfxWgSoQFHZ96W4XRx_ElOtRo(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showLeaderboard$56(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$ptoRKQreobGPaEca0trCMcf7IPs(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$22(i, view);
    }

    public static /* synthetic */ void $r8$lambda$qlnM2nkUQ8JhlqZAfyJk2fThPOc(MainActivity mainActivity, View view) {
        mainActivity.lambda$showMore$50(view);
    }

    public static /* synthetic */ void $r8$lambda$riu3oR40kA9mVCKP44SG4N5s8RU(MainActivity mainActivity) {
        mainActivity.lambda$showMore$53();
    }

    public static /* synthetic */ void $r8$lambda$snoPc7xct8tE9DiCVLIdxBBocYc(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$chooseOmr$28(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$t3EL8yGV6KLbWym2tWM9A__glhE(MainActivity mainActivity, String str, View view) {
        mainActivity.lambda$buildChrome$4(str, view);
    }

    public static /* synthetic */ void $r8$lambda$u7CpVbkWwcleUspyqLyngtnNYfQ(MainActivity mainActivity) {
        mainActivity.lambda$showMore$51();
    }

    public static /* synthetic */ void $r8$lambda$uO_c6ZwX47u8NeWxxojOvjddZh0(MainActivity mainActivity, View view) {
        mainActivity.lambda$loadPractice$39(view);
    }

    public static /* synthetic */ void $r8$lambda$uiUPA8FJbr1k_X6OJlPzFiqk2do(MainActivity mainActivity, View view) {
        mainActivity.lambda$showMore$52(view);
    }

    public static /* synthetic */ void $r8$lambda$uvT9rO7jFFZ8VBzxrKIhbp9jivA(MainActivity mainActivity, View view) {
        mainActivity.lambda$showFace$62(view);
    }

    /* renamed from: $r8$lambda$vz_I9ZY5P7ilFAaEXOG-VA5ZjyI, reason: not valid java name */
    public static /* synthetic */ void m28$r8$lambda$vz_I9ZY5P7ilFAaEXOGVA5ZjyI(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadBatches$46(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$yMVZ_58o5d6h0ytsvBH0P7p3kpw(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$23(i, view);
    }

    public static /* synthetic */ void $r8$lambda$zgO_gN3t5W85FjtHqs8UPu7hWyA(MainActivity mainActivity) {
        mainActivity.lambda$showReceipt$31();
    }

    /* renamed from: -$$Nest$fgetprefs, reason: not valid java name */
    static /* bridge */ /* synthetic */ SharedPreferences m29$$Nest$fgetprefs(MainActivity mainActivity) {
        return mainActivity.prefs;
    }

    /* renamed from: -$$Nest$fgetscreenToken, reason: not valid java name */
    static /* bridge */ /* synthetic */ int m30$$Nest$fgetscreenToken(MainActivity mainActivity) {
        return mainActivity.screenToken;
    }

    /* renamed from: -$$Nest$fgettab, reason: not valid java name */
    static /* bridge */ /* synthetic */ String m31$$Nest$fgettab(MainActivity mainActivity) {
        return mainActivity.tab;
    }

    /* renamed from: -$$Nest$fputtimer, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m32$$Nest$fputtimer(MainActivity mainActivity, CountDownTimer countDownTimer) {
        mainActivity.timer = countDownTimer;
    }

    /* renamed from: -$$Nest$mbusy, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m33$$Nest$mbusy(MainActivity mainActivity, String str) {
        mainActivity.busy(str);
    }

    /* renamed from: -$$Nest$mclearLogin, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m34$$Nest$mclearLogin(MainActivity mainActivity) {
        mainActivity.clearLogin();
    }

    /* renamed from: -$$Nest$mclock, reason: not valid java name */
    static /* bridge */ /* synthetic */ String m35$$Nest$mclock(MainActivity mainActivity, int i) {
        return mainActivity.clock(i);
    }

    /* renamed from: -$$Nest$mconfirm, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m36$$Nest$mconfirm(MainActivity mainActivity, String str, String str2, Runnable runnable) {
        mainActivity.confirm(str, str2, runnable);
    }

    /* renamed from: -$$Nest$mdp, reason: not valid java name */
    static /* bridge */ /* synthetic */ int m37$$Nest$mdp(MainActivity mainActivity, float f) {
        return mainActivity.dp(f);
    }

    /* renamed from: -$$Nest$merrorPage, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m38$$Nest$merrorPage(MainActivity mainActivity, String str, Runnable runnable) {
        mainActivity.errorPage(str, runnable);
    }

    /* renamed from: -$$Nest$mhideBusy, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m39$$Nest$mhideBusy(MainActivity mainActivity) {
        mainActivity.hideBusy();
    }

    /* renamed from: -$$Nest$mopenLive, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m40$$Nest$mopenLive(MainActivity mainActivity, JSONObject jSONObject) {
        mainActivity.openLive(jSONObject);
    }

    /* renamed from: -$$Nest$mroute, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m41$$Nest$mroute(MainActivity mainActivity) {
        mainActivity.route();
    }

    /* renamed from: -$$Nest$msetScreen, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m42$$Nest$msetScreen(MainActivity mainActivity, String str, View view, boolean z, Runnable runnable, Runnable runnable2) {
        mainActivity.setScreen(str, view, z, runnable, runnable2);
    }

    /* renamed from: -$$Nest$mshowError, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m43$$Nest$mshowError(MainActivity mainActivity, String str) {
        mainActivity.showError(str);
    }

    /* renamed from: -$$Nest$mshowMain, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m44$$Nest$mshowMain(MainActivity mainActivity, String str) {
        mainActivity.showMain(str);
    }

    /* renamed from: -$$Nest$mshowReceipt, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m45$$Nest$mshowReceipt(MainActivity mainActivity, String str) {
        mainActivity.showReceipt(str);
    }

    /* renamed from: -$$Nest$mshowResult, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m46$$Nest$mshowResult(MainActivity mainActivity, String str, JSONObject jSONObject, JSONArray jSONArray) {
        mainActivity.showResult(str, jSONObject, jSONArray);
    }

    /* renamed from: -$$Nest$mstartFace, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m47$$Nest$mstartFace(MainActivity mainActivity, String str, int i, Runnable runnable) {
        mainActivity.startFace(str, i, runnable);
    }

    /* renamed from: -$$Nest$mstartLive, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m48$$Nest$mstartLive(MainActivity mainActivity, int i) {
        mainActivity.startLive(i);
    }

    /* renamed from: -$$Nest$smarr, reason: not valid java name */
    static /* bridge */ /* synthetic */ JSONArray m49$$Nest$smarr(JSONObject jSONObject, String str) {
        return arr(jSONObject, str);
    }

    /* renamed from: -$$Nest$smat, reason: not valid java name */
    static /* bridge */ /* synthetic */ JSONObject m50$$Nest$smat(JSONArray jSONArray, int i) {
        return at(jSONArray, i);
    }

    /* renamed from: -$$Nest$smjson, reason: not valid java name */
    static /* bridge */ /* synthetic */ JSONObject m51$$Nest$smjson(Object[] objArr) {
        return json(objArr);
    }

    /* renamed from: -$$Nest$smstr, reason: not valid java name */
    static /* bridge */ /* synthetic */ String m52$$Nest$smstr(JSONObject jSONObject, String str) {
        return str(jSONObject, str);
    }

    private Api.Callback actCb(Ok ok) {
        return new AnonymousClass1(ok);
    }

    private static JSONArray arr(JSONObject jSONObject, String str) {
        JSONArray optJSONArray = jSONObject.optJSONArray(str);
        return optJSONArray == null ? new JSONArray() : optJSONArray;
    }

    private static JSONObject at(JSONArray jSONArray, int i) {
        JSONObject optJSONObject = jSONArray.optJSONObject(i);
        return optJSONObject == null ? new JSONObject() : optJSONObject;
    }

    private void buildChrome() {
        LinearLayout vbox = Ui.vbox(this);
        vbox.setBackgroundColor(Ui.BG);
        this.header = Ui.hbox(this);
        this.header.setBackgroundColor(Ui.INK);
        this.header.setPadding(dp(8.0f), dp(12.0f), dp(8.0f), dp(12.0f));
        this.backBtn = Ui.tv(this, "←", 22.0f, -1, true);
        this.backBtn.setPadding(dp(12.0f), dp(2.0f), dp(14.0f), dp(2.0f));
        this.backBtn.setOnClickListener(new MainActivity$$ExternalSyntheticLambda5(this));
        this.header.addView(this.backBtn);
        this.titleView = Ui.tv(this, "Prottasha Academy", 18.0f, -1, true);
        this.header.addView(this.titleView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView refresh = Ui.tv(this, "↻", 24.0f, -1, true);
        refresh.setPadding(dp(12.0f), dp(2.0f), dp(12.0f), dp(2.0f));
        refresh.setOnClickListener(new MainActivity$$ExternalSyntheticLambda6(this));
        this.header.addView(refresh);
        vbox.addView(this.header, new LinearLayout.LayoutParams(-1, -2));
        this.content = new FrameLayout(this);
        vbox.addView(this.content, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        this.nav = Ui.hbox(this);
        this.nav.setBackground(Ui.box(this, Ui.INK, 0, 26.0f));
        this.nav.setPadding(dp(6.0f), dp(6.0f), dp(6.0f), dp(6.0f));
        this.nav.setElevation(dp(8.0f));
        for (int i = 0; i < TABS.length; i++) {
            String key = TABS[i][0];
            TextView item = Ui.tv(this, TABS[i][2], 11.0f, 0xFFB9B6E0, true);
            item.setGravity(17);
            item.setCompoundDrawablePadding(dp(2.0f));
            Drawable ico = getDrawable(drawableId(TABS[i][1])).mutate();
            item.setCompoundDrawablesWithIntrinsicBounds(null, ico, null, null);
            item.setCompoundDrawableTintList(ColorStateList.valueOf(0xFFB9B6E0));
            item.setPadding(0, dp(8.0f), 0, dp(8.0f));
            item.setOnClickListener(new MainActivity$$ExternalSyntheticLambda7(this, key));
            this.navItems[i] = item;
            this.nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1.0f));
        }
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(-1, -2);
        navLp.setMargins(dp(12.0f), dp(4.0f), dp(12.0f), dp(12.0f));
        vbox.addView(this.nav, navLp);
        final FrameLayout root = new FrameLayout(this);
        root.addView(vbox, new FrameLayout.LayoutParams(-1, -1));
        final View splash = buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        splash.postDelayed(new Runnable() {
            @Override
            public void run() {
                splash.animate().alpha(0f).setDuration(350).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        root.removeView(splash);
                    }
                }).start();
            }
        }, 1500);
    }

    private int drawableId(String name) {
        return getResources().getIdentifier(name, "drawable", getPackageName());
    }

    private void styleNav(String active) {
        for (int i = 0; i < TABS.length; i++) {
            boolean on = TABS[i][0].equals(active);
            TextView t = this.navItems[i];
            t.setTextColor(on ? -1 : 0xFFB9B6E0);
            t.setCompoundDrawableTintList(ColorStateList.valueOf(on ? Ui.ACCENT : 0xFFB9B6E0));
            t.setBackground(on ? Ui.box(this, 0x24FFFFFF, 0, 20.0f) : null);
        }
    }

    private View buildSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Ui.INK);
        f.setClickable(true);
        LinearLayout col = Ui.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleX(0.6f);
        logo.setScaleY(0.6f);
        logo.setAlpha(0f);
        col.addView(logo, new LinearLayout.LayoutParams(dp(150.0f), dp(150.0f)));
        TextView name = Ui.tv(this, "প্রত্যাশা একাডেমি", 28.0f, -1, true);
        name.setGravity(Gravity.CENTER);
        name.setAlpha(0f);
        TextView sub = Ui.tv(this, "Prottasha Academy", 14.0f, 0xFFB9B6E0, false);
        sub.setGravity(Gravity.CENTER);
        sub.setAlpha(0f);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
        nl.topMargin = dp(18.0f);
        col.addView(name, nl);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.topMargin = dp(4.0f);
        col.addView(sub, sl);
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(-1, -2);
        cl.gravity = Gravity.CENTER;
        f.addView(col, cl);
        FrameLayout track = new FrameLayout(this);
        track.setBackground(Ui.box(this, 0x1FFFFFFF, 0, 3.0f));
        View fill = new View(this);
        fill.setBackground(Ui.box(this, Ui.ACCENT, 0, 3.0f));
        fill.setPivotX(0f);
        fill.setScaleX(0f);
        track.addView(fill, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(dp(140.0f), dp(5.0f));
        tl.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        tl.bottomMargin = dp(70.0f);
        f.addView(track, tl);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(800).setInterpolator(new OvershootInterpolator()).start();
        name.animate().alpha(1f).setStartDelay(500).setDuration(500).start();
        sub.animate().alpha(1f).setStartDelay(650).setDuration(500).start();
        fill.animate().scaleX(1f).setStartDelay(200).setDuration(1300).start();
        return f;
    }

    private void busy(String str) {
        hideBusy();
        this.busyDialog = new AlertDialog.Builder(this).setMessage(str).setCancelable(false).show();
    }

    private View centered(String str) {
        FrameLayout frameLayout = new FrameLayout(this);
        TextView tv = Ui.tv(this, str, 16.0f, 0xFF55527A, false);
        tv.setGravity(17);
        tv.setPadding(dp(24.0f), dp(24.0f), dp(24.0f), dp(24.0f));
        frameLayout.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        return frameLayout;
    }

    private void chooseOmr(int i) {
        busy("অপেক্ষা করো…");
        Api.call("POST", "/online/exams/" + i + "/choose", json("mode", "omr"), actCb(new MainActivity$$ExternalSyntheticLambda35(this)));
    }

    private void clearLogin() {
        Api.token = null;
        this.prefs.edit().remove("token").remove("uid").remove("name").remove("email").remove("role").apply();
    }

    private String clock(int i) {
        int max = Math.max(0, i);
        int i2 = max / 3600;
        int i3 = (max % 3600) / 60;
        int i4 = max % 60;
        Locale locale = Locale.US;
        return i2 > 0 ? String.format(locale, "%d:%02d:%02d", Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf(i4)) : String.format(locale, "%02d:%02d", Integer.valueOf(i3), Integer.valueOf(i4));
    }

    private byte[] compress(Uri uri) throws Exception {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream openInputStream = getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(openInputStream, null, options);
        openInputStream.close();
        int i = 1;
        while (Math.max(options.outWidth, options.outHeight) / i > 3200) {
            i *= 2;
        }
        BitmapFactory.Options options2 = new BitmapFactory.Options();
        options2.inSampleSize = i;
        InputStream openInputStream2 = getContentResolver().openInputStream(uri);
        Bitmap decodeStream = BitmapFactory.decodeStream(openInputStream2, null, options2);
        openInputStream2.close();
        if (decodeStream == null) {
            throw new Exception("decode failed");
        }
        int i2 = 0;
        try {
            InputStream openInputStream3 = getContentResolver().openInputStream(uri);
            int attributeInt = new ExifInterface(openInputStream3).getAttributeInt("Orientation", 1);
            openInputStream3.close();
            if (attributeInt == 6) {
                i2 = 90;
            } else if (attributeInt == 3) {
                i2 = 180;
            } else if (attributeInt == 8) {
                i2 = 270;
            }
        } catch (Exception e) {
        }
        int i3 = i2;
        float min = Math.min(1.0f, 2400.0f / Math.max(decodeStream.getWidth(), decodeStream.getHeight()));
        if (i3 != 0 || min < 1.0f) {
            Matrix matrix = new Matrix();
            if (i3 != 0) {
                matrix.postRotate(i3);
            }
            if (min < 1.0f) {
                matrix.postScale(min, min);
            }
            decodeStream = Bitmap.createBitmap(decodeStream, 0, 0, decodeStream.getWidth(), decodeStream.getHeight(), matrix, true);
        }
        int i4 = 88;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        decodeStream.compress(Bitmap.CompressFormat.JPEG, 88, byteArrayOutputStream);
        while (byteArrayOutputStream.size() > 7340032 && i4 > 40) {
            i4 -= 15;
            byteArrayOutputStream.reset();
            decodeStream.compress(Bitmap.CompressFormat.JPEG, i4, byteArrayOutputStream);
        }
        return byteArrayOutputStream.toByteArray();
    }

    private void confirm(String str, String str2, Runnable runnable) {
        new AlertDialog.Builder(this).setTitle(str).setMessage(str2).setPositiveButton("হ্যাঁ", new MainActivity$$ExternalSyntheticLambda37(runnable)).setNegativeButton("না", (DialogInterface.OnClickListener) null).show();
    }

    private int dp(float f) {
        return Ui.dp(this, f);
    }

    private void errorPage(String str, Runnable runnable) {
        LinearLayout pageBox = pageBox();
        pageBox.setGravity(1);
        pageBox.setPadding(dp(24.0f), dp(60.0f), dp(24.0f), dp(24.0f));
        TextView tv = Ui.tv(this, str, 16.0f, 0xFFD6393F, false);
        tv.setGravity(17);
        Ui.add(pageBox, tv, 16);
        if (runnable != null) {
            Ui.add(pageBox, Ui.primary(this, "আবার চেষ্টা করো", new MainActivity$$ExternalSyntheticLambda70(runnable)));
        }
        setPage(pageBox);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    private View examCard(JSONObject jSONObject) {
        char c;
        int i;
        int optInt = jSONObject.optInt("id");
        String optString = jSONObject.optString("state");
        String optString2 = jSONObject.optString("mode", "online");
        String str = str(jSONObject, "choice");
        LinearLayout card = Ui.card(this);
        Ui.add(card, Ui.tv(this, jSONObject.optString("title"), 17.0f, 0xFF17153B, true), 4);
        String str2 = jSONObject.optInt("questions") + " টি প্রশ্ন · " + Math.max(1, jSONObject.optInt("time_limit_seconds") / 60) + " মিনিট · " + ("omr".equals(optString2) ? "OMR" : "both".equals(optString2) ? "অনলাইন বা OMR" : "অনলাইন");
        if (!str(jSONObject, "batch_name").isEmpty()) {
            str2 = str2 + "\n" + jSONObject.optString("batch_name");
        }
        if (!str(jSONObject, "end_time").isEmpty()) {
            str2 = str2 + "\nশেষ সময়: " + when(jSONObject.optString("end_time"));
        }
        Ui.add(card, Ui.tv(this, str2, 13.0f, 0xFF55527A, false), 8);
        switch (optString.hashCode()) {
            case -1357520532:
                if (optString.equals("closed")) {
                    c = 6;
                    break;
                }
                c = 65535;
                break;
            case -1309235419:
                if (optString.equals("expired")) {
                    c = 7;
                    break;
                }
                c = 65535;
                break;
            case -1097452790:
                if (optString.equals("locked")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case -753541113:
                if (optString.equals("in_progress")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case 110164:
                if (optString.equals("omr")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case 3089282:
                if (optString.equals("done")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case 3417674:
                if (optString.equals("open")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case 1306691868:
                if (optString.equals("upcoming")) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                if ("online".equals(optString2)) {
                    i = 0;
                } else {
                    if (!"online".equals(str)) {
                        if ("both".equals(optString2)) {
                            Ui.add(card, Ui.tv(this, "একবার বেছে নিলে আর বদলানো যাবে না।", 12.0f, 0xFFB7791F, false), 6);
                            Ui.add(card, Ui.primary(this, "অনলাইনে দেবো", new MainActivity$$ExternalSyntheticLambda46(this, optInt)), 6);
                        }
                        Ui.add(card, Ui.secondary(this, "OMR-এ দেবো", new MainActivity$$ExternalSyntheticLambda47(this, optInt)), 0);
                        return card;
                    }
                    i = 0;
                }
                Ui.add(card, Ui.primary(this, "পরীক্ষা শুরু করো", new MainActivity$$ExternalSyntheticLambda45(this, optInt)), i);
                return card;
            case 1:
                Ui.add(card, Ui.tv(this, "পরীক্ষা চলছে — বাকি " + clock(jSONObject.optInt("remaining_seconds")), 13.0f, 0xFFB7791F, true), 6);
                Ui.add(card, Ui.primary(this, "চালিয়ে যাও", new MainActivity$$ExternalSyntheticLambda48(this, optInt)), 0);
                return card;
            case 2:
                String str3 = str(jSONObject, "omr_submission");
                Ui.add(card, Ui.tv(this, "published".equals(str3) ? "ফলাফল প্রকাশিত" : "uploaded".equals(str3) ? "OMR শিট জমা হয়েছে — স্ক্যানের অপেক্ষায়" : "error".equals(str3) ? "শিটে সমস্যা পাওয়া গেছে — আবার ছবি তুলে জমা দাও" : "তুমি OMR-এ পরীক্ষা দিচ্ছো। উত্তর OMR শিটে দিয়ে ছবি জমা দাও।", 13.0f, 0xFF4A3FD1, true), 8);
                Ui.add(card, Ui.secondary(this, "প্রশ্নপত্র দেখো", new MainActivity$$ExternalSyntheticLambda49(this, optInt)), 6);
                if (!"published".equals(str3)) {
                    Ui.add(card, Ui.primary(this, "📷 OMR শিটের ছবি জমা দাও", new MainActivity$$ExternalSyntheticLambda50(this, optInt)), 0);
                }
                return card;
            case 3:
                JSONObject optJSONObject = jSONObject.optJSONObject("result");
                if (optJSONObject != null) {
                    Ui.add(card, Ui.tv(this, "✅ নম্বর: " + num(optJSONObject.optDouble("marks")) + " / " + num(optJSONObject.optDouble("max_marks")) + "\nসঠিক " + optJSONObject.optInt("right") + " · ভুল " + optJSONObject.optInt("wrong") + " · বাদ " + optJSONObject.optInt("skipped") + "\nর\u200d্যাঙ্ক: " + optJSONObject.optInt("rank") + " / " + optJSONObject.optInt("participants"), 14.0f, 0xFF0B8A63, true), 8);
                    Ui.add(card, Ui.secondary(this, "উত্তর ও ব্যাখ্যা দেখো", new MainActivity$$ExternalSyntheticLambda51(this, optJSONObject.optInt("result_id"), "published".equals(str(jSONObject, "omr_submission")))), 0);
                } else {
                    Ui.add(card, Ui.tv(this, jSONObject.optBoolean("result_hidden") ? str(jSONObject, "result_note") : "তোমার উত্তর জমা হয়েছে।", 13.0f, 0xFF4A3FD1, true), 0);
                }
                return card;
            case 4:
                Ui.add(card, Ui.tv(this, "⏳ এখনো শুরু হয়নি" + (str(jSONObject, "start_time").isEmpty() ? "" : " — শুরু: " + when(jSONObject.optString("start_time"))), 13.0f, 0xFFB7791F, true), 0);
                return card;
            case 5:
                Ui.add(card, Ui.tv(this, "🔒 এই পরীক্ষা তোমার ব্যাচের নয়।", 13.0f, 0xFF55527A, false), 6);
                Ui.add(card, Ui.secondary(this, "ব্যাচে যোগ দাও", new MainActivity$$ExternalSyntheticLambda52(this)), 0);
                return card;
            case 6:
                Ui.add(card, Ui.tv(this, "সময়সীমা শেষ।", 13.0f, 0xFF55527A, true), 0);
                return card;
            case 7:
                Ui.add(card, Ui.tv(this, "সময় শেষ হয়ে গেছে, উত্তর জমা হয়নি।", 13.0f, 0xFFD6393F, true), 0);
                return card;
            default:
                Ui.add(card, Ui.tv(this, "এখনও প্রশ্ন যোগ করা হয়নি।", 13.0f, 0xFF55527A, false), 0);
                return card;
        }
    }

    private static String fmtUtc(String str) {
        try {
            String replace = str.replace(' ', 'T');
            if (replace.length() > 19) {
                replace = replace.substring(0, 19);
            }
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            return new SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(simpleDateFormat.parse(replace));
        } catch (Exception e) {
            return str;
        }
    }

    private void hideBusy() {
        if (this.busyDialog != null) {
            try {
                this.busyDialog.dismiss();
            } catch (Exception e) {
            }
            this.busyDialog = null;
        }
    }

    private static JSONObject json(Object... objArr) {
        JSONObject jSONObject = new JSONObject();
        for (int i = 0; i + 1 < objArr.length; i += 2) {
            try {
                jSONObject.put((String) objArr[i], objArr[i + 1]);
            } catch (Exception e) {
            }
        }
        return jSONObject;
    }

    private /* synthetic */ void lambda$buildChrome$2(View view) {
        onBackPressed();
    }

    private /* synthetic */ void lambda$buildChrome$3(View view) {
        if (this.refreshAction != null) {
            this.refreshAction.run();
        }
    }

    private /* synthetic */ void lambda$buildChrome$4(String str, View view) {
        showMain(str);
    }

    private /* synthetic */ void lambda$chooseOmr$28(JSONObject jSONObject) throws Exception {
        showMain("exams");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$confirm$0(Runnable runnable, DialogInterface dialogInterface, int i) {
        runnable.run();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$errorPage$5(Runnable runnable, View view) {
        runnable.run();
    }

    private /* synthetic */ void lambda$examCard$17(int i) {
        startLive(i);
    }

    private /* synthetic */ void lambda$examCard$18(int i, View view) {
        confirm("পরীক্ষা শুরু করবে?", "শুরু করলে সময় চলতে থাকবে।", new MainActivity$$ExternalSyntheticLambda42(this, i));
    }

    private /* synthetic */ void lambda$examCard$19(int i) {
        startLive(i);
    }

    private /* synthetic */ void lambda$examCard$20(int i, View view) {
        confirm("অনলাইনে পরীক্ষা দেবে?", "এই পরীক্ষা অনলাইনেই দিতে হবে, OMR-এ নয়।", new MainActivity$$ExternalSyntheticLambda3(this, i));
    }

    private /* synthetic */ void lambda$examCard$21(int i) {
        chooseOmr(i);
    }

    private /* synthetic */ void lambda$examCard$22(int i, View view) {
        confirm("OMR-এ পরীক্ষা দেবে?", "উত্তর কাগজের OMR শিটে দিয়ে ছবি তুলে জমা দিতে হবে।", new MainActivity$$ExternalSyntheticLambda18(this, i));
    }

    private /* synthetic */ void lambda$examCard$23(int i, View view) {
        startLive(i);
    }

    private /* synthetic */ void lambda$examCard$24(int i, View view) {
        showPaper(i);
    }

    private /* synthetic */ void lambda$examCard$25(int i, View view) {
        pickOmrImage(i);
    }

    private /* synthetic */ void lambda$examCard$26(int i, boolean z, View view) {
        openReview(i, z);
    }

    private /* synthetic */ void lambda$examCard$27(View view) {
        showMain("batches");
    }

    private /* synthetic */ void lambda$loadBatches$44(JSONObject jSONObject) throws Exception {
        toast(jSONObject.optString("message", "যুক্ত হয়েছো"));
        showMain("batches");
    }

    private /* synthetic */ void lambda$loadBatches$45(double d, int i, View view) {
        if (d > 0.0d) {
            paymentDialog(i);
        } else {
            busy("অপেক্ষা করো…");
            Api.call("POST", "/omr/batches/" + i + "/join", new JSONObject(), actCb(new MainActivity$$ExternalSyntheticLambda0(this)));
        }
    }

    private /* synthetic */ void lambda$loadBatches$46(JSONObject jSONObject) throws Exception {
        JSONArray jSONArray;
        boolean z;
        LinearLayout pageBox = pageBox();
        JSONArray arr = arr(jSONObject, "batches");
        boolean z2 = false;
        if (arr.length() == 0) {
            Ui.add(pageBox, Ui.tv(this, "এখনও কোনো ব্যাচ নেই।", 15.0f, 0xFF55527A, false));
        }
        int i = 0;
        while (i < arr.length()) {
            JSONObject at = at(arr, i);
            int optInt = at.optInt("id");
            double optDouble = at.optDouble("price");
            String optString = at.optString("state");
            LinearLayout card = Ui.card(this);
            Ui.add(card, Ui.tv(this, at.optString("name"), 17.0f, 0xFF17153B, true), 3);
            Ui.add(card, Ui.tv(this, at.optInt("exams") + " টি পরীক্ষা · " + (optDouble > 0.0d ? "৳" + num(optDouble) : "ফ্রি"), 13.0f, 0xFF55527A, z2), 8);
            if ("active".equals(optString)) {
                Ui.add(card, Ui.tv(this, "✅ তুমি এই ব্যাচে আছো", 14.0f, 0xFF0B8A63, true), 4);
                JSONArray arr2 = arr(at, "exam_list");
                int i2 = 0;
                while (i2 < arr2.length()) {
                    Ui.add(card, Ui.tv(this, "• " + at(arr2, i2).optString("title"), 13.0f, 0xFF17153B, false), 2);
                    i2++;
                    arr = arr;
                }
                jSONArray = arr;
                z = false;
            } else {
                jSONArray = arr;
                if ("pending".equals(optString)) {
                    z = false;
                    Ui.add(card, Ui.tv(this, "⏳ পেমেন্ট অ্যাডমিনের অনুমোদনের অপেক্ষায় আছে।", 13.0f, 0xFFB7791F, true), 0);
                } else {
                    if ("rejected".equals(optString)) {
                        Ui.add(card, Ui.tv(this, "আগের পেমেন্ট গ্রহণ করা হয়নি। আবার চেষ্টা করো।", 13.0f, 0xFFD6393F, true), 6);
                    }
                    z = false;
                    Ui.add(card, Ui.primary(this, optDouble > 0.0d ? "যোগ দাও (পেমেন্ট)" : "যোগ দাও", new MainActivity$$ExternalSyntheticLambda21(this, optDouble, optInt)), 0);
                }
            }
            Ui.add(pageBox, card, 12);
            i++;
            z2 = z;
            arr = jSONArray;
        }
        setPage(pageBox);
    }

    private /* synthetic */ void lambda$loadDashboard$43(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        LinearLayout card = Ui.card(this);
        int i = 0xFF17153B;
        Ui.add(card, Ui.tv(this, "তোমার অগ্রগতি", 17.0f, 0xFF17153B, true), 6);
        float f = 15.0f;
        Ui.add(card, Ui.tv(this, "পরীক্ষা দিয়েছো: " + jSONObject.optInt("exams_completed"), 15.0f, 0xFF4A3FD1, true), 4);
        Ui.add(card, Ui.tv(this, jSONObject.optBoolean("adaptive_ready") ? "🧠 Adaptive Exam প্রস্তুত — 'প্র্যাকটিস' ট্যাবে যাও।" : "Adaptive Exam পেতে আরও " + jSONObject.optInt("exams_needed") + " টি পরীক্ষা দাও।", 13.0f, 0xFF55527A, false), 0);
        Ui.add(pageBox, card, 14);
        JSONArray arr = arr(jSONObject, "topic_performance");
        if (arr.length() == 0) {
            Ui.add(pageBox, Ui.tv(this, "এখনও কোনো ফলাফল নেই। পরীক্ষা দিলে এখানে দেখা যাবে।", 14.0f, 0xFF55527A, false));
        }
        int i2 = 0;
        while (i2 < arr.length()) {
            JSONObject at = at(arr, i2);
            String optString = at.optString("level");
            int i3 = "strong".equals(optString) ? 0xFF0B8A63 : "weak".equals(optString) ? 0xFFD6393F : 0xFFB7791F;
            String str = "strong".equals(optString) ? "ভালো" : "weak".equals(optString) ? "দুর্বল" : "উন্নতি দরকার";
            LinearLayout card2 = Ui.card(this);
            Ui.add(card2, Ui.tv(this, at.optString("topic_name"), f, i, true), 2);
            Ui.add(card2, Ui.tv(this, "সঠিক " + at.optInt("correct_count") + " / " + at.optInt("total_attempts") + " · " + Math.round(at.optDouble("accuracy") * 100.0d) + "% · " + str, 13.0f, i3, true), 8);
            Ui.add(card2, Ui.bar(this, at.optDouble("accuracy"), i3), 0);
            Ui.add(pageBox, card2, 10);
            i2++;
            i = 0xFF17153B;
            f = 15.0f;
        }
        setPage(pageBox);
    }

    private /* synthetic */ void lambda$loadExams$16(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        JSONArray arr = arr(jSONObject, "exams");
        if (arr.length() == 0) {
            Ui.add(pageBox, Ui.tv(this, "এখন কোনো পরীক্ষা নেই। 'ব্যাচ' ট্যাব থেকে ব্যাচে যোগ দাও।", 15.0f, 0xFF55527A, false));
        }
        for (int i = 0; i < arr.length(); i++) {
            Ui.add(pageBox, examCard(at(arr, i)), 12);
        }
        setPage(pageBox);
    }

    private /* synthetic */ void lambda$loadPractice$38(View view) {
        busy("প্রশ্ন তৈরি হচ্ছে…");
        Api.call("POST", "/exam/generate", json("count", 10), actCb(new MainActivity$$ExternalSyntheticLambda34(this)));
    }

    private /* synthetic */ void lambda$loadPractice$39(View view) {
        busy("তোমার জন্য প্রশ্ন তৈরি হচ্ছে… একটু সময় লাগতে পারে।");
        Api.call("POST", "/exam/generate-adaptive", null, actCb(new MainActivity$$ExternalSyntheticLambda34(this)));
    }

    private /* synthetic */ void lambda$loadPractice$40(JSONObject jSONObject, View view) {
        busy("প্রশ্ন তৈরি হচ্ছে…");
        Api.call("POST", "/exam/generate", json("panel_exam_id", Integer.valueOf(jSONObject.optInt("id"))), actCb(new MainActivity$$ExternalSyntheticLambda34(this)));
    }

    private /* synthetic */ void lambda$loadPractice$41(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        LinearLayout card = Ui.card(this);
        Ui.add(card, Ui.tv(this, "প্র্যাকটিস করো", 17.0f, 0xFF17153B, true), 4);
        float f = 13.0f;
        Ui.add(card, Ui.tv(this, "তোমার ব্যাচের শেষ হওয়া পরীক্ষার প্রশ্ন থেকে অনুশীলন। ৫টি পরীক্ষা দিলে দুর্বল জায়গার উপর Adaptive Exam পাবে।", 13.0f, 0xFF55527A, false), 10);
        Ui.add(card, Ui.primary(this, "র\u200d্যান্ডম প্র্যাকটিস (১০টি প্রশ্ন)", new MainActivity$$ExternalSyntheticLambda39(this)), 8);
        Ui.add(card, Ui.secondary(this, "🧠 Adaptive Exam (দুর্বল জায়গা)", new MainActivity$$ExternalSyntheticLambda40(this)), 0);
        Ui.add(pageBox, card, 14);
        JSONArray arr = arr(jSONObject, "exams");
        int i = 0;
        while (i < arr.length()) {
            JSONObject at = at(arr, i);
            LinearLayout card2 = Ui.card(this);
            Ui.add(card2, Ui.tv(this, at.optString("title"), 16.0f, 0xFF17153B, true), 3);
            Ui.add(card2, Ui.tv(this, at.optInt("questions") + " টি প্রশ্ন · " + str(at, "batch_name") + (at.optBoolean("participated") ? " · ✅ পরীক্ষা দিয়েছো" : ""), f, 0xFF55527A, false), 8);
            if (at.optBoolean("practice_open")) {
                Ui.add(card2, Ui.secondary(this, "এই পরীক্ষা প্র্যাকটিস করো", new MainActivity$$ExternalSyntheticLambda41(this, at)), 0);
            } else {
                Ui.add(card2, Ui.tv(this, "পরীক্ষা শেষ হলে প্র্যাকটিস খুলবে।", 12.0f, 0xFFB7791F, false), 0);
            }
            Ui.add(pageBox, card2, 10);
            i++;
            f = 13.0f;
        }
        setPage(pageBox);
    }

    private /* synthetic */ void lambda$onCreate$1() {
        clearLogin();
        toast("আবার লগইন করো।");
        route();
    }

    private /* synthetic */ void lambda$openLive$29(int i, JSONArray jSONArray, Runnable runnable) {
        Api.call("POST", "/online/exams/" + i + "/submit", json("answers", jSONArray), new AnonymousClass5(runnable));
    }

    private /* synthetic */ void lambda$openPractice$42(int i, JSONArray jSONArray, JSONArray jSONArray2, Runnable runnable) {
        Api.call("POST", "/exam/" + i + "/submit", json("answers", jSONArray2), new AnonymousClass6(jSONArray, runnable));
    }

    private /* synthetic */ void lambda$openReview$34(JSONObject jSONObject) throws Exception {
        showResult("ফলাফল", jSONObject, arr(jSONObject, "results"));
    }

    private /* synthetic */ void lambda$openReview$35(JSONObject jSONObject) throws Exception {
        JSONArray arr = arr(jSONObject, "answers");
        JSONArray jSONArray = new JSONArray();
        Object[] objArr = {"a", "b", "c", "d"};
        for (int i = 0; i < arr.length(); i++) {
            JSONObject at = at(arr, i);
            int optInt = at.isNull("selected_option") ? 0 : at.optInt("selected_option");
            int optInt2 = at.optInt("correct_option");
            jSONArray.put(json("question_text", at.optString("question"), "options", json("a", at.optString("option1"), "b", at.optString("option2"), "c", at.optString("option3"), "d", at.optString("option4")), "your_answer", (optInt < 1 || optInt > 4) ? JSONObject.NULL : objArr[optInt - 1], "correct_answer", (optInt2 < 1 || optInt2 > 4) ? "" : objArr[optInt2 - 1], "is_correct", Boolean.valueOf(optInt == optInt2 && optInt != 0), "explanation", ""));
        }
        showResult("ফলাফল", new JSONObject(), jSONArray);
    }

    private /* synthetic */ void lambda$paymentDialog$47(JSONObject jSONObject) throws Exception {
        toast(jSONObject.optString("message", "জমা হয়েছে"));
        showMain("batches");
    }

    private /* synthetic */ void lambda$paymentDialog$48(int i, EditText editText, EditText editText2, EditText editText3, DialogInterface dialogInterface, int i2) {
        busy("অপেক্ষা করো…");
        Api.call("POST", "/omr/batches/" + i + "/join", json("method", editText.getText().toString(), "sender_number", editText2.getText().toString(), "transaction_id", editText3.getText().toString()), actCb(new MainActivity$$ExternalSyntheticLambda36(this)));
    }

    private /* synthetic */ void lambda$pickOmrImage$64(DialogInterface dialogInterface, int i) {
        if (i != 0) {
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            startActivityForResult(Intent.createChooser(intent, "ছবি বেছে নাও"), 22);
        } else if (checkSelfPermission("android.permission.CAMERA") == 0) {
            launchCamera();
        } else {
            requestPermissions(new String[]{"android.permission.CAMERA"}, 24);
        }
    }

    private /* synthetic */ void lambda$showAdminNote$12(View view) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(Api.base + "/admin")));
    }

    private /* synthetic */ void lambda$showAdminNote$13(View view) {
        clearLogin();
        route();
    }

    private /* synthetic */ void lambda$showAuth$10(boolean z, View view) {
        showAuth(!z);
    }

    private /* synthetic */ void lambda$showAuth$11(View view) {
        showServerSetup(false);
    }

    private /* synthetic */ void lambda$showAuth$8(JSONObject jSONObject) throws Exception {
        saveLogin(jSONObject);
        this.tab = "exams";
        route();
    }

    private /* synthetic */ void lambda$showAuth$9(EditText editText, EditText editText2, EditText editText3, boolean z, View view) {
        String trim = editText.getText().toString().trim();
        String obj = editText2.getText().toString();
        String trim2 = editText3.getText().toString().trim();
        if (trim.isEmpty() || obj.isEmpty() || (z && trim2.isEmpty())) {
            showError("সব ঘর পূরণ করো।");
        } else {
            busy("অপেক্ষা করো…");
            Api.call("POST", z ? "/auth/register" : "/auth/login", z ? json("name", trim2, "email", trim, "password", obj) : json("email", trim, "password", obj), actCb(new MainActivity$$ExternalSyntheticLambda28(this)));
        }
    }

    private /* synthetic */ void lambda$showFace$57() {
        showMain("more");
    }

    private /* synthetic */ void lambda$showFace$58(CheckBox checkBox, View view) {
        if (checkBox.isChecked()) {
            startFace("enroll", 0, new MainActivity$$ExternalSyntheticLambda22(this));
        } else {
            showError("আগে সম্মতির বক্সে টিক দাও।");
        }
    }

    private /* synthetic */ void lambda$showFace$59(View view) {
        startFace("verify", 0, new MainActivity$$ExternalSyntheticLambda22(this));
    }

    private /* synthetic */ void lambda$showFace$60(JSONObject jSONObject) throws Exception {
        showFace();
    }

    private /* synthetic */ void lambda$showFace$61() {
        busy("অপেক্ষা করো…");
        Api.call("DELETE", "/face/me", null, actCb(new MainActivity$$ExternalSyntheticLambda14(this)));
    }

    private /* synthetic */ void lambda$showFace$62(View view) {
        confirm("ছেড়ে দেবে?", "তোমার ছবি ও ফেস ডেটা মুছে যাবে।", new MainActivity$$ExternalSyntheticLambda19(this));
    }

    private /* synthetic */ void lambda$showFace$63(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        boolean optBoolean = jSONObject.optBoolean("enrolled");
        boolean z = optBoolean && "approved".equals(jSONObject.optString("status"));
        LinearLayout card = Ui.card(this);
        Ui.add(card, Ui.tv(this, !optBoolean ? "তুমি এখনও পার্সোনাল কেয়ারে যুক্ত নও।" : z ? "✅ তুমি পার্সোনাল কেয়ারে যুক্ত আছো।" : "⏳ আবেদন জমা হয়েছে — অ্যাডমিনের অনুমোদনের অপেক্ষায়।", 15.0f, 0xFF17153B, true), 8);
        String str = str(jSONObject, "photo");
        if (str.contains(",")) {
            try {
                byte[] decode = Base64.decode(str.substring(str.indexOf(44) + 1), 0);
                ImageView imageView = new ImageView(this);
                imageView.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(96.0f), dp(96.0f));
                layoutParams.bottomMargin = dp(10.0f);
                card.addView(imageView, layoutParams);
            } catch (Exception e) {
            }
        }
        if (optBoolean) {
            if (z) {
                Ui.add(card, Ui.primary(this, "📷 হাজিরা দাও", new MainActivity$$ExternalSyntheticLambda59(this)), 8);
            }
            Ui.add(card, Ui.btn(this, "পার্সোনাল কেয়ার ছেড়ে দাও", 0xFFFFE1DC, 0xFFD6393F, new MainActivity$$ExternalSyntheticLambda60(this)), 0);
        } else {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText("আমি ফেস ডেটা সংরক্ষণে সম্মতি দিচ্ছি।");
            checkBox.setTextColor(0xFF17153B);
            Ui.add(card, checkBox, 8);
            Ui.add(card, Ui.primary(this, "ক্যামেরায় যুক্ত হও", new MainActivity$$ExternalSyntheticLambda58(this, checkBox)), 0);
        }
        Ui.add(pageBox, card, 14);
        JSONArray arr = arr(jSONObject, "recent");
        if (arr.length() > 0) {
            Ui.add(pageBox, Ui.tv(this, "সাম্প্রতিক হাজিরা", 15.0f, 0xFF17153B, true), 8);
        }
        for (int i = 0; i < arr.length(); i++) {
            JSONObject at = at(arr, i);
            Ui.add(pageBox, Ui.tv(this, ("exam".equals(at.optString("kind")) ? "📝 " + str(at, "title") : "🏫 হাজিরা") + " — " + fmtUtc(at.optString("marked_at")), 13.0f, 0xFF55527A, false), 4);
        }
        setPage(pageBox);
    }

    private /* synthetic */ void lambda$showLeaderboard$55() {
        showMain("more");
    }

    private /* synthetic */ void lambda$showLeaderboard$56(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        JSONArray arr = arr(jSONObject, "leaderboard");
        int i = this.prefs.getInt("uid", -1);
        float f = 14.0f;
        boolean z = false;
        if (arr.length() == 0) {
            Ui.add(pageBox, Ui.tv(this, "এখনও কেউ লিডারবোর্ডে নেই (কমপক্ষে ৩টি প্র্যাকটিস exam লাগে)।", 14.0f, 0xFF55527A, false));
        }
        int i2 = 0;
        while (i2 < arr.length()) {
            JSONObject at = at(arr, i2);
            boolean z2 = at.optInt("student_id") == i ? true : z;
            LinearLayout hbox = Ui.hbox(this);
            hbox.setPadding(dp(f), dp(12.0f), dp(f), dp(12.0f));
            hbox.setBackground(Ui.box(this, z2 ? 0xFFE4E1FF : -1, z2 ? 0xFF4A3FD1 : 0xFFE2DFF3, 12.0f));
            TextView tv = Ui.tv(this, i2 == 0 ? "🥇" : i2 == 1 ? "🥈" : i2 == 2 ? "🥉" : String.valueOf(i2 + 1), 18.0f, 0xFF17153B, true);
            tv.setMinWidth(dp(40.0f));
            hbox.addView(tv);
            LinearLayout vbox = Ui.vbox(this);
            vbox.addView(Ui.tv(this, at.optString("name"), 15.0f, 0xFF17153B, true));
            vbox.addView(Ui.tv(this, at.optInt("exams_completed") + " টি পরীক্ষা", 12.0f, 0xFF55527A, false));
            hbox.addView(vbox, new LinearLayout.LayoutParams(0, -2, 1.0f));
            hbox.addView(Ui.tv(this, num(at.optDouble("avg_score")) + "%", 17.0f, 0xFF4A3FD1, true));
            Ui.add(pageBox, hbox, 8);
            i2++;
            f = 14.0f;
            z = false;
        }
        setPage(pageBox);
    }

    private /* synthetic */ void lambda$showMain$14(String str) {
        showMain(str);
    }

    private /* synthetic */ void lambda$showMain$15(String str) {
        showMain(str);
    }

    private /* synthetic */ void lambda$showMore$49(View view) {
        showLeaderboard();
    }

    private /* synthetic */ void lambda$showMore$50(View view) {
        showFace();
    }

    private /* synthetic */ void lambda$showMore$51() {
        showServerSetup(true);
    }

    private /* synthetic */ void lambda$showMore$52(View view) {
        confirm("সার্ভার বদলাবে?", "ঠিকানা বদলালে তোমাকে আবার লগইন করতে হবে।", new MainActivity$$ExternalSyntheticLambda8(this));
    }

    private /* synthetic */ void lambda$showMore$53() {
        clearLogin();
        route();
    }

    private /* synthetic */ void lambda$showMore$54(View view) {
        confirm("লগআউট করবে?", "", new MainActivity$$ExternalSyntheticLambda13(this));
    }

    private /* synthetic */ void lambda$showPaper$32(String str) {
        showMain(str);
    }

    private /* synthetic */ void lambda$showPaper$33(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        JSONArray arr = arr(jSONObject, "questions");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject at = at(arr, i);
            JSONObject optJSONObject = at.optJSONObject("options");
            if (optJSONObject == null) {
                optJSONObject = new JSONObject();
            }
            LinearLayout card = Ui.card(this);
            Ui.add(card, Ui.tv(this, at.optInt("no") + ". " + at.optString("question"), 16.0f, 0xFF17153B, true), 6);
            String[] strArr = {"a", "b", "c", "d"};
            int i2 = 0;
            for (int i3 = 4; i2 < i3; i3 = 4) {
                String str = strArr[i2];
                Ui.add(card, Ui.tv(this, str.toUpperCase() + ".  " + optJSONObject.optString(str), 15.0f, 0xFF17153B, false), 3);
                i2++;
            }
            Ui.add(pageBox, card, 10);
        }
        setScreen(jSONObject.optString("title", "প্রশ্নপত্র"), scroll(pageBox), false, new MainActivity$$ExternalSyntheticLambda68(this, this.tab), null);
    }

    private /* synthetic */ void lambda$showReceipt$30(View view) {
        showMain("exams");
    }

    private /* synthetic */ void lambda$showReceipt$31() {
        showMain("exams");
    }

    private /* synthetic */ void lambda$showResult$36(View view) {
        showMain(this.tab);
    }

    private /* synthetic */ void lambda$showResult$37() {
        showMain(this.tab);
    }

    private /* synthetic */ void lambda$showServerSetup$6(EditText editText, View view) {
        String trim = editText.getText().toString().trim();
        if (trim.isEmpty()) {
            showError("ঠিকানা লেখো।");
            return;
        }
        if (!trim.matches("(?i)^https?://.*")) {
            trim = "https://" + trim;
        }
        while (trim.endsWith("/")) {
            trim = trim.substring(0, trim.length() - 1);
        }
        String str = trim;
        String str2 = Api.base;
        busy("সংযোগ পরীক্ষা হচ্ছে…");
        Api.base = str;
        Api.call("GET", "/public/home", null, new AnonymousClass3(str, str2));
    }

    private /* synthetic */ void lambda$showServerSetup$7() {
        showMain("more");
    }

    private /* synthetic */ void lambda$uploadOmr$65() {
        showError("ছবিটি পড়া যায়নি। আবার চেষ্টা করো।");
    }

    private /* synthetic */ void lambda$uploadOmr$66(JSONObject jSONObject) throws Exception {
        toast(jSONObject.optString("message", "OMR শিট জমা হয়েছে।"));
        showMain("exams");
    }

    private /* synthetic */ void lambda$uploadOmr$67(Uri uri, int i) {
        try {
            Api.upload("/omr/exams/" + i + "/submission", compress(uri), "image/jpeg", actCb(new MainActivity$$ExternalSyntheticLambda32(this)));
        } catch (Exception e) {
            runOnUiThread(new MainActivity$$ExternalSyntheticLambda31(this));
        }
    }

    private void launchCamera() {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", "omr_" + System.currentTimeMillis() + ".jpg");
            contentValues.put("mime_type", "image/jpeg");
            contentValues.put("relative_path", "Pictures/ProttashaOMR");
            this.camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            intent.putExtra("output", this.camUri);
            startActivityForResult(intent, 21);
        } catch (Exception e) {
            showError("ক্যামেরা খোলা যায়নি। গ্যালারি থেকে ছবি নাও।");
        }
    }

    private void loadBatches(Runnable runnable) {
        Api.call("GET", "/omr/batches", null, pageCb(new MainActivity$$ExternalSyntheticLambda67(this), runnable));
    }

    private void loadDashboard(Runnable runnable) {
        Api.call("GET", "/exam/performance", null, pageCb(new MainActivity$$ExternalSyntheticLambda20(this), runnable));
    }

    private void loadExams(Runnable runnable) {
        Api.call("GET", "/online/exams", null, pageCb(new MainActivity$$ExternalSyntheticLambda69(this), runnable));
    }

    private void loadPractice(Runnable runnable) {
        Api.call("GET", "/exam/practice-exams", null, pageCb(new MainActivity$$ExternalSyntheticLambda65(this), runnable));
    }

    private static String num(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.format(Locale.US, "%.2f", Double.valueOf(d));
    }

    private void openLive(JSONObject jSONObject) {
        new ExamSession(jSONObject.optString("title"), arr(jSONObject, "questions"), jSONObject.optInt("remaining_seconds", -1), new MainActivity$$ExternalSyntheticLambda43(this, jSONObject.optInt("exam_id"))).show();
    }

    private void openPractice(JSONObject jSONObject) {
        JSONArray arr = arr(jSONObject, "questions");
        if (arr.length() == 0) {
            showError(str(jSONObject, "message").isEmpty() ? "এখন কোনো প্রশ্ন পাওয়া যায়নি।" : jSONObject.optString("message"));
            return;
        }
        int optInt = jSONObject.optInt("exam_id");
        str(jSONObject, "message").isEmpty();
        new ExamSession("প্র্যাকটিস", arr, -1, new MainActivity$$ExternalSyntheticLambda4(this, optInt, arr)).show();
    }

    private void openReview(int i, boolean z) {
        busy("লোড হচ্ছে…");
        if (z) {
            Api.call("GET", "/omr/results/" + i + "/review", null, actCb(new MainActivity$$ExternalSyntheticLambda64(this)));
        } else {
            Api.call("GET", "/online/results/" + i + "/review", null, actCb(new MainActivity$$ExternalSyntheticLambda63(this)));
        }
    }

    private LinearLayout pageBox() {
        LinearLayout vbox = Ui.vbox(this);
        vbox.setPadding(dp(14.0f), dp(14.0f), dp(14.0f), dp(24.0f));
        return vbox;
    }

    private Api.Callback pageCb(Ok ok, Runnable runnable) {
        return new AnonymousClass2(this.screenToken, ok, runnable);
    }

    private void paymentDialog(int i) {
        LinearLayout vbox = Ui.vbox(this);
        vbox.setPadding(dp(18.0f), dp(10.0f), dp(18.0f), dp(0.0f));
        EditText input = Ui.input(this, "পেমেন্ট মাধ্যম (bKash / Nagad…)", 1);
        EditText input2 = Ui.input(this, "যে নম্বর থেকে পাঠিয়েছো", 3);
        EditText input3 = Ui.input(this, "Transaction ID", 1);
        Ui.add(vbox, input, 8);
        Ui.add(vbox, input2, 8);
        Ui.add(vbox, input3, 8);
        new AlertDialog.Builder(this).setTitle("পেমেন্টের তথ্য").setView(vbox).setPositiveButton("জমা দাও", new MainActivity$$ExternalSyntheticLambda15(this, i, input, input2, input3)).setNegativeButton("বাতিল", (DialogInterface.OnClickListener) null).show();
    }

    private void pickOmrImage(int i) {
        this.pendingOmrExam = i;
        new AlertDialog.Builder(this).setTitle("OMR শিটের ছবি").setItems(new String[]{"📷 ক্যামেরায় ছবি তোলো", "🖼 গ্যালারি থেকে নাও"}, new MainActivity$$ExternalSyntheticLambda25(this)).show();
    }

    private void route() {
        if (Api.base == null || Api.base.isEmpty()) {
            showServerSetup(false);
            return;
        }
        if (Api.token == null) {
            showAuth(false);
        } else if ("admin".equals(this.prefs.getString("role", ""))) {
            showAdminNote();
        } else {
            showMain(this.tab);
        }
    }

    private void saveLogin(JSONObject jSONObject) {
        JSONObject optJSONObject = jSONObject.optJSONObject("user");
        if (optJSONObject == null) {
            optJSONObject = new JSONObject();
        }
        Api.token = jSONObject.optString("token");
        this.prefs.edit().putString("token", Api.token).putInt("uid", optJSONObject.optInt("id")).putString("name", optJSONObject.optString("name")).putString("email", optJSONObject.optString("email")).putString("role", optJSONObject.optString("role")).apply();
    }

    private ScrollView scroll(View view) {
        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(view, new FrameLayout.LayoutParams(-1, -2));
        return scrollView;
    }

    private void setContent(View view) {
        this.content.removeAllViews();
        this.content.addView(view, new FrameLayout.LayoutParams(-1, -1));
    }

    private void setPage(LinearLayout linearLayout) {
        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(linearLayout, new FrameLayout.LayoutParams(-1, -2));
        setContent(scrollView);
    }

    private void setScreen(String str, View view, boolean z, Runnable runnable, Runnable runnable2) {
        this.screenToken++;
        stopTimer();
        this.titleView.setText(str);
        this.onBack = runnable;
        this.refreshAction = runnable2;
        this.backBtn.setVisibility(runnable != null ? 0 : 8);
        this.header.setVisibility(0);
        this.nav.setVisibility(z ? 0 : 8);
        setContent(view);
    }

    private void showAdminNote() {
        LinearLayout pageBox = pageBox();
        pageBox.setPadding(dp(20.0f), dp(40.0f), dp(20.0f), dp(20.0f));
        Ui.add(pageBox, Ui.tv(this, "অ্যাডমিন অ্যাকাউন্ট", 22.0f, 0xFF17153B, true), 8);
        Ui.add(pageBox, Ui.tv(this, "এই অ্যাপ শিক্ষার্থীদের জন্য। অ্যাডমিন প্যানেল ব্রাউজারে খোলো।", 15.0f, 0xFF55527A, false), 16);
        Ui.add(pageBox, Ui.primary(this, "অ্যাডমিন প্যানেল খোলো", new MainActivity$$ExternalSyntheticLambda16(this)), 10);
        Ui.add(pageBox, Ui.secondary(this, "লগআউট", new MainActivity$$ExternalSyntheticLambda17(this)), 10);
        setScreen("অ্যাডমিন", scroll(pageBox), false, null, null);
    }

    private void showAuth(boolean z) {
        LinearLayout pageBox = pageBox();
        pageBox.setPadding(dp(20.0f), dp(30.0f), dp(20.0f), dp(20.0f));
        ImageView authLogo = new ImageView(this);
        authLogo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams authLp = new LinearLayout.LayoutParams(dp(96.0f), dp(96.0f));
        authLp.gravity = Gravity.CENTER_HORIZONTAL;
        authLp.bottomMargin = dp(8.0f);
        pageBox.addView(authLogo, authLp);
        TextView authName = Ui.tv(this, "প্রত্যাশা একাডেমি", 26.0f, Ui.INK, true);
        authName.setGravity(Gravity.CENTER);
        Ui.add(pageBox, authName, 2);
        TextView authSub = Ui.tv(this, z ? "নতুন অ্যাকাউন্ট খোলো" : "পরীক্ষা শুরু করতে লগইন করো", 14.0f, Ui.MUTED, false);
        authSub.setGravity(Gravity.CENTER);
        Ui.add(pageBox, authSub, 22);
        EditText input = Ui.input(this, "তোমার নাম", 8193);
        EditText input2 = Ui.input(this, "ইমেইল", 33);
        EditText input3 = Ui.input(this, "পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)", 129);
        if (z) {
            Ui.add(pageBox, input, 10);
        }
        Ui.add(pageBox, input2, 10);
        Ui.add(pageBox, input3, 14);
        Ui.add(pageBox, Ui.primary(this, z ? "অ্যাকাউন্ট খোলো" : "লগইন করো", new MainActivity$$ExternalSyntheticLambda9(this, input2, input3, input, z)), 10);
        Ui.add(pageBox, Ui.secondary(this, z ? "আগে থেকেই অ্যাকাউন্ট আছে? লগইন" : "নতুন? অ্যাকাউন্ট খোলো", new MainActivity$$ExternalSyntheticLambda10(this, z)), 10);
        if (!FIXED_SERVER) {
            Ui.add(pageBox, Ui.btn(this, "সার্ভারের ঠিকানা: " + Api.base, -1, 0xFF55527A, new MainActivity$$ExternalSyntheticLambda12(this)), 10);
        }
        setScreen("Prottasha Academy", scroll(pageBox), false, null, null);
        this.header.setVisibility(8);
    }

    private void showError(String str) {
        hideBusy();
        new AlertDialog.Builder(this).setMessage(str).setPositiveButton("ঠিক আছে", (DialogInterface.OnClickListener) null).show();
    }

    private void showFace() {
        setScreen("ফেস হাজিরা", centered("লোড হচ্ছে…"), false, new MainActivity$$ExternalSyntheticLambda11(this), new MainActivity$$ExternalSyntheticLambda22(this));
        Api.call("GET", "/face/me", null, pageCb(new MainActivity$$ExternalSyntheticLambda33(this), new MainActivity$$ExternalSyntheticLambda22(this)));
    }

    private void showLeaderboard() {
        setScreen("লিডারবোর্ড", centered("লোড হচ্ছে…"), false, new MainActivity$$ExternalSyntheticLambda44(this), new MainActivity$$ExternalSyntheticLambda55(this));
        Api.call("GET", "/exam/leaderboard", null, pageCb(new MainActivity$$ExternalSyntheticLambda66(this), new MainActivity$$ExternalSyntheticLambda55(this)));
    }

    private void showMain(final String t) {
        this.tab = t;
        styleNav(t);
        String title = "Prottasha Academy";
        for (String[] x : TABS) {
            if (x[0].equals(t)) {
                title = x[2];
            }
        }
        Runnable again = new Runnable() {
            @Override
            public void run() {
                showMain(t);
            }
        };
        setScreen(title, centered("লোড হচ্ছে…"), true, null, again);
        if ("home".equals(t)) {
            this.header.setVisibility(8);
            loadHome(again);
        } else if ("exams".equals(t)) {
            loadExams(again);
        } else if ("practice".equals(t)) {
            loadPractice(again);
        } else if ("batches".equals(t)) {
            loadBatches(again);
        } else {
            showMore();
        }
    }

    private void showMore() {
        LinearLayout pageBox = pageBox();
        LinearLayout profile = Ui.vbox(this);
        profile.setBackground(Ui.box(this, Ui.INK, 0, 28.0f));
        profile.setPadding(dp(20.0f), dp(20.0f), dp(20.0f), dp(20.0f));
        String nm = this.prefs.getString("name", "");
        LinearLayout row = Ui.hbox(this);
        String initial = nm.isEmpty() ? "?" : nm.substring(0, nm.offsetByCodePoints(0, 1));
        TextView av = Ui.tv(this, initial, 24.0f, Ui.INK, true);
        av.setGravity(Gravity.CENTER);
        av.setBackground(Ui.box(this, Ui.ACCENT, 0, 20.0f));
        row.addView(av, new LinearLayout.LayoutParams(dp(60.0f), dp(60.0f)));
        LinearLayout who = Ui.vbox(this);
        who.setPadding(dp(14.0f), 0, 0, 0);
        who.addView(Ui.tv(this, nm, 20.0f, -1, true));
        who.addView(Ui.tv(this, this.prefs.getString("email", ""), 13.0f, Ui.ON_INK, false));
        row.addView(who, new LinearLayout.LayoutParams(0, -2, 1.0f));
        profile.addView(row);
        Ui.add(pageBox, profile, 16);
        Ui.add(pageBox, menuRow("ic_rank", "লিডারবোর্ড", "সেরাদের তালিকা দেখো", 0xFFF1E0FF, 0xFF7A2FBF, new MainActivity$$ExternalSyntheticLambda53(this)), 10);
        Ui.add(pageBox, menuRow("ic_face", "ফেস হাজিরা", "পার্সোনাল কেয়ার", 0xFFD6F4F4, 0xFF0B6F73, new MainActivity$$ExternalSyntheticLambda54(this)), 10);
        if (!FIXED_SERVER) {
            Ui.add(pageBox, menuRow("ic_more", "সার্ভারের ঠিকানা", Api.base, 0xFFFFEFC9, 0xFF8A5A00, new MainActivity$$ExternalSyntheticLambda56(this)), 10);
        }
        Ui.add(pageBox, Ui.btn(this, "লগআউট", Ui.RED_BG, Ui.RED, new MainActivity$$ExternalSyntheticLambda57(this)), 10);
        setPage(pageBox);
    }

    private void showPaper(int i) {
        busy("প্রশ্নপত্র লোড হচ্ছে…");
        Api.call("GET", "/online/exams/" + i + "/paper", null, actCb(new MainActivity$$ExternalSyntheticLambda30(this)));
    }

    private void showReceipt(String str) {
        LinearLayout pageBox = pageBox();
        pageBox.setPadding(dp(20.0f), dp(50.0f), dp(20.0f), dp(20.0f));
        Ui.add(pageBox, Ui.tv(this, "✅ জমা হয়েছে", 22.0f, 0xFF0B8A63, true), 10);
        Ui.add(pageBox, Ui.tv(this, str, 15.0f, 0xFF17153B, false), 18);
        Ui.add(pageBox, Ui.primary(this, "পরীক্ষার তালিকায় ফিরে যাও", new MainActivity$$ExternalSyntheticLambda61(this)), 0);
        setScreen("জমা", scroll(pageBox), false, new MainActivity$$ExternalSyntheticLambda62(this), null);
    }

    private void showResult(String str, JSONObject jSONObject, JSONArray jSONArray) {
        boolean z;
        LinearLayout pageBox = pageBox();
        LinearLayout card = Ui.card(this);
        int i = 0xFF17153B;
        if (jSONObject.has("marks")) {
            Ui.add(card, Ui.tv(this, "নম্বর: " + num(jSONObject.optDouble("marks")) + " / " + num(jSONObject.optDouble("max_marks")), 24.0f, 0xFF4A3FD1, true), 6);
            Ui.add(card, Ui.tv(this, "স্কোর " + jSONObject.optInt("score") + "%  ·  র\u200d্যাঙ্ক " + jSONObject.optInt("rank") + " / " + jSONObject.optInt("participants"), 15.0f, 0xFF17153B, true), 4);
            Ui.add(card, Ui.tv(this, "সঠিক " + jSONObject.optInt("correct_count") + " · ভুল " + jSONObject.optInt("wrong_count") + " · বাদ " + jSONObject.optInt("skipped_count"), 14.0f, 0xFF55527A, false), 0);
        } else if (jSONObject.has("score")) {
            Ui.add(card, Ui.tv(this, "স্কোর: " + jSONObject.optInt("score") + "%", 26.0f, 0xFF4A3FD1, true), 6);
            Ui.add(card, Ui.tv(this, "সঠিক " + jSONObject.optInt("correct_count") + " / " + jSONObject.optInt("total_questions"), 15.0f, 0xFF17153B, true), 4);
            if (!str(jSONObject, "message").isEmpty()) {
                Ui.add(card, Ui.tv(this, jSONObject.optString("message"), 13.0f, 0xFF55527A, false), 0);
            }
        } else {
            Ui.add(card, Ui.tv(this, "উত্তর পর্যালোচনা", 18.0f, 0xFF4A3FD1, true), 0);
        }
        Ui.add(pageBox, card, 14);
        int i2 = 0;
        while (i2 < jSONArray.length()) {
            JSONObject at = at(jSONArray, i2);
            JSONObject optJSONObject = at.optJSONObject("options");
            if (optJSONObject == null) {
                optJSONObject = new JSONObject();
            }
            String str2 = str(at, "your_answer");
            String str3 = str(at, "correct_answer");
            LinearLayout card2 = Ui.card(this);
            Ui.add(card2, Ui.tv(this, (i2 + 1) + ". " + at.optString("question_text"), 16.0f, i, true), 8);
            String[] strArr = new String[4];
            strArr[0] = "a";
            strArr[1] = "b";
            strArr[2] = "c";
            strArr[3] = "d";
            int i3 = 0;
            while (i3 < 4) {
                String str4 = strArr[i3];
                JSONObject jSONObject2 = optJSONObject;
                TextView tv = Ui.tv(this, str4.toUpperCase() + ".  " + optJSONObject.optString(str4, ""), 15.0f, 0xFF17153B, false);
                LinearLayout linearLayout = card;
                tv.setPadding(dp(10.0f), dp(8.0f), dp(10.0f), dp(8.0f));
                if (str4.equalsIgnoreCase(str3)) {
                    tv.setBackground(Ui.box(this, 0xFFD9F5EA, 0xFF0B8A63, 8.0f));
                } else if (str4.equalsIgnoreCase(str2)) {
                    tv.setBackground(Ui.box(this, 0xFFFFE1DC, 0xFFD6393F, 8.0f));
                } else {
                    tv.setBackground(Ui.box(this, -1, 0xFFE2DFF3, 8.0f));
                }
                Ui.add(card2, tv, 5);
                i3++;
                optJSONObject = jSONObject2;
                card = linearLayout;
            }
            LinearLayout linearLayout2 = card;
            if (str2.isEmpty()) {
                Ui.add(card2, Ui.tv(this, "উত্তর দাওনি", 13.0f, 0xFFB7791F, true), 4);
                z = true;
            } else {
                z = true;
                Ui.add(card2, Ui.tv(this, at.optBoolean("is_correct") ? "✅ সঠিক" : "❌ ভুল — সঠিক উত্তর: " + str3.toUpperCase(), 13.0f, at.optBoolean("is_correct") ? 0xFF0B8A63 : 0xFFD6393F, true), 4);
            }
            if (!str(at, "explanation").isEmpty()) {
                Ui.add(card2, Ui.tv(this, "ব্যাখ্যা: " + at.optString("explanation"), 13.0f, 0xFF55527A, false), 0);
            }
            Ui.add(pageBox, card2, 10);
            i2++;
            card = linearLayout2;
            i = 0xFF17153B;
        }
        Ui.add(pageBox, Ui.primary(this, "শেষ", new MainActivity$$ExternalSyntheticLambda1(this)), 0);
        setScreen(str, scroll(pageBox), false, new MainActivity$$ExternalSyntheticLambda2(this), null);
    }

    private void showServerSetup(boolean z) {
        LinearLayout pageBox = pageBox();
        pageBox.setPadding(dp(20.0f), dp(40.0f), dp(20.0f), dp(20.0f));
        Ui.add(pageBox, Ui.tv(this, "সার্ভারের ঠিকানা", 22.0f, 0xFF17153B, true), 8);
        Ui.add(pageBox, Ui.tv(this, "যে ওয়েবসাইটে পরীক্ষা সিস্টেম চালু আছে তার ঠিকানা দাও। যেমন: https://exam.example.com", 14.0f, 0xFF55527A, false), 16);
        EditText input = Ui.input(this, "https://your-site.com", 17);
        input.setText(Api.base == null ? "" : Api.base);
        Ui.add(pageBox, input, 14);
        Ui.add(pageBox, Ui.primary(this, "সংযোগ করো", new MainActivity$$ExternalSyntheticLambda26(this, input)), 10);
        setScreen("সার্ভার", scroll(pageBox), false, z ? new MainActivity$$ExternalSyntheticLambda27(this) : null, null);
    }

    private void startFace(String str, int i, Runnable runnable) {
        this.afterFace = runnable;
        Intent intent = new Intent(this, (Class<?>) FaceActivity.class);
        intent.putExtra("mode", str);
        intent.putExtra("exam_id", i);
        startActivityForResult(intent, 23);
    }

    private void startLive(int i) {
        busy("পরীক্ষা লোড হচ্ছে…");
        Api.call("POST", "/online/exams/" + i + "/start", null, new AnonymousClass4(i));
    }

    private void stopTimer() {
        if (this.timer != null) {
            this.timer.cancel();
            this.timer = null;
        }
    }

    private static String str(JSONObject jSONObject, String str) {
        return jSONObject.isNull(str) ? "" : jSONObject.optString(str, "");
    }

    private void toast(String str) {
        Toast.makeText(this, str, 1).show();
    }

    private void uploadOmr(Uri uri) {
        int i = this.pendingOmrExam;
        busy("ছবি আপলোড হচ্ছে…");
        Api.POOL.execute(new MainActivity$$ExternalSyntheticLambda29(this, uri, i));
    }

    private static String when(String str) {
        return str == null ? "" : str.replace('T', ' ');
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 21) {
            if (i2 == -1 && this.camUri != null) {
                uploadOmr(this.camUri);
                return;
            } else {
                if (this.camUri != null) {
                    try {
                        getContentResolver().delete(this.camUri, null, null);
                        return;
                    } catch (Exception e) {
                        return;
                    }
                }
                return;
            }
        }
        if (i == 22) {
            if (i2 != -1 || intent == null || intent.getData() == null) {
                return;
            }
            uploadOmr(intent.getData());
            return;
        }
        if (i == 23) {
            String stringExtra = intent == null ? "" : intent.getStringExtra("message");
            if (i2 != -1) {
                if (stringExtra == null || stringExtra.isEmpty()) {
                    return;
                }
                showError(stringExtra);
                return;
            }
            if (stringExtra != null && !stringExtra.isEmpty()) {
                toast(stringExtra);
            }
            if (this.afterFace != null) {
                this.afterFace.run();
            }
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        if (this.onBack != null) {
            this.onBack.run();
        } else {
            super.onBackPressed();
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.prefs = getSharedPreferences("exam", 0);
        Api.base = FIXED_SERVER ? "https://prottashaacademy.com" : this.prefs.getString("server", "https://prottashaacademy.com");
        Api.token = this.prefs.getString("token", null);
        Api.onUnauthorized = new MainActivity$$ExternalSyntheticLambda38(this);
        buildChrome();
        route();
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 24) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                showError("ক্যামেরার অনুমতি দাও, অথবা গ্যালারি থেকে ছবি নাও।");
            } else {
                launchCamera();
            }
        }
    }

    // ---------------------------------------------------------------- Home screen

    private void loadHome(final Runnable retry) {
        final int tok = this.screenToken;
        Api.call("GET", "/online/exams", null, pageCb(new Ok() {
            @Override
            public void run(final JSONObject ex) throws Exception {
                Api.call("GET", "/exam/performance", null, new Api.Callback() {
                    @Override
                    public void onOk(JSONObject perf) {
                        if (tok != MainActivity.this.screenToken) {
                            return;
                        }
                        try {
                            buildHome(ex, perf);
                        } catch (Exception e) {
                            errorPage("দেখাতে সমস্যা হয়েছে: " + e.getMessage(), retry);
                        }
                    }

                    @Override
                    public void onErr(String m, String c, int s) {
                        if (tok != MainActivity.this.screenToken) {
                            return;
                        }
                        try {
                            buildHome(ex, new JSONObject());
                        } catch (Exception e) {
                            errorPage("দেখাতে সমস্যা হয়েছে: " + e.getMessage(), retry);
                        }
                    }
                });
            }
        }, retry));
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.tv(this, s, 19.0f, Ui.INK, true);
        t.setPadding(0, dp(10.0f), 0, dp(10.0f));
        return t;
    }

    private View iconTile(String icon, int bg, int fg, int boxDp, int iconDp, float radius) {
        FrameLayout ic = new FrameLayout(this);
        ic.setBackground(Ui.box(this, bg, 0, radius));
        ImageView iv = new ImageView(this);
        iv.setImageResource(drawableId(icon));
        iv.setColorFilter(fg);
        ic.addView(iv, new FrameLayout.LayoutParams(dp((float) iconDp), dp((float) iconDp), Gravity.CENTER));
        ic.setLayoutParams(new LinearLayout.LayoutParams(dp((float) boxDp), dp((float) boxDp)));
        return ic;
    }

    private View tile(String label, String icon, int bg, int fg, View.OnClickListener l) {
        LinearLayout t = Ui.vbox(this);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setBackground(Ui.box(this, Ui.WHITE, 0, 20.0f));
        t.setPadding(dp(4.0f), dp(14.0f), dp(4.0f), dp(12.0f));
        t.setElevation(dp(1.0f));
        t.addView(iconTile(icon, bg, fg, 46, 24, 14.0f));
        TextView tx = Ui.tv(this, label, 12.0f, Ui.INK, true);
        tx.setGravity(Gravity.CENTER);
        tx.setPadding(dp(2.0f), dp(8.0f), dp(2.0f), 0);
        t.addView(tx, new LinearLayout.LayoutParams(-1, -2));
        t.setOnClickListener(l);
        Ui.press(t);
        return t;
    }

    private View menuRow(String icon, String title, String sub, int bg, int fg, View.OnClickListener l) {
        LinearLayout r = Ui.hbox(this);
        r.setBackground(Ui.box(this, Ui.WHITE, 0, 20.0f));
        r.setPadding(dp(14.0f), dp(12.0f), dp(14.0f), dp(12.0f));
        r.setElevation(dp(1.0f));
        r.addView(iconTile(icon, bg, fg, 42, 22, 13.0f));
        LinearLayout tx = Ui.vbox(this);
        tx.setPadding(dp(12.0f), 0, dp(8.0f), 0);
        tx.addView(Ui.tv(this, title, 15.0f, Ui.INK, true));
        tx.addView(Ui.tv(this, sub, 12.0f, Ui.MUTED, false));
        r.addView(tx, new LinearLayout.LayoutParams(0, -2, 1.0f));
        r.addView(Ui.tv(this, "›", 22.0f, Ui.MUTED, true));
        r.setOnClickListener(l);
        Ui.press(r);
        return r;
    }

    private void buildHome(JSONObject ex, JSONObject perf) throws Exception {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(dp(18.0f), dp(26.0f), dp(18.0f), dp(24.0f));

        // greeting
        LinearLayout top = Ui.hbox(this);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        top.addView(logo, new LinearLayout.LayoutParams(dp(50.0f), dp(50.0f)));
        LinearLayout who = Ui.vbox(this);
        who.setPadding(dp(12.0f), 0, 0, 0);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String hello = hour < 5 ? "শুভ রাত্রি" : hour < 12 ? "শুভ সকাল" : hour < 16 ? "শুভ দুপুর" : hour < 19 ? "শুভ বিকাল" : "শুভ সন্ধ্যা";
        who.addView(Ui.tv(this, hello, 13.0f, Ui.MUTED, false));
        String nm = this.prefs.getString("name", "");
        who.addView(Ui.tv(this, nm.isEmpty() ? "শিক্ষার্থী" : nm, 21.0f, Ui.INK, true));
        top.addView(who, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView ref = Ui.tv(this, "↻", 20.0f, Ui.INK, true);
        ref.setGravity(Gravity.CENTER);
        ref.setBackground(Ui.box(this, Ui.WHITE, 0, 16.0f));
        ref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMain("home");
            }
        });
        Ui.press(ref);
        top.addView(ref, new LinearLayout.LayoutParams(dp(46.0f), dp(46.0f)));
        Ui.add(box, top, 18);

        // featured exam
        JSONArray exams = arr(ex, "exams");
        JSONObject feat = null;
        for (int pass = 0; pass < 3 && feat == null; pass++) {
            String want = pass == 0 ? "in_progress" : pass == 1 ? "open" : "upcoming";
            for (int i = 0; i < exams.length(); i++) {
                JSONObject e = at(exams, i);
                if (want.equals(e.optString("state"))) {
                    feat = e;
                    break;
                }
            }
        }
        LinearLayout hero = Ui.vbox(this);
        hero.setBackground(Ui.box(this, Ui.INK, 0, 28.0f));
        hero.setPadding(dp(20.0f), dp(20.0f), dp(20.0f), dp(20.0f));
        hero.setElevation(dp(4.0f));
        if (feat == null) {
            hero.addView(Ui.pill(this, "পরীক্ষা", 0x29FFB020, 0xFFFFC95C), new LinearLayout.LayoutParams(-2, -2));
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
            tl.topMargin = dp(14.0f);
            hero.addView(Ui.tv(this, "এখন কোনো পরীক্ষা নেই", 22.0f, -1, true), tl);
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
            sl.topMargin = dp(6.0f);
            sl.bottomMargin = dp(16.0f);
            hero.addView(Ui.tv(this, "ব্যাচে যোগ দিলে তোমার পরীক্ষা এখানে দেখা যাবে।", 14.0f, Ui.ON_INK, false), sl);
            hero.addView(Ui.btn(this, "ব্যাচ দেখো", Ui.ACCENT, Ui.INK, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMain("batches");
                }
            }), new LinearLayout.LayoutParams(-1, -2));
        } else {
            final int id = feat.optInt("id");
            String st = feat.optString("state");
            String mode = feat.optString("mode", "online");
            String choice = str(feat, "choice");
            String chip = "in_progress".equals(st) ? "● পরীক্ষা চলছে" : "open".equals(st) ? "● লাইভ পরীক্ষা" : "আসন্ন পরীক্ষা";
            hero.addView(Ui.pill(this, chip, 0x29FFB020, 0xFFFFC95C), new LinearLayout.LayoutParams(-2, -2));
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
            tl.topMargin = dp(14.0f);
            hero.addView(Ui.tv(this, feat.optString("title"), 22.0f, -1, true), tl);
            String meta = feat.optInt("questions") + " টি প্রশ্ন, " + Math.max(1, feat.optInt("time_limit_seconds") / 60) + " মিনিট";
            if (!str(feat, "batch_name").isEmpty()) {
                meta = meta + "\n" + feat.optString("batch_name");
            }
            LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
            ml.topMargin = dp(6.0f);
            hero.addView(Ui.tv(this, meta, 14.0f, Ui.ON_INK, false), ml);
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
            bl.topMargin = dp(18.0f);
            if ("in_progress".equals(st)) {
                hero.addView(Ui.tv(this, "বাকি সময়", 13.0f, Ui.ON_INK, false), bl);
                final TextView clockView = Ui.tv(this, clock(feat.optInt("remaining_seconds")), 40.0f, -1, true);
                hero.addView(clockView, new LinearLayout.LayoutParams(-1, -2));
                stopTimer();
                final int secs = Math.max(1, feat.optInt("remaining_seconds"));
                this.timer = new CountDownTimer(secs * 1000L, 1000L) {
                    @Override
                    public void onTick(long ms) {
                        clockView.setText(clock((int) (ms / 1000L)));
                    }

                    @Override
                    public void onFinish() {
                        clockView.setText(clock(0));
                    }
                };
                this.timer.start();
            } else if ("upcoming".equals(st)) {
                String when = str(feat, "start_time").isEmpty() ? "শিগগিরই শুরু হবে" : "শুরু: " + when(feat.optString("start_time"));
                hero.addView(Ui.tv(this, when, 15.0f, 0xFFFFC95C, true), bl);
            }
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
            cl.topMargin = dp(16.0f);
            if ("in_progress".equals(st)) {
                hero.addView(Ui.btn(this, "চালিয়ে যাও", Ui.ACCENT, Ui.INK, new MainActivity$$ExternalSyntheticLambda48(this, id)), cl);
            } else if ("open".equals(st) && ("online".equals(mode) || "online".equals(choice))) {
                hero.addView(Ui.btn(this, "পরীক্ষায় প্রবেশ করো", Ui.ACCENT, Ui.INK, new MainActivity$$ExternalSyntheticLambda45(this, id)), cl);
            } else {
                hero.addView(Ui.btn(this, "বিস্তারিত দেখো", Ui.ACCENT, Ui.INK, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showMain("exams");
                    }
                }), cl);
            }
        }
        Ui.add(box, hero, 8);

        // quick actions
        box.addView(sectionTitle("দ্রুত শুরু করো"));
        Object[][] quick = {
                {"লাইভ পরীক্ষা", "ic_live", 0xFFE4E1FF, 0xFF4A3FD1, "exams"},
                {"প্র্যাকটিস", "ic_practice", 0xFFD9F5EA, 0xFF0B6B4B, "practice"},
                {"অ্যাডাপটিভ", "ic_adaptive", 0xFFFFEFC9, 0xFF8A5A00, "adaptive"},
                {"লিডারবোর্ড", "ic_rank", 0xFFF1E0FF, 0xFF7A2FBF, "rank"},
                {"ফেস হাজিরা", "ic_face", 0xFFD6F4F4, 0xFF0B6F73, "face"},
                {"ব্যাচ", "ic_batch", 0xFFFFE1DC, 0xFFB4321F, "batches"}};
        LinearLayout row = null;
        for (int i = 0; i < quick.length; i++) {
            if (i % 3 == 0) {
                row = Ui.hbox(this);
                row.setGravity(Gravity.TOP);
                Ui.add(box, row, 10);
            }
            final String go = (String) quick[i][4];
            View tile = tile((String) quick[i][0], (String) quick[i][1], (Integer) quick[i][2], (Integer) quick[i][3], new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if ("adaptive".equals(go)) {
                        lambda$loadPractice$39(v);
                    } else if ("rank".equals(go)) {
                        showLeaderboard();
                    } else if ("face".equals(go)) {
                        showFace();
                    } else {
                        showMain(go);
                    }
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            lp.rightMargin = i % 3 == 2 ? 0 : dp(10.0f);
            row.addView(tile, lp);
        }

        // progress
        JSONArray topics = arr(perf, "topic_performance");
        int completed = perf.optInt("exams_completed");
        int needed = perf.optInt("exams_needed");
        boolean ready = perf.optBoolean("adaptive_ready");
        double sum = 0;
        for (int i = 0; i < topics.length(); i++) {
            sum += at(topics, i).optDouble("accuracy");
        }
        double avg = topics.length() == 0 ? 0 : sum / topics.length();
        box.addView(sectionTitle("তোমার অগ্রগতি"));
        LinearLayout card = Ui.card(this);
        LinearLayout prow = Ui.hbox(this);
        RingView ring = new RingView(this);
        ring.setData((float) avg, Math.round(avg * 100.0d) + "%", "গড় সঠিক", Ui.TRACK, Ui.INDIGO, Ui.INK, Ui.MUTED);
        prow.addView(ring, new LinearLayout.LayoutParams(dp(112.0f), dp(112.0f)));
        LinearLayout right = Ui.vbox(this);
        right.setPadding(dp(16.0f), 0, 0, 0);
        right.addView(Ui.tv(this, "পরীক্ষা সম্পন্ন", 13.0f, Ui.MUTED, false));
        right.addView(Ui.tv(this, String.valueOf(completed), 28.0f, Ui.INDIGO, true));
        String adaptiveText = ready ? "🧠 Adaptive Exam প্রস্তুত" : "Adaptive পেতে আরও " + needed + " টি পরীক্ষা";
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-1, -2);
        al.topMargin = dp(6.0f);
        right.addView(Ui.tv(this, adaptiveText, 13.0f, ready ? Ui.GREEN : Ui.MUTED, true), al);
        double total = completed + (ready ? 0 : needed);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, -2);
        barLp.topMargin = dp(8.0f);
        right.addView(Ui.bar(this, ready ? 1.0d : (total == 0 ? 0 : completed / total), ready ? Ui.GREEN : Ui.ACCENT), barLp);
        prow.addView(right, new LinearLayout.LayoutParams(0, -2, 1.0f));
        card.addView(prow);
        if (topics.length() == 0) {
            LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-1, -2);
            nl.topMargin = dp(14.0f);
            card.addView(Ui.tv(this, "এখনও কোনো ফলাফল নেই। পরীক্ষা দিলে এখানে দেখা যাবে।", 13.0f, Ui.MUTED, false), nl);
        } else {
            LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
            hl.topMargin = dp(16.0f);
            hl.bottomMargin = dp(8.0f);
            card.addView(Ui.tv(this, "যে বিষয়ে আরও অনুশীলন দরকার", 14.0f, Ui.INK, true), hl);
            boolean[] used = new boolean[topics.length()];
            int shownTopics = Math.min(3, topics.length());
            for (int n = 0; n < shownTopics; n++) {
                int best = -1;
                for (int i = 0; i < topics.length(); i++) {
                    if (!used[i] && (best < 0 || at(topics, i).optDouble("accuracy") < at(topics, best).optDouble("accuracy"))) {
                        best = i;
                    }
                }
                used[best] = true;
                JSONObject tp = at(topics, best);
                String level = tp.optString("level");
                int col = "strong".equals(level) ? Ui.GREEN : "weak".equals(level) ? Ui.RED : Ui.ACCENT;
                LinearLayout line = Ui.hbox(this);
                line.addView(Ui.tv(this, tp.optString("topic_name"), 13.0f, Ui.INK, false), new LinearLayout.LayoutParams(0, -2, 1.0f));
                line.addView(Ui.tv(this, Math.round(tp.optDouble("accuracy") * 100.0d) + "%", 13.0f, Ui.INK, true));
                Ui.add(card, line, 4);
                Ui.add(card, Ui.bar(this, tp.optDouble("accuracy"), col), 12);
            }
        }
        Ui.add(box, card, 8);

        // more exams
        int extra = 0;
        for (int i = 0; i < exams.length() && extra < 3; i++) {
            JSONObject e = at(exams, i);
            if (feat != null && e.optInt("id") == feat.optInt("id")) {
                continue;
            }
            if (extra == 0) {
                box.addView(sectionTitle("আরও পরীক্ষা"));
            }
            Ui.add(box, examCard(e), 12);
            extra++;
        }

        for (int i = 0; i < box.getChildCount(); i++) {
            Ui.rise(box.getChildAt(i), i * 70);
        }
        setPage(box);
    }

}
