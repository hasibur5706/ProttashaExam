package com.prottasha.exam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.app.Dialog;
import android.widget.ProgressBar;
import android.graphics.Typeface;
import android.view.animation.DecelerateInterpolator;
import android.graphics.drawable.GradientDrawable;
import android.widget.HorizontalScrollView;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import java.util.Calendar;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.prottasha.exam.Api;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class MainActivity extends Activity {
    private static final int REQ_CAM = 21;
    private static final int REQ_CAM_PERM = 24;
    private static final int REQ_FACE = 23;
    private static final int REQ_PICK = 22;
    private Runnable afterFace;
    private TextView backBtn;
    private AlertDialog busyDialog;
    private Uri camUri;
    private FrameLayout content;
    private LinearLayout header;
    private LinearLayout nav;
    private Runnable onBack;
    private int pendingOmrExam;
    private SharedPreferences prefs;
    private Runnable refreshAction;
    private CountDownTimer timer;
    private TextView titleView;
    private static final String[][] TABS = {
            {"home", "ic_home", "হোম"},
            {"exams", "ic_exam", "পরীক্ষা"},
            {"practice", "ic_practice", "প্র্যাকটিস"},
            {"rank", "ic_rank", "র‍্যাঙ্ক"},
            {"more", "ic_more", "আরও"}};
    private static final boolean FIXED_SERVER = !"https://prottashaacademy.com".isEmpty();
    private TextView[] navItems = new TextView[TABS.length];
    private String tab = "home";
    private JSONObject lastExams;
    private String examFilter = "all";
    private String reviewFilter = "all";
    private int practiceCount = 10;
    private boolean splashShowing = false;
    private boolean inkStatus = true;
    private int screenToken = 0;

    /* renamed from: com.prottasha.exam.MainActivity$1, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass1 implements Api.Callback {
        final /* synthetic */ Ok val$ok;

        AnonymousClass1(Ok ok) {
            this.val$ok = ok;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            MainActivity.m43$$Nest$mshowError(MainActivity.this, str);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            try {
                this.val$ok.run(jSONObject);
            } catch (Exception e) {
                MainActivity.m43$$Nest$mshowError(MainActivity.this, "সমস্যা হয়েছে: " + e.getMessage());
            }
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$2, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass2 implements Api.Callback {
        final /* synthetic */ Ok val$ok;
        final /* synthetic */ Runnable val$retry;
        final /* synthetic */ int val$tok;

        AnonymousClass2(int i, Ok ok, Runnable runnable) {
            this.val$tok = i;
            this.val$ok = ok;
            this.val$retry = runnable;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            if (this.val$tok != MainActivity.m30$$Nest$fgetscreenToken(MainActivity.this)) {
                return;
            }
            MainActivity.m38$$Nest$merrorPage(MainActivity.this, str, this.val$retry);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            if (this.val$tok != MainActivity.m30$$Nest$fgetscreenToken(MainActivity.this)) {
                return;
            }
            try {
                this.val$ok.run(jSONObject);
            } catch (Exception e) {
                MainActivity.m38$$Nest$merrorPage(MainActivity.this, "দেখাতে সমস্যা হয়েছে: " + e.getMessage(), this.val$retry);
            }
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$3, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass3 implements Api.Callback {
        final /* synthetic */ String val$old;
        final /* synthetic */ String val$url;

        AnonymousClass3(String str, String str2) {
            this.val$url = str;
            this.val$old = str2;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            Api.base = this.val$old;
            MainActivity.m43$$Nest$mshowError(MainActivity.this, "এই ঠিকানায় পরীক্ষা সার্ভার পাওয়া যায়নি।\n" + str);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            if (!this.val$url.equals(this.val$old)) {
                MainActivity.m34$$Nest$mclearLogin(MainActivity.this);
            }
            MainActivity.m29$$Nest$fgetprefs(MainActivity.this).edit().putString("server", this.val$url).apply();
            MainActivity.m41$$Nest$mroute(MainActivity.this);
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$4, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass4 implements Api.Callback {
        final /* synthetic */ int val$id;

        /* renamed from: $r8$lambda$JAaHTqzE0bf48l2W_drKkmQ--_I, reason: not valid java name */
        public static /* synthetic */ void m53$r8$lambda$JAaHTqzE0bf48l2W_drKkmQ_I(AnonymousClass4 anonymousClass4, int i) {
            anonymousClass4.lambda$onErr$0(i);
        }

        AnonymousClass4(int i) {
            this.val$id = i;
        }

        private /* synthetic */ void lambda$onErr$0(int i) {
            MainActivity.m48$$Nest$mstartLive(MainActivity.this, i);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            if ("FACE_REQUIRED".equals(str2)) {
                MainActivity.m47$$Nest$mstartFace(MainActivity.this, "verify", this.val$id, new MainActivity$4$$ExternalSyntheticLambda0(this, this.val$id));
            } else {
                MainActivity.m43$$Nest$mshowError(MainActivity.this, str);
            }
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            MainActivity.m40$$Nest$mopenLive(MainActivity.this, jSONObject);
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$5, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass5 implements Api.Callback {
        final /* synthetic */ Runnable val$onFail;

        AnonymousClass5(Runnable runnable) {
            this.val$onFail = runnable;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            this.val$onFail.run();
            MainActivity.m43$$Nest$mshowError(MainActivity.this, str);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            if (jSONObject.optBoolean("result_hidden")) {
                MainActivity.m45$$Nest$mshowReceipt(MainActivity.this, jSONObject.optString("message"));
            } else {
                MainActivity.m46$$Nest$mshowResult(MainActivity.this, "ফলাফল", jSONObject, MainActivity.m49$$Nest$smarr(jSONObject, "results"));
            }
        }
    }

    /* renamed from: com.prottasha.exam.MainActivity$6, reason: invalid class name */
    /* loaded from: classes2.dex */
    class AnonymousClass6 implements Api.Callback {
        final /* synthetic */ Runnable val$onFail;
        final /* synthetic */ JSONArray val$qs;

        AnonymousClass6(JSONArray jSONArray, Runnable runnable) {
            this.val$qs = jSONArray;
            this.val$onFail = runnable;
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onErr(String str, String str2, int i) {
            this.val$onFail.run();
            MainActivity.m43$$Nest$mshowError(MainActivity.this, str);
        }

        @Override // com.prottasha.exam.Api.Callback
        public void onOk(JSONObject jSONObject) {
            MainActivity.m39$$Nest$mhideBusy(MainActivity.this);
            JSONArray m49$$Nest$smarr = MainActivity.m49$$Nest$smarr(jSONObject, "results");
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < m49$$Nest$smarr.length(); i++) {
                JSONObject m50$$Nest$smat = MainActivity.m50$$Nest$smat(m49$$Nest$smarr, i);
                JSONObject jSONObject2 = null;
                for (int i2 = 0; i2 < this.val$qs.length(); i2++) {
                    if (MainActivity.m50$$Nest$smat(this.val$qs, i2).optInt("id") == m50$$Nest$smat.optInt("question_id")) {
                        jSONObject2 = MainActivity.m50$$Nest$smat(this.val$qs, i2);
                    }
                }
                if (jSONObject2 != null) {
                    try {
                        m50$$Nest$smat.put("options", MainActivity.m51$$Nest$smjson(new Object[]{"a", jSONObject2.optString("option_a"), "b", jSONObject2.optString("option_b"), "c", jSONObject2.optString("option_c"), "d", jSONObject2.optString("option_d")}));
                    } catch (Exception e) {
                    }
                }
                jSONArray.put(m50$$Nest$smat);
            }
            MainActivity.m46$$Nest$mshowResult(MainActivity.this, "প্র্যাকটিসের ফলাফল", jSONObject, jSONArray);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public class ExamSession {
        LinearLayout body;
        View barFill;
        View barRest;
        LinearLayout palette;
        HorizontalScrollView paletteScroll;
        final int n;
        Button next;
        Button prev;
        TextView progressView;
        final JSONArray qs;
        final int remaining;
        final String[] sel;
        Button send;
        final long[] spent;
        final Submitter submitter;
        ScrollView sv;
        TextView timerView;
        final String title;
        int idx = 0;
        long shown = System.currentTimeMillis();
        boolean busy = false;

        /* renamed from: com.prottasha.exam.MainActivity$ExamSession$1, reason: invalid class name */
        /* loaded from: classes2.dex */
        class AnonymousClass1 extends CountDownTimer {
            AnonymousClass1(long j, long j2) {
                super(j, j2);
            }

            @Override // android.os.CountDownTimer
            public void onFinish() {
                ExamSession.this.timerView.setText("⏱ 00:00");
                ExamSession.this.doSubmit();
            }

            @Override // android.os.CountDownTimer
            public void onTick(long j) {
                int i = (int) (j / 1000);
                ExamSession.this.timerView.setText("⏱ " + MainActivity.m35$$Nest$mclock(MainActivity.this, i));
                ExamSession.this.timerView.setTextColor(i < 60 ? 0xFFFF8A8A : 0xFFFFC95C);
            }
        }

        /* renamed from: $r8$lambda$KNCn3zu-CcqtPownWtty6VR-yz8, reason: not valid java name */
        public static /* synthetic */ void m54$r8$lambda$KNCn3zuCcqtPownWtty6VRyz8(ExamSession examSession, View view) {
            examSession.lambda$show$1(view);
        }

        public static /* synthetic */ void $r8$lambda$TQ4HJs73AYRZ34HRNuMpVHpo_pk(ExamSession examSession) {
            examSession.lambda$show$3();
        }

        /* renamed from: $r8$lambda$V-pxKYt0kCGE45B-JRgYHCxqmwo, reason: not valid java name */
        public static /* synthetic */ void m55$r8$lambda$VpxKYt0kCGE45BJRgYHCxqmwo(ExamSession examSession, String str, View view) {
            examSession.lambda$renderQ$5(str, view);
        }

        /* renamed from: $r8$lambda$Wx834LsSewkvmCE-fPT5B8lbGik, reason: not valid java name */
        public static /* synthetic */ void m56$r8$lambda$Wx834LsSewkvmCEfPT5B8lbGik(ExamSession examSession, View view) {
            examSession.lambda$show$0(view);
        }

        public static /* synthetic */ void $r8$lambda$avDm8t2pdgJxQ6PtYA709Gqundg(ExamSession examSession, View view) {
            examSession.lambda$show$2(view);
        }

        public static /* synthetic */ void $r8$lambda$mQoBjXZTcQFu5bBsTSIaibPbn9k(ExamSession examSession) {
            examSession.lambda$doSubmit$6();
        }

        /* renamed from: $r8$lambda$pz-dFBhXLHO01zlxwvsgxVCwfGM, reason: not valid java name */
        public static /* synthetic */ void m57$r8$lambda$pzdFBhXLHO01zlxwvsgxVCwfGM(ExamSession examSession) {
            examSession.lambda$show$4();
        }

        ExamSession(String str, JSONArray jSONArray, int i, Submitter submitter) {
            this.title = str;
            this.qs = jSONArray;
            this.remaining = i;
            this.submitter = submitter;
            this.n = jSONArray.length();
            this.sel = new String[this.n];
            this.spent = new long[this.n];
        }

        private /* synthetic */ void lambda$doSubmit$6() {
            this.busy = false;
        }

        private /* synthetic */ void lambda$renderQ$5(String str, View view) {
            this.sel[this.idx] = str.equals(this.sel[this.idx]) ? null : str;
            renderQ();
        }

        private /* synthetic */ void lambda$show$0(View view) {
            go(this.idx - 1);
        }

        private /* synthetic */ void lambda$show$1(View view) {
            go(this.idx + 1);
        }

        private /* synthetic */ void lambda$show$2(View view) {
            askSubmit();
        }

        private /* synthetic */ void lambda$show$3() {
            MainActivity.m44$$Nest$mshowMain(MainActivity.this, MainActivity.m31$$Nest$fgettab(MainActivity.this));
        }

        private /* synthetic */ void lambda$show$4() {
            MainActivity.m36$$Nest$mconfirm(MainActivity.this, "পরীক্ষা থেকে বের হবে?", this.remaining >= 0 ? "উত্তর জমা হবে না। পরে আবার এসে বাকি সময় থেকে চালিয়ে যেতে পারবে।" : "এই প্র্যাকটিসের উত্তর হারিয়ে যাবে।", new MainActivity$ExamSession$$ExternalSyntheticLambda0(this));
        }

        void askSubmit() {
            if (this.busy) {
                return;
            }
            int left = 0;
            for (String x : this.sel) {
                if (x == null) {
                    left++;
                }
            }
            MainActivity.this.submitSheet(this.n - left, left, new Runnable() {
                @Override
                public void run() {
                    ExamSession.this.doSubmit();
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void doSubmit() {
            if (this.busy) {
                return;
            }
            this.busy = true;
            leave();
            this.shown = System.currentTimeMillis();
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < this.n; i++) {
                jSONArray.put(MainActivity.m51$$Nest$smjson(new Object[]{"question_id", Integer.valueOf(MainActivity.m50$$Nest$smat(this.qs, i).optInt("id")), "selected_option", this.sel[i] == null ? JSONObject.NULL : this.sel[i], "time_taken_seconds", Long.valueOf(this.spent[i])}));
            }
            MainActivity.m33$$Nest$mbusy(MainActivity.this, "জমা হচ্ছে…");
            this.submitter.submit(jSONArray, new MainActivity$ExamSession$$ExternalSyntheticLambda1(this));
        }

        void go(int i) {
            if (i < 0 || i >= this.n) {
                return;
            }
            leave();
            this.idx = i;
            this.shown = System.currentTimeMillis();
            renderQ();
            this.sv.scrollTo(0, 0);
        }

        void leave() {
            long[] jArr = this.spent;
            int i = this.idx;
            jArr[i] = jArr[i] + ((System.currentTimeMillis() - this.shown) / 1000);
        }

        void renderQ() {
            int answered = 0;
            for (String x : this.sel) {
                if (x != null) {
                    answered++;
                }
            }
            MainActivity act = MainActivity.this;
            this.progressView.setText("প্রশ্ন " + act.bn(this.idx + 1) + " / " + act.bn(this.n) + "   (উত্তর " + act.bn(answered) + ")");
            float w = Math.max(0.02f, answered / (float) this.n);
            ((LinearLayout.LayoutParams) this.barFill.getLayoutParams()).weight = w;
            ((LinearLayout.LayoutParams) this.barRest.getLayoutParams()).weight = 1.0f - w;
            this.barFill.requestLayout();
            this.prev.setAlpha(this.idx > 0 ? 1.0f : 0.45f);
            this.prev.setEnabled(this.idx > 0);
            this.next.setVisibility(this.idx < this.n - 1 ? View.VISIBLE : View.GONE);
            this.send.setVisibility(this.idx < this.n - 1 ? View.GONE : View.VISIBLE);
            this.body.removeAllViews();
            JSONObject q = MainActivity.at(this.qs, this.idx);
            if (!MainActivity.str(q, "topic_name").isEmpty()) {
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
                tl.bottomMargin = act.dp(10.0f);
                this.body.addView(Ui.pill(act, q.optString("topic_name"), Ui.SOFT, Ui.INDIGO), tl);
            }
            Ui.add(this.body, Ui.tv(act, q.optString("question_text"), 21.0f, Ui.INK, true), 18);
            String[] keys = {"a", "b", "c", "d"};
            String[] letters = {"ক", "খ", "গ", "ঘ"};
            for (int k = 0; k < 4; k++) {
                String key = keys[k];
                boolean on = key.equals(this.sel[this.idx]);
                LinearLayout row = Ui.hbox(act);
                row.setBackground(Ui.box(act, on ? Ui.SOFT : Ui.WHITE, on ? Ui.INDIGO : 0, 20.0f));
                row.setPadding(act.dp(12.0f), act.dp(12.0f), act.dp(14.0f), act.dp(12.0f));
                TextView badge = Ui.tv(act, letters[k], 16.0f, on ? -1 : Ui.INK, true);
                badge.setGravity(Gravity.CENTER);
                badge.setBackground(Ui.box(act, on ? Ui.INDIGO : Ui.TRACK, 0, 12.0f));
                row.addView(badge, new LinearLayout.LayoutParams(act.dp(34.0f), act.dp(34.0f)));
                TextView t = Ui.tv(act, q.optString("option_" + key), 16.0f, Ui.INK, on);
                t.setPadding(act.dp(12.0f), 0, 0, 0);
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1.0f));
                row.setOnClickListener(new MainActivity$ExamSession$$ExternalSyntheticLambda2(this, key));
                Ui.press(row);
                Ui.add(this.body, row, 10);
            }
            this.palette.removeAllViews();
            for (int i = 0; i < this.n; i++) {
                final int target = i;
                boolean cur = i == this.idx;
                boolean ans = this.sel[i] != null;
                TextView bub = Ui.tv(act, act.bn(i + 1), 15.0f, cur ? -1 : Ui.INK, true);
                bub.setGravity(Gravity.CENTER);
                bub.setBackground(Ui.box(act, cur ? Ui.INK : ans ? Ui.SOFT : Ui.WHITE, cur ? 0 : ans ? Ui.INDIGO : Ui.LINE, 14.0f));
                bub.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ExamSession.this.go(target);
                    }
                });
                LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(act.dp(44.0f), act.dp(44.0f));
                bl.rightMargin = act.dp(8.0f);
                this.palette.addView(bub, bl);
            }
            final int scrollTo = Math.max(0, this.idx * act.dp(52.0f) - act.dp(120.0f));
            this.paletteScroll.post(new Runnable() {
                @Override
                public void run() {
                    ExamSession.this.paletteScroll.smoothScrollTo(scrollTo, 0);
                }
            });
        }

        void show() {
            MainActivity act = MainActivity.this;
            LinearLayout root = Ui.vbox(act);
            root.setBackgroundColor(Ui.BG);
            LinearLayout top = Ui.hbox(act);
            top.setPadding(act.dp(18.0f), act.dp(14.0f), act.dp(18.0f), act.dp(4.0f));
            this.progressView = Ui.tv(act, "", 15.0f, Ui.INK, true);
            top.addView(this.progressView, new LinearLayout.LayoutParams(0, -2, 1.0f));
            this.timerView = Ui.tv(act, this.remaining >= 0 ? "⏱ " + act.clock(this.remaining) : "", 16.0f, 0xFFFFC95C, true);
            this.timerView.setBackground(Ui.box(act, Ui.INK, 0, 20.0f));
            this.timerView.setPadding(act.dp(14.0f), act.dp(7.0f), act.dp(14.0f), act.dp(7.0f));
            if (this.remaining < 0) {
                this.timerView.setVisibility(View.GONE);
            }
            top.addView(this.timerView);
            root.addView(top, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout bar = new LinearLayout(act);
            bar.setBackground(Ui.box(act, Ui.TRACK, 0, 4.0f));
            this.barFill = new View(act);
            this.barFill.setBackground(Ui.box(act, Ui.INDIGO, 0, 4.0f));
            this.barRest = new View(act);
            bar.addView(this.barFill, new LinearLayout.LayoutParams(0, act.dp(6.0f), 0.02f));
            bar.addView(this.barRest, new LinearLayout.LayoutParams(0, act.dp(6.0f), 0.98f));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
            blp.setMargins(act.dp(18.0f), act.dp(6.0f), act.dp(18.0f), act.dp(6.0f));
            root.addView(bar, blp);
            this.sv = new ScrollView(act);
            this.body = Ui.vbox(act);
            this.body.setPadding(act.dp(18.0f), act.dp(10.0f), act.dp(18.0f), act.dp(20.0f));
            this.sv.addView(this.body, new FrameLayout.LayoutParams(-1, -2));
            root.addView(this.sv, new LinearLayout.LayoutParams(-1, 0, 1.0f));
            LinearLayout bottom = Ui.vbox(act);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Ui.WHITE);
            float rr = act.dp(28.0f);
            bg.setCornerRadii(new float[]{rr, rr, rr, rr, 0f, 0f, 0f, 0f});
            bottom.setBackground(bg);
            bottom.setElevation(act.dp(12.0f));
            bottom.setPadding(act.dp(16.0f), act.dp(14.0f), act.dp(16.0f), act.dp(14.0f));
            this.paletteScroll = new HorizontalScrollView(act);
            this.paletteScroll.setHorizontalScrollBarEnabled(false);
            this.palette = Ui.hbox(act);
            this.paletteScroll.addView(this.palette);
            Ui.add(bottom, this.paletteScroll, 12);
            LinearLayout buttons = Ui.hbox(act);
            this.prev = Ui.btn(act, "আগের", Ui.WHITE, Ui.INK, new MainActivity$ExamSession$$ExternalSyntheticLambda3(this));
            this.next = Ui.btn(act, "পরের প্রশ্ন", Ui.INDIGO, Ui.WHITE, new MainActivity$ExamSession$$ExternalSyntheticLambda4(this));
            this.send = Ui.btn(act, "উত্তর জমা দাও", Ui.ACCENT, Ui.INK, new MainActivity$ExamSession$$ExternalSyntheticLambda5(this));
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(act.dp(110.0f), -2);
            pl.rightMargin = act.dp(10.0f);
            buttons.addView(this.prev, pl);
            buttons.addView(this.next, new LinearLayout.LayoutParams(0, -2, 1.0f));
            buttons.addView(this.send, new LinearLayout.LayoutParams(0, -2, 1.0f));
            bottom.addView(buttons, new LinearLayout.LayoutParams(-1, -2));
            root.addView(bottom, new LinearLayout.LayoutParams(-1, -2));
            act.setScreen(this.title, root, false, new MainActivity$ExamSession$$ExternalSyntheticLambda6(this), null);
            renderQ();
            if (this.remaining >= 0) {
                act.timer = new AnonymousClass1(1000L * this.remaining, 1000L).start();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public interface Ok {
        void run(JSONObject jSONObject) throws Exception;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public interface Submitter {
        void submit(JSONArray jSONArray, Runnable runnable);
    }

    public static /* synthetic */ void $r8$lambda$0OEj7dKd0zu2PAixBGRK6kHfBaE(MainActivity mainActivity, View view) {
        mainActivity.lambda$showAuth$11(view);
    }

    /* renamed from: $r8$lambda$0pdPFnjySiMIo-1DUmzHBygt3jU, reason: not valid java name */
    public static /* synthetic */ void m2$r8$lambda$0pdPFnjySiMIo1DUmzHBygt3jU(MainActivity mainActivity, View view) {
        mainActivity.lambda$showFace$59(view);
    }

    public static /* synthetic */ void $r8$lambda$3CUt1mfsNra54BH3U5de0lAIZx0(MainActivity mainActivity, View view) {
        mainActivity.lambda$buildChrome$3(view);
    }

    public static /* synthetic */ void $r8$lambda$4XHB5HzSgsqCtpmdAofTcbJGFGQ(MainActivity mainActivity) {
        mainActivity.lambda$onCreate$1();
    }

    /* renamed from: $r8$lambda$5IYA-SNKnkgczOClLMNBsr5PmGs, reason: not valid java name */
    public static /* synthetic */ void m3$r8$lambda$5IYASNKnkgczOClLMNBsr5PmGs(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$18(i, view);
    }

    /* renamed from: $r8$lambda$63-2dv2nMGr1z-XabSDFH18vfcI, reason: not valid java name */
    public static /* synthetic */ void m4$r8$lambda$632dv2nMGr1zXabSDFH18vfcI(MainActivity mainActivity, boolean z, View view) {
        mainActivity.lambda$showAuth$10(z, view);
    }

    public static /* synthetic */ void $r8$lambda$6iRiYq6NpkAe9QLuvTHCBzE8np8(MainActivity mainActivity, EditText editText, EditText editText2, EditText editText3, boolean z, View view) {
        mainActivity.lambda$showAuth$9(editText, editText2, editText3, z, view);
    }

    public static /* synthetic */ void $r8$lambda$7JGreejyIeiVV7BwLVdK2je2WB8(MainActivity mainActivity, CheckBox checkBox, View view) {
        mainActivity.lambda$showFace$58(checkBox, view);
    }

    /* renamed from: $r8$lambda$7qRkEDomPAPkQ-Td2pSV4Kw5wVs, reason: not valid java name */
    public static /* synthetic */ void m5$r8$lambda$7qRkEDomPAPkQTd2pSV4Kw5wVs(MainActivity mainActivity, View view) {
        mainActivity.lambda$showMore$49(view);
    }

    /* renamed from: $r8$lambda$8LnNpkNKxYu0ldXa76galWmy-50, reason: not valid java name */
    public static /* synthetic */ void m6$r8$lambda$8LnNpkNKxYu0ldXa76galWmy50(MainActivity mainActivity, View view) {
        mainActivity.lambda$showAdminNote$13(view);
    }

    public static /* synthetic */ void $r8$lambda$ChFWKTh2xO8SsTViHaLbt2tkChE(MainActivity mainActivity, View view) {
        mainActivity.lambda$showMore$54(view);
    }

    public static /* synthetic */ void $r8$lambda$D1UXKjZufLmeYjUxTLdyJJdlnTk(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadPractice$41(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$DO6I05IqB376oIaWUR6BgC86ZNM(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showFace$60(jSONObject);
    }

    /* renamed from: $r8$lambda$Dm5TF_3CxGQRi0Hw6au09EP7a-U, reason: not valid java name */
    public static /* synthetic */ void m7$r8$lambda$Dm5TF_3CxGQRi0Hw6au09EP7aU(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showPaper$33(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$FOqj_vqLcgdpgBGxTInD6QyGsZY(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$25(i, view);
    }

    public static /* synthetic */ void $r8$lambda$FXu1EG0effOMM2vOiHTxCaWDabk(MainActivity mainActivity) {
        mainActivity.showLeaderboard();
    }

    public static /* synthetic */ void $r8$lambda$GDd17EW5TLWPkvDx9qUQ3ld4lhM(MainActivity mainActivity, int i) {
        mainActivity.lambda$examCard$21(i);
    }

    /* renamed from: $r8$lambda$GJ8NtPPFwJ-6mOwfQwZmXRWJaBc, reason: not valid java name */
    public static /* synthetic */ void m8$r8$lambda$GJ8NtPPFwJ6mOwfQwZmXRWJaBc(MainActivity mainActivity, int i) {
        mainActivity.lambda$examCard$19(i);
    }

    /* renamed from: $r8$lambda$Gp-RM_2g0vbMijSLgiiFSAPSWts, reason: not valid java name */
    public static /* synthetic */ void m9$r8$lambda$GpRM_2g0vbMijSLgiiFSAPSWts(MainActivity mainActivity, String str) {
        mainActivity.lambda$showMain$15(str);
    }

    public static /* synthetic */ void $r8$lambda$JGgkIQzIdNuWS23rFHPpsXutOu0(MainActivity mainActivity) {
        mainActivity.lambda$showFace$57();
    }

    public static /* synthetic */ void $r8$lambda$JyyR3iFiYuA4ToeoNRZ6zn47KJo(MainActivity mainActivity, View view) {
        mainActivity.lambda$showReceipt$30(view);
    }

    /* renamed from: $r8$lambda$KcrZ568C6_-YqQkjE_BT9I5CaV8, reason: not valid java name */
    public static /* synthetic */ void m10$r8$lambda$KcrZ568C6_YqQkjE_BT9I5CaV8(MainActivity mainActivity) {
        mainActivity.showFace();
    }

    public static /* synthetic */ void $r8$lambda$MHuJ9acgGyk41x2qTtrp6kkTrGw(MainActivity mainActivity, int i, boolean z, View view) {
        mainActivity.lambda$examCard$26(i, z, view);
    }

    /* renamed from: $r8$lambda$P-HII347s9pSC38oIdmUjWYXl2c, reason: not valid java name */
    public static /* synthetic */ void m11$r8$lambda$PHII347s9pSC38oIdmUjWYXl2c(MainActivity mainActivity) {
        mainActivity.lambda$showResult$37();
    }

    public static /* synthetic */ void $r8$lambda$Pmrfax10MWZ9MctYRIBATkT5nmM(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$paymentDialog$47(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$R3nYBJ5Xonc1jWDDT6yaOTV3clU(MainActivity mainActivity, JSONObject jSONObject, View view) {
        mainActivity.lambda$loadPractice$40(jSONObject, view);
    }

    /* renamed from: $r8$lambda$RqDm6IYbsDR8fkCq-32wooGfnU8, reason: not valid java name */
    public static /* synthetic */ void m12$r8$lambda$RqDm6IYbsDR8fkCq32wooGfnU8(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showFace$63(jSONObject);
    }

    /* renamed from: $r8$lambda$S9MdXG1xkBWEx8rJVpQ-mbC139Y, reason: not valid java name */
    public static /* synthetic */ void m13$r8$lambda$S9MdXG1xkBWEx8rJVpQmbC139Y(MainActivity mainActivity, View view) {
        mainActivity.lambda$examCard$27(view);
    }

    public static /* synthetic */ void $r8$lambda$SH8noAFID_O0BuQz9Lw8JAPPeHc(MainActivity mainActivity, View view) {
        mainActivity.lambda$showAdminNote$12(view);
    }

    /* renamed from: $r8$lambda$TL-ivfhk5khvbWTi0IX8Z35Sd9o, reason: not valid java name */
    public static /* synthetic */ void m14$r8$lambda$TLivfhk5khvbWTi0IX8Z35Sd9o(MainActivity mainActivity, View view) {
        mainActivity.lambda$loadPractice$38(view);
    }

    public static /* synthetic */ void $r8$lambda$VXqgE3Of5YEIrR21VHh_UkXEKSg(MainActivity mainActivity) {
        mainActivity.lambda$uploadOmr$65();
    }

    /* renamed from: $r8$lambda$VoN2_idDPiHzvSZKKzZhY652-OE, reason: not valid java name */
    public static /* synthetic */ void m15$r8$lambda$VoN2_idDPiHzvSZKKzZhY652OE(MainActivity mainActivity, String str) {
        mainActivity.lambda$showMain$14(str);
    }

    /* renamed from: $r8$lambda$WBkjzsgSEOsS48Yw4-GufOtN9bg, reason: not valid java name */
    public static /* synthetic */ void m16$r8$lambda$WBkjzsgSEOsS48Yw4GufOtN9bg(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$openReview$35(jSONObject);
    }

    /* renamed from: $r8$lambda$XKEyic2ZQOEoqtf-Dd1qRVcjFOY, reason: not valid java name */
    public static /* synthetic */ void m17$r8$lambda$XKEyic2ZQOEoqtfDd1qRVcjFOY(MainActivity mainActivity, int i, JSONArray jSONArray, Runnable runnable) {
        mainActivity.lambda$openLive$29(i, jSONArray, runnable);
    }

    public static /* synthetic */ void $r8$lambda$Ze2qsh0MVUgLzps6erGHVkt_LRU(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadBatches$44(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$ZgCiawqiwpAD6CpZhGR4SOQRnOk(MainActivity mainActivity, double d, int i, View view) {
        mainActivity.lambda$loadBatches$45(d, i, view);
    }

    /* renamed from: $r8$lambda$_4uEYGmKVgRhEtDc1c-eJ9JUcWg, reason: not valid java name */
    public static /* synthetic */ void m18$r8$lambda$_4uEYGmKVgRhEtDc1ceJ9JUcWg(MainActivity mainActivity) {
        mainActivity.lambda$showFace$61();
    }

    public static /* synthetic */ void $r8$lambda$b05wwUpMHHlQr2kXp5qkJJknm24(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$20(i, view);
    }

    public static /* synthetic */ void $r8$lambda$bmOBIZ_aaIgB68UYWe31XriW0HI(MainActivity mainActivity, EditText editText, View view) {
        mainActivity.lambda$showServerSetup$6(editText, view);
    }

    /* renamed from: $r8$lambda$cs10DC3fvVo-onhtamO3lspOEt0, reason: not valid java name */
    public static /* synthetic */ void m19$r8$lambda$cs10DC3fvVoonhtamO3lspOEt0(MainActivity mainActivity, int i, EditText editText, EditText editText2, EditText editText3, DialogInterface dialogInterface, int i2) {
        mainActivity.lambda$paymentDialog$48(i, editText, editText2, editText3, dialogInterface, i2);
    }

    /* renamed from: $r8$lambda$d_rrHNGyE_-CVF6jsZTY0m5UlHI, reason: not valid java name */
    public static /* synthetic */ void m20$r8$lambda$d_rrHNGyE_CVF6jsZTY0m5UlHI(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$uploadOmr$66(jSONObject);
    }

    /* renamed from: $r8$lambda$enRZ7raUuFhBo5wBzms-LL37hio, reason: not valid java name */
    public static /* synthetic */ void m21$r8$lambda$enRZ7raUuFhBo5wBzmsLL37hio(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.openPractice(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$gbbgxHTyCeYasOVpfPS09Vx_rgM(MainActivity mainActivity, int i, JSONArray jSONArray, JSONArray jSONArray2, Runnable runnable) {
        mainActivity.lambda$openPractice$42(i, jSONArray, jSONArray2, runnable);
    }

    public static /* synthetic */ void $r8$lambda$ghBSQe4aQEnmye8llwJ9O_1Fg3I(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadExams$16(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$goFvspdIAKQ0J2QLw1FjdMzUNSc(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showAuth$8(jSONObject);
    }

    /* renamed from: $r8$lambda$grqvxgZm8-Wux5U3GsP7fGqhZNA, reason: not valid java name */
    public static /* synthetic */ void m22$r8$lambda$grqvxgZm8Wux5U3GsP7fGqhZNA(MainActivity mainActivity, DialogInterface dialogInterface, int i) {
        mainActivity.lambda$pickOmrImage$64(dialogInterface, i);
    }

    public static /* synthetic */ void $r8$lambda$i9wDYbEnR6egWPxOiSZN0aVN9wQ(MainActivity mainActivity) {
        mainActivity.lambda$showServerSetup$7();
    }

    public static /* synthetic */ void $r8$lambda$iI7GoOSRifm92vNceksnLbGJWZU(MainActivity mainActivity, int i) {
        mainActivity.lambda$examCard$17(i);
    }

    /* renamed from: $r8$lambda$i_a6AvNDiBXxTZKTm78au_6b-Nw, reason: not valid java name */
    public static /* synthetic */ void m23$r8$lambda$i_a6AvNDiBXxTZKTm78au_6bNw(MainActivity mainActivity, View view) {
        mainActivity.lambda$buildChrome$2(view);
    }

    /* renamed from: $r8$lambda$jJPEH3-PcXkDqIzTxV9Fhl_EeBE, reason: not valid java name */
    public static /* synthetic */ void m24$r8$lambda$jJPEH3PcXkDqIzTxV9Fhl_EeBE(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$openReview$34(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$jLV7OY3lV5mzNXRgu8L_0VqoNno(MainActivity mainActivity, View view) {
        mainActivity.lambda$showResult$36(view);
    }

    /* renamed from: $r8$lambda$m3lsu8G5HN-pHUYYndr85xWmR9A, reason: not valid java name */
    public static /* synthetic */ void m25$r8$lambda$m3lsu8G5HNpHUYYndr85xWmR9A(MainActivity mainActivity, Uri uri, int i) {
        mainActivity.lambda$uploadOmr$67(uri, i);
    }

    public static /* synthetic */ void $r8$lambda$m56PDYpOHzMlyez64Y0GOL4J8II(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadDashboard$43(jSONObject);
    }

    /* renamed from: $r8$lambda$myy9qwAU3ATs3vv_W-5rsVpbHns, reason: not valid java name */
    public static /* synthetic */ void m26$r8$lambda$myy9qwAU3ATs3vv_W5rsVpbHns(MainActivity mainActivity) {
        mainActivity.lambda$showLeaderboard$55();
    }

    /* renamed from: $r8$lambda$ntH3IHAktNMLi4Dw8zPr-wXNpNM, reason: not valid java name */
    public static /* synthetic */ void m27$r8$lambda$ntH3IHAktNMLi4Dw8zPrwXNpNM(MainActivity mainActivity, String str) {
        mainActivity.lambda$showPaper$32(str);
    }

    public static /* synthetic */ void $r8$lambda$pEmwZsAaw8ftfF6rZarYd0ory40(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$24(i, view);
    }

    public static /* synthetic */ void $r8$lambda$pFqfxWgSoQFHZ96W4XRx_ElOtRo(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$showLeaderboard$56(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$ptoRKQreobGPaEca0trCMcf7IPs(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$22(i, view);
    }

    public static /* synthetic */ void $r8$lambda$qlnM2nkUQ8JhlqZAfyJk2fThPOc(MainActivity mainActivity, View view) {
        mainActivity.lambda$showMore$50(view);
    }

    public static /* synthetic */ void $r8$lambda$riu3oR40kA9mVCKP44SG4N5s8RU(MainActivity mainActivity) {
        mainActivity.lambda$showMore$53();
    }

    public static /* synthetic */ void $r8$lambda$snoPc7xct8tE9DiCVLIdxBBocYc(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$chooseOmr$28(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$t3EL8yGV6KLbWym2tWM9A__glhE(MainActivity mainActivity, String str, View view) {
        mainActivity.lambda$buildChrome$4(str, view);
    }

    public static /* synthetic */ void $r8$lambda$u7CpVbkWwcleUspyqLyngtnNYfQ(MainActivity mainActivity) {
        mainActivity.lambda$showMore$51();
    }

    public static /* synthetic */ void $r8$lambda$uO_c6ZwX47u8NeWxxojOvjddZh0(MainActivity mainActivity, View view) {
        mainActivity.lambda$loadPractice$39(view);
    }

    public static /* synthetic */ void $r8$lambda$uiUPA8FJbr1k_X6OJlPzFiqk2do(MainActivity mainActivity, View view) {
        mainActivity.lambda$showMore$52(view);
    }

    public static /* synthetic */ void $r8$lambda$uvT9rO7jFFZ8VBzxrKIhbp9jivA(MainActivity mainActivity, View view) {
        mainActivity.lambda$showFace$62(view);
    }

    /* renamed from: $r8$lambda$vz_I9ZY5P7ilFAaEXOG-VA5ZjyI, reason: not valid java name */
    public static /* synthetic */ void m28$r8$lambda$vz_I9ZY5P7ilFAaEXOGVA5ZjyI(MainActivity mainActivity, JSONObject jSONObject) throws Exception {
        mainActivity.lambda$loadBatches$46(jSONObject);
    }

    public static /* synthetic */ void $r8$lambda$yMVZ_58o5d6h0ytsvBH0P7p3kpw(MainActivity mainActivity, int i, View view) {
        mainActivity.lambda$examCard$23(i, view);
    }

    public static /* synthetic */ void $r8$lambda$zgO_gN3t5W85FjtHqs8UPu7hWyA(MainActivity mainActivity) {
        mainActivity.lambda$showReceipt$31();
    }

    /* renamed from: -$$Nest$fgetprefs, reason: not valid java name */
    static /* bridge */ /* synthetic */ SharedPreferences m29$$Nest$fgetprefs(MainActivity mainActivity) {
        return mainActivity.prefs;
    }

    /* renamed from: -$$Nest$fgetscreenToken, reason: not valid java name */
    static /* bridge */ /* synthetic */ int m30$$Nest$fgetscreenToken(MainActivity mainActivity) {
        return mainActivity.screenToken;
    }

    /* renamed from: -$$Nest$fgettab, reason: not valid java name */
    static /* bridge */ /* synthetic */ String m31$$Nest$fgettab(MainActivity mainActivity) {
        return mainActivity.tab;
    }

    /* renamed from: -$$Nest$fputtimer, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m32$$Nest$fputtimer(MainActivity mainActivity, CountDownTimer countDownTimer) {
        mainActivity.timer = countDownTimer;
    }

    /* renamed from: -$$Nest$mbusy, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m33$$Nest$mbusy(MainActivity mainActivity, String str) {
        mainActivity.busy(str);
    }

    /* renamed from: -$$Nest$mclearLogin, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m34$$Nest$mclearLogin(MainActivity mainActivity) {
        mainActivity.clearLogin();
    }

    /* renamed from: -$$Nest$mclock, reason: not valid java name */
    static /* bridge */ /* synthetic */ String m35$$Nest$mclock(MainActivity mainActivity, int i) {
        return mainActivity.clock(i);
    }

    /* renamed from: -$$Nest$mconfirm, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m36$$Nest$mconfirm(MainActivity mainActivity, String str, String str2, Runnable runnable) {
        mainActivity.confirm(str, str2, runnable);
    }

    /* renamed from: -$$Nest$mdp, reason: not valid java name */
    static /* bridge */ /* synthetic */ int m37$$Nest$mdp(MainActivity mainActivity, float f) {
        return mainActivity.dp(f);
    }

    /* renamed from: -$$Nest$merrorPage, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m38$$Nest$merrorPage(MainActivity mainActivity, String str, Runnable runnable) {
        mainActivity.errorPage(str, runnable);
    }

    /* renamed from: -$$Nest$mhideBusy, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m39$$Nest$mhideBusy(MainActivity mainActivity) {
        mainActivity.hideBusy();
    }

    /* renamed from: -$$Nest$mopenLive, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m40$$Nest$mopenLive(MainActivity mainActivity, JSONObject jSONObject) {
        mainActivity.openLive(jSONObject);
    }

    /* renamed from: -$$Nest$mroute, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m41$$Nest$mroute(MainActivity mainActivity) {
        mainActivity.route();
    }

    /* renamed from: -$$Nest$msetScreen, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m42$$Nest$msetScreen(MainActivity mainActivity, String str, View view, boolean z, Runnable runnable, Runnable runnable2) {
        mainActivity.setScreen(str, view, z, runnable, runnable2);
    }

    /* renamed from: -$$Nest$mshowError, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m43$$Nest$mshowError(MainActivity mainActivity, String str) {
        mainActivity.showError(str);
    }

    /* renamed from: -$$Nest$mshowMain, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m44$$Nest$mshowMain(MainActivity mainActivity, String str) {
        mainActivity.showMain(str);
    }

    /* renamed from: -$$Nest$mshowReceipt, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m45$$Nest$mshowReceipt(MainActivity mainActivity, String str) {
        mainActivity.showReceipt(str);
    }

    /* renamed from: -$$Nest$mshowResult, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m46$$Nest$mshowResult(MainActivity mainActivity, String str, JSONObject jSONObject, JSONArray jSONArray) {
        mainActivity.showResult(str, jSONObject, jSONArray);
    }

    /* renamed from: -$$Nest$mstartFace, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m47$$Nest$mstartFace(MainActivity mainActivity, String str, int i, Runnable runnable) {
        mainActivity.startFace(str, i, runnable);
    }

    /* renamed from: -$$Nest$mstartLive, reason: not valid java name */
    static /* bridge */ /* synthetic */ void m48$$Nest$mstartLive(MainActivity mainActivity, int i) {
        mainActivity.startLive(i);
    }

    /* renamed from: -$$Nest$smarr, reason: not valid java name */
    static /* bridge */ /* synthetic */ JSONArray m49$$Nest$smarr(JSONObject jSONObject, String str) {
        return arr(jSONObject, str);
    }

    /* renamed from: -$$Nest$smat, reason: not valid java name */
    static /* bridge */ /* synthetic */ JSONObject m50$$Nest$smat(JSONArray jSONArray, int i) {
        return at(jSONArray, i);
    }

    /* renamed from: -$$Nest$smjson, reason: not valid java name */
    static /* bridge */ /* synthetic */ JSONObject m51$$Nest$smjson(Object[] objArr) {
        return json(objArr);
    }

    /* renamed from: -$$Nest$smstr, reason: not valid java name */
    static /* bridge */ /* synthetic */ String m52$$Nest$smstr(JSONObject jSONObject, String str) {
        return str(jSONObject, str);
    }

    private Api.Callback actCb(Ok ok) {
        return new AnonymousClass1(ok);
    }

    private static JSONArray arr(JSONObject jSONObject, String str) {
        JSONArray optJSONArray = jSONObject.optJSONArray(str);
        return optJSONArray == null ? new JSONArray() : optJSONArray;
    }

    private static JSONObject at(JSONArray jSONArray, int i) {
        JSONObject optJSONObject = jSONArray.optJSONObject(i);
        return optJSONObject == null ? new JSONObject() : optJSONObject;
    }

    private void buildChrome() {
        LinearLayout vbox = Ui.vbox(this);
        vbox.setBackgroundColor(Ui.BG);
        this.header = Ui.hbox(this);
        this.header.setBackgroundColor(Ui.BG);
        this.header.setPadding(dp(14.0f), dp(14.0f), dp(14.0f), dp(8.0f));
        this.backBtn = Ui.tv(this, "←", 20.0f, Ui.INK, true);
        this.backBtn.setGravity(Gravity.CENTER);
        this.backBtn.setBackground(Ui.box(this, Ui.WHITE, 0, 16.0f));
        this.backBtn.setOnClickListener(new MainActivity$$ExternalSyntheticLambda5(this));
        Ui.press(this.backBtn);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(46.0f), dp(46.0f));
        bl.rightMargin = dp(12.0f);
        this.header.addView(this.backBtn, bl);
        this.titleView = Ui.tv(this, "Prottasha Academy", 22.0f, Ui.INK, true);
        this.header.addView(this.titleView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView refresh = Ui.tv(this, "↻", 20.0f, Ui.INK, true);
        refresh.setGravity(Gravity.CENTER);
        refresh.setBackground(Ui.box(this, Ui.WHITE, 0, 16.0f));
        refresh.setOnClickListener(new MainActivity$$ExternalSyntheticLambda6(this));
        Ui.press(refresh);
        this.header.addView(refresh, new LinearLayout.LayoutParams(dp(46.0f), dp(46.0f)));
        vbox.addView(this.header, new LinearLayout.LayoutParams(-1, -2));
        this.content = new FrameLayout(this);
        vbox.addView(this.content, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        this.nav = Ui.hbox(this);
        this.nav.setBackground(Ui.box(this, Ui.INK, 0, 26.0f));
        this.nav.setPadding(dp(6.0f), dp(6.0f), dp(6.0f), dp(6.0f));
        this.nav.setElevation(dp(8.0f));
        for (int i = 0; i < TABS.length; i++) {
            String key = TABS[i][0];
            TextView item = Ui.tv(this, TABS[i][2], 11.0f, 0xFFB9B6E0, true);
            item.setGravity(17);
            item.setCompoundDrawablePadding(dp(2.0f));
            Drawable ico = getDrawable(drawableId(TABS[i][1])).mutate();
            item.setCompoundDrawablesWithIntrinsicBounds(null, ico, null, null);
            item.setCompoundDrawableTintList(ColorStateList.valueOf(0xFFB9B6E0));
            item.setPadding(0, dp(8.0f), 0, dp(8.0f));
            item.setOnClickListener(new MainActivity$$ExternalSyntheticLambda7(this, key));
            this.navItems[i] = item;
            this.nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1.0f));
        }
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(-1, -2);
        navLp.setMargins(dp(12.0f), dp(4.0f), dp(12.0f), dp(12.0f));
        vbox.addView(this.nav, navLp);
        final FrameLayout root = new FrameLayout(this);
        root.addView(vbox, new FrameLayout.LayoutParams(-1, -1));
        final View splash = buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        this.splashShowing = true;
        statusBar(true);
        splash.postDelayed(new Runnable() {
            @Override
            public void run() {
                splash.animate().alpha(0f).setDuration(350).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        root.removeView(splash);
                        MainActivity.this.splashShowing = false;
                        MainActivity.this.statusBar(MainActivity.this.inkStatus);
                    }
                }).start();
            }
        }, 1500);
    }

    private void statusBar(boolean ink) {
        this.inkStatus = ink;
        if (this.splashShowing) {
            ink = true;
        }
        getWindow().setStatusBarColor(ink ? Ui.INK : Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        View d = getWindow().getDecorView();
        int f = d.getSystemUiVisibility();
        f = ink ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        d.setSystemUiVisibility(f);
    }

    private String bn(Object o) {
        String s = String.valueOf(o);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            sb.append(ch >= '0' && ch <= '9' ? (char) (0x09E6 + (ch - '0')) : ch);
        }
        return sb.toString();
    }

    private View pageHeader(String small, String big) {
        LinearLayout h = Ui.vbox(this);
        h.setPadding(dp(4.0f), dp(4.0f), 0, dp(14.0f));
        h.addView(Ui.tv(this, small, 13.0f, Ui.MUTED, false));
        h.addView(Ui.tv(this, big, 28.0f, Ui.INK, true));
        return h;
    }

    private LinearLayout tabBox(String small, String big) {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(dp(18.0f), dp(26.0f), dp(18.0f), dp(24.0f));
        box.addView(pageHeader(small, big));
        return box;
    }

    private View segmented(String[] labels, int selected, final java.util.function.IntConsumer onPick) {
        LinearLayout seg = Ui.hbox(this);
        seg.setBackground(Ui.box(this, 0xFFE4E1F5, 0, 18.0f));
        seg.setPadding(dp(4.0f), dp(4.0f), dp(4.0f), dp(4.0f));
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean on = i == selected;
            TextView t = Ui.tv(this, labels[i], 15.0f, Ui.INK, on);
            t.setGravity(Gravity.CENTER);
            if (on) {
                t.setBackground(Ui.box(this, Ui.WHITE, 0, 14.0f));
            }
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onPick.accept(idx);
                }
            });
            seg.addView(t, new LinearLayout.LayoutParams(0, dp(44.0f), 1.0f));
        }
        return seg;
    }

    private Dialog sheet(View content) {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(1);
        ScrollView sv = new ScrollView(this);
        sv.addView(content, new FrameLayout.LayoutParams(-1, -2));
        d.setContentView(sv);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0));
            w.setLayout(-1, -2);
            w.setGravity(Gravity.BOTTOM);
            w.setSoftInputMode(16);
            w.getAttributes().windowAnimations = android.R.style.Animation_InputMethod;
        }
        d.show();
        return d;
    }

    private LinearLayout sheetBody() {
        LinearLayout c = Ui.vbox(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Ui.WHITE);
        float r = dp(32.0f);
        g.setCornerRadii(new float[]{r, r, r, r, 0f, 0f, 0f, 0f});
        c.setBackground(g);
        c.setPadding(dp(22.0f), dp(26.0f), dp(22.0f), dp(26.0f));
        return c;
    }

    private void confirm(String title, String message, final Runnable ok) {
        final Dialog[] hold = new Dialog[1];
        LinearLayout c = sheetBody();
        c.addView(Ui.tv(this, title, 22.0f, Ui.INK, true));
        TextView m = Ui.tv(this, message, 14.0f, Ui.MUTED, false);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
        ml.topMargin = dp(6.0f);
        ml.bottomMargin = dp(18.0f);
        c.addView(m, ml);
        Ui.add(c, Ui.primary(this, "হ্যাঁ", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hold[0].dismiss();
                if (ok != null) {
                    ok.run();
                }
            }
        }), 10);
        Ui.add(c, Ui.btn(this, "না", Ui.WHITE, Ui.INK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hold[0].dismiss();
            }
        }), 0);
        hold[0] = sheet(c);
    }

    private void submitSheet(int answered, int left, final Runnable ok) {
        final Dialog[] hold = new Dialog[1];
        LinearLayout c = sheetBody();
        c.addView(Ui.tv(this, "পরীক্ষা জমা দেবে?", 22.0f, Ui.INK, true));
        TextView m = Ui.tv(this, "জমা দেওয়ার পর আর উত্তর বদলানো যাবে না।", 14.0f, Ui.MUTED, false);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
        ml.topMargin = dp(6.0f);
        ml.bottomMargin = dp(18.0f);
        c.addView(m, ml);
        LinearLayout tiles = Ui.hbox(this);
        tiles.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams t1 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        t1.rightMargin = dp(10.0f);
        tiles.addView(statTile(bn(answered), "উত্তর দিয়েছো", Ui.GREEN_BG, 0xFF0B5C40), t1);
        tiles.addView(statTile(bn(left), "বাকি আছে", Ui.AMBER_BG, 0xFF7A4E00), new LinearLayout.LayoutParams(0, -2, 1.0f));
        Ui.add(c, tiles, 18);
        Ui.add(c, Ui.primary(this, "হ্যাঁ, জমা দাও", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hold[0].dismiss();
                ok.run();
            }
        }), 10);
        Ui.add(c, Ui.btn(this, "ফিরে যাও", Ui.WHITE, Ui.INK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hold[0].dismiss();
            }
        }), 0);
        hold[0] = sheet(c);
    }

    private int drawableId(String name) {
        return getResources().getIdentifier(name, "drawable", getPackageName());
    }

    private void styleNav(String active) {
        for (int i = 0; i < TABS.length; i++) {
            boolean on = TABS[i][0].equals(active);
            TextView t = this.navItems[i];
            t.setTextColor(on ? -1 : 0xFFB9B6E0);
            t.setCompoundDrawableTintList(ColorStateList.valueOf(on ? Ui.ACCENT : 0xFFB9B6E0));
            t.setBackground(on ? Ui.box(this, 0x24FFFFFF, 0, 20.0f) : null);
        }
    }

    private View buildSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Ui.INK);
        f.setClickable(true);
        LinearLayout col = Ui.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleX(0.6f);
        logo.setScaleY(0.6f);
        logo.setAlpha(0f);
        col.addView(logo, new LinearLayout.LayoutParams(dp(150.0f), dp(150.0f)));
        TextView name = Ui.tv(this, "প্রত্যাশা একাডেমি", 28.0f, -1, true);
        name.setGravity(Gravity.CENTER);
        name.setAlpha(0f);
        TextView sub = Ui.tv(this, "Prottasha Academy", 14.0f, 0xFFB9B6E0, false);
        sub.setGravity(Gravity.CENTER);
        sub.setAlpha(0f);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
        nl.topMargin = dp(18.0f);
        col.addView(name, nl);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.topMargin = dp(4.0f);
        col.addView(sub, sl);
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(-1, -2);
        cl.gravity = Gravity.CENTER;
        f.addView(col, cl);
        FrameLayout track = new FrameLayout(this);
        track.setBackground(Ui.box(this, 0x1FFFFFFF, 0, 3.0f));
        View fill = new View(this);
        fill.setBackground(Ui.box(this, Ui.ACCENT, 0, 3.0f));
        fill.setPivotX(0f);
        fill.setScaleX(0f);
        track.addView(fill, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(dp(140.0f), dp(5.0f));
        tl.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        tl.bottomMargin = dp(70.0f);
        f.addView(track, tl);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(800).setInterpolator(new OvershootInterpolator()).start();
        name.animate().alpha(1f).setStartDelay(500).setDuration(500).start();
        sub.animate().alpha(1f).setStartDelay(650).setDuration(500).start();
        fill.animate().scaleX(1f).setStartDelay(200).setDuration(1300).start();
        return f;
    }

    private AlertDialog styled(AlertDialog d) {
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(Ui.box(this, Ui.WHITE, 0, 24.0f));
        }
        int[] ids = {DialogInterface.BUTTON_POSITIVE, DialogInterface.BUTTON_NEGATIVE, DialogInterface.BUTTON_NEUTRAL};
        for (int id : ids) {
            Button b = d.getButton(id);
            if (b != null) {
                b.setTextColor(Ui.INDIGO);
                b.setAllCaps(false);
                b.setTypeface(Ui.display(MainActivity.this));
            }
        }
        return d;
    }

    private void busy(String str) {
        hideBusy();
        this.busyDialog = styled(new AlertDialog.Builder(this).setMessage(str).setCancelable(false).show());
    }

    private View centered(String str) {
        FrameLayout f = new FrameLayout(this);
        LinearLayout col = Ui.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(ColorStateList.valueOf(Ui.INDIGO));
        col.addView(pb, new LinearLayout.LayoutParams(dp(44.0f), dp(44.0f)));
        TextView tv = Ui.tv(this, str, 15.0f, Ui.MUTED, false);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(24.0f), dp(14.0f), dp(24.0f), 0);
        col.addView(tv, new LinearLayout.LayoutParams(-2, -2));
        f.addView(col, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        return f;
    }

    private void chooseOmr(int i) {
        busy("অপেক্ষা করো…");
        Api.call("POST", "/online/exams/" + i + "/choose", json("mode", "omr"), actCb(new MainActivity$$ExternalSyntheticLambda35(this)));
    }

    private void clearLogin() {
        Api.token = null;
        this.prefs.edit().remove("token").remove("uid").remove("name").remove("email").remove("role").apply();
    }

    private String clock(int i) {
        return bn(clockAscii(i));
    }

    private String clockAscii(int i) {
        int max = Math.max(0, i);
        int i2 = max / 3600;
        int i3 = (max % 3600) / 60;
        int i4 = max % 60;
        Locale locale = Locale.US;
        return i2 > 0 ? String.format(locale, "%d:%02d:%02d", Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf(i4)) : String.format(locale, "%02d:%02d", Integer.valueOf(i3), Integer.valueOf(i4));
    }

    private byte[] compress(Uri uri) throws Exception {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream openInputStream = getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(openInputStream, null, options);
        openInputStream.close();
        int i = 1;
        while (Math.max(options.outWidth, options.outHeight) / i > 3200) {
            i *= 2;
        }
        BitmapFactory.Options options2 = new BitmapFactory.Options();
        options2.inSampleSize = i;
        InputStream openInputStream2 = getContentResolver().openInputStream(uri);
        Bitmap decodeStream = BitmapFactory.decodeStream(openInputStream2, null, options2);
        openInputStream2.close();
        if (decodeStream == null) {
            throw new Exception("decode failed");
        }
        int i2 = 0;
        try {
            InputStream openInputStream3 = getContentResolver().openInputStream(uri);
            int attributeInt = new ExifInterface(openInputStream3).getAttributeInt("Orientation", 1);
            openInputStream3.close();
            if (attributeInt == 6) {
                i2 = 90;
            } else if (attributeInt == 3) {
                i2 = 180;
            } else if (attributeInt == 8) {
                i2 = 270;
            }
        } catch (Exception e) {
        }
        int i3 = i2;
        float min = Math.min(1.0f, 2400.0f / Math.max(decodeStream.getWidth(), decodeStream.getHeight()));
        if (i3 != 0 || min < 1.0f) {
            Matrix matrix = new Matrix();
            if (i3 != 0) {
                matrix.postRotate(i3);
            }
            if (min < 1.0f) {
                matrix.postScale(min, min);
            }
            decodeStream = Bitmap.createBitmap(decodeStream, 0, 0, decodeStream.getWidth(), decodeStream.getHeight(), matrix, true);
        }
        int i4 = 88;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        decodeStream.compress(Bitmap.CompressFormat.JPEG, 88, byteArrayOutputStream);
        while (byteArrayOutputStream.size() > 7340032 && i4 > 40) {
            i4 -= 15;
            byteArrayOutputStream.reset();
            decodeStream.compress(Bitmap.CompressFormat.JPEG, i4, byteArrayOutputStream);
        }
        return byteArrayOutputStream.toByteArray();
    }

    private int dp(float f) {
        return Ui.dp(this, f);
    }

    private void errorPage(String str, Runnable runnable) {
        LinearLayout pageBox = pageBox();
        pageBox.setGravity(1);
        pageBox.setPadding(dp(24.0f), dp(60.0f), dp(24.0f), dp(24.0f));
        TextView tv = Ui.tv(this, str, 16.0f, 0xFFD6393F, false);
        tv.setGravity(17);
        Ui.add(pageBox, tv, 16);
        if (runnable != null) {
            Ui.add(pageBox, Ui.primary(this, "আবার চেষ্টা করো", new MainActivity$$ExternalSyntheticLambda70(runnable)));
        }
        setPage(pageBox);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    private String stateText(String s) {
        if ("open".equals(s)) {
            return "খোলা";
        }
        if ("in_progress".equals(s)) {
            return "চলছে";
        }
        if ("omr".equals(s)) {
            return "OMR";
        }
        if ("done".equals(s)) {
            return "শেষ";
        }
        if ("upcoming".equals(s)) {
            return "আসন্ন";
        }
        if ("locked".equals(s)) {
            return "লক";
        }
        if ("closed".equals(s)) {
            return "বন্ধ";
        }
        if ("expired".equals(s)) {
            return "মেয়াদ শেষ";
        }
        return "পরীক্ষা";
    }

    private int stateBg(String s) {
        if ("open".equals(s)) {
            return Ui.GREEN_BG;
        }
        if ("in_progress".equals(s)) {
            return Ui.INDIGO;
        }
        if ("omr".equals(s)) {
            return 0xFFDDEBFF;
        }
        if ("upcoming".equals(s)) {
            return Ui.AMBER_BG;
        }
        if ("expired".equals(s)) {
            return Ui.RED_BG;
        }
        return 0xFFECEAF8;
    }

    private int stateFg(String s) {
        if ("open".equals(s)) {
            return 0xFF0B5C40;
        }
        if ("in_progress".equals(s)) {
            return -1;
        }
        if ("omr".equals(s)) {
            return 0xFF1F5FBF;
        }
        if ("upcoming".equals(s)) {
            return 0xFF7A4E00;
        }
        if ("expired".equals(s)) {
            return 0xFF8E2415;
        }
        return 0xFF3D3A66;
    }

    private void act(LinearLayout card, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10.0f);
        card.addView(v, lp);
    }

    private void note(LinearLayout card, String text, int color, boolean bold) {
        TextView t = Ui.tv(this, text, 13.0f, color, bold);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10.0f);
        card.addView(t, lp);
    }

    private View examCard(JSONObject e) {
        final int id = e.optInt("id");
        String state = e.optString("state");
        String mode = e.optString("mode", "online");
        String choice = str(e, "choice");
        boolean omrLook = "omr".equals(mode) || "omr".equals(state);
        LinearLayout card = Ui.card(this);
        card.setPadding(dp(14.0f), dp(14.0f), dp(14.0f), dp(14.0f));
        LinearLayout head = Ui.hbox(this);
        head.addView(iconTile(omrLook ? "ic_exam" : "ic_live", omrLook ? 0xFFDDEBFF : 0xFFE4E1FF, omrLook ? 0xFF1F5FBF : 0xFF4A3FD1, 44, 22, 14.0f));
        LinearLayout tx = Ui.vbox(this);
        tx.setPadding(dp(12.0f), 0, dp(8.0f), 0);
        tx.addView(Ui.tv(this, e.optString("title"), 16.0f, Ui.INK, true));
        if (!str(e, "batch_name").isEmpty()) {
            tx.addView(Ui.tv(this, e.optString("batch_name"), 12.0f, Ui.MUTED, false));
        }
        head.addView(tx, new LinearLayout.LayoutParams(0, -2, 1.0f));
        head.addView(Ui.pill(this, stateText(state), stateBg(state), stateFg(state)));
        card.addView(head, new LinearLayout.LayoutParams(-1, -2));
        String meta = bn(e.optInt("questions")) + " টি প্রশ্ন, " + bn(Math.max(1, e.optInt("time_limit_seconds") / 60)) + " মিনিট, " + ("omr".equals(mode) ? "OMR" : "both".equals(mode) ? "অনলাইন বা OMR" : "অনলাইন");
        if (!str(e, "end_time").isEmpty()) {
            meta = meta + "\nশেষ সময়: " + when(e.optString("end_time"));
        }
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
        ml.topMargin = dp(12.0f);
        TextView metaView = Ui.tv(this, meta, 12.0f, Ui.MUTED, false);
        metaView.setLineSpacing(0f, 1.3f);
        card.addView(metaView, ml);
        View divider = new View(this);
        divider.setBackgroundColor(Ui.TRACK);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(1.0f));
        dl.topMargin = dp(12.0f);
        card.addView(divider, dl);

        if ("open".equals(state)) {
            if ("online".equals(mode) || "online".equals(choice)) {
                act(card, Ui.primary(this, "পরীক্ষা শুরু করো", new MainActivity$$ExternalSyntheticLambda45(this, id)));
            } else {
                if ("both".equals(mode)) {
                    note(card, "একবার বেছে নিলে আর বদলানো যাবে না।", Ui.AMBER, false);
                    act(card, Ui.primary(this, "অনলাইনে দেবো", new MainActivity$$ExternalSyntheticLambda46(this, id)));
                }
                act(card, Ui.secondary(this, "OMR-এ দেবো", new MainActivity$$ExternalSyntheticLambda47(this, id)));
            }
        } else if ("in_progress".equals(state)) {
            note(card, "পরীক্ষা চলছে, বাকি " + clock(e.optInt("remaining_seconds")), Ui.AMBER, true);
            act(card, Ui.primary(this, "চালিয়ে যাও", new MainActivity$$ExternalSyntheticLambda48(this, id)));
        } else if ("omr".equals(state)) {
            String sub = str(e, "omr_submission");
            note(card, "published".equals(sub) ? "ফলাফল প্রকাশিত" : "uploaded".equals(sub) ? "OMR শিট জমা হয়েছে — স্ক্যানের অপেক্ষায়" : "error".equals(sub) ? "শিটে সমস্যা পাওয়া গেছে — আবার ছবি তুলে জমা দাও" : "তুমি OMR-এ পরীক্ষা দিচ্ছো। উত্তর OMR শিটে দিয়ে ছবি জমা দাও।", Ui.INDIGO, true);
            act(card, Ui.secondary(this, "প্রশ্নপত্র দেখো", new MainActivity$$ExternalSyntheticLambda49(this, id)));
            if (!"published".equals(sub)) {
                act(card, Ui.primary(this, "📷 OMR শিটের ছবি জমা দাও", new MainActivity$$ExternalSyntheticLambda50(this, id)));
            }
        } else if ("done".equals(state)) {
            JSONObject res = e.optJSONObject("result");
            if (res != null) {
                note(card, "নম্বর: " + num(res.optDouble("marks")) + " / " + num(res.optDouble("max_marks")) + "\nসঠিক " + res.optInt("right") + ", ভুল " + res.optInt("wrong") + ", বাদ " + res.optInt("skipped") + "\nর\u200d্যাঙ্ক: " + res.optInt("rank") + " / " + res.optInt("participants"), Ui.GREEN, true);
                act(card, Ui.secondary(this, "উত্তর ও ব্যাখ্যা দেখো", new MainActivity$$ExternalSyntheticLambda51(this, res.optInt("result_id"), "published".equals(str(e, "omr_submission")))));
            } else {
                note(card, e.optBoolean("result_hidden") ? str(e, "result_note") : "তোমার উত্তর জমা হয়েছে।", Ui.INDIGO, true);
            }
        } else if ("upcoming".equals(state)) {
            note(card, "এখনো শুরু হয়নি" + (str(e, "start_time").isEmpty() ? "" : " — শুরু: " + when(e.optString("start_time"))), Ui.AMBER, true);
        } else if ("locked".equals(state)) {
            note(card, "🔒 এই পরীক্ষা তোমার ব্যাচের নয়।", Ui.MUTED, false);
            act(card, Ui.secondary(this, "ব্যাচে যোগ দাও", new MainActivity$$ExternalSyntheticLambda52(this)));
        } else if ("closed".equals(state)) {
            note(card, "সময়সীমা শেষ।", Ui.MUTED, true);
        } else if ("expired".equals(state)) {
            note(card, "সময় শেষ হয়ে গেছে, উত্তর জমা হয়নি।", Ui.RED, true);
        } else {
            note(card, "এখনও প্রশ্ন যোগ করা হয়নি।", Ui.MUTED, false);
        }
        return card;
    }

    private void renderExams(JSONObject j) {
        this.lastExams = j;
        LinearLayout box = tabBox("তোমার সব পরীক্ষা", "পরীক্ষা");
        JSONArray all = arr(j, "exams");
        LinearLayout chips = Ui.hbox(this);
        String[][] fs = {{"all", "সব"}, {"online", "লাইভ"}, {"omr", "OMR"}};
        for (final String[] f : fs) {
            boolean on = f[0].equals(this.examFilter);
            TextView c = Ui.tv(this, f[1], 14.0f, on ? -1 : Ui.INK, true);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(18.0f), dp(11.0f), dp(18.0f), dp(11.0f));
            c.setBackground(Ui.box(this, on ? Ui.INK : Ui.WHITE, 0, 22.0f));
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MainActivity.this.examFilter = f[0];
                    renderExams(MainActivity.this.lastExams);
                }
            });
            Ui.press(c);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dp(8.0f);
            chips.addView(c, lp);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(chips);
        Ui.add(box, hs, 8);
        int shown = 0;
        for (int g = 0; g < 2; g++) {
            boolean wantActive = g == 0;
            int inGroup = 0;
            for (int i = 0; i < all.length(); i++) {
                JSONObject e = at(all, i);
                String st = e.optString("state");
                boolean isActive = "open".equals(st) || "in_progress".equals(st) || "upcoming".equals(st) || "omr".equals(st);
                if (isActive != wantActive) {
                    continue;
                }
                String mode = e.optString("mode", "online");
                boolean match = "all".equals(this.examFilter)
                        || ("online".equals(this.examFilter) && ("online".equals(mode) || "both".equals(mode)))
                        || ("omr".equals(this.examFilter) && ("omr".equals(mode) || "both".equals(mode) || "omr".equals(st)));
                if (!match) {
                    continue;
                }
                if (inGroup == 0) {
                    box.addView(sectionTitle(wantActive ? "চলছে ও আসন্ন" : "অন্যান্য ও শেষ হয়েছে"));
                }
                Ui.add(box, examCard(e), 12);
                inGroup++;
                shown++;
            }
        }
        if (shown == 0) {
            Ui.add(box, Ui.tv(this, all.length() == 0 ? "এখন কোনো পরীক্ষা নেই। 'ব্যাচ' ট্যাব থেকে ব্যাচে যোগ দাও।" : "এই ফিল্টারে কোনো পরীক্ষা নেই।", 15.0f, Ui.MUTED, false));
        }
        setPage(box);
    }

    private static String fmtUtc(String str) {
        try {
            String replace = str.replace(' ', 'T');
            if (replace.length() > 19) {
                replace = replace.substring(0, 19);
            }
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            return new SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(simpleDateFormat.parse(replace));
        } catch (Exception e) {
            return str;
        }
    }

    private void hideBusy() {
        if (this.busyDialog != null) {
            try {
                this.busyDialog.dismiss();
            } catch (Exception e) {
            }
            this.busyDialog = null;
        }
    }

    private static JSONObject json(Object... objArr) {
        JSONObject jSONObject = new JSONObject();
        for (int i = 0; i + 1 < objArr.length; i += 2) {
            try {
                jSONObject.put((String) objArr[i], objArr[i + 1]);
            } catch (Exception e) {
            }
        }
        return jSONObject;
    }

    private /* synthetic */ void lambda$buildChrome$2(View view) {
        onBackPressed();
    }

    private /* synthetic */ void lambda$buildChrome$3(View view) {
        if (this.refreshAction != null) {
            this.refreshAction.run();
        }
    }

    private /* synthetic */ void lambda$buildChrome$4(String str, View view) {
        showMain(str);
    }

    private /* synthetic */ void lambda$chooseOmr$28(JSONObject jSONObject) throws Exception {
        showMain("exams");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$confirm$0(Runnable runnable, DialogInterface dialogInterface, int i) {
        runnable.run();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$errorPage$5(Runnable runnable, View view) {
        runnable.run();
    }

    private /* synthetic */ void lambda$examCard$17(int i) {
        startLive(i);
    }

    private /* synthetic */ void lambda$examCard$18(int i, View view) {
        confirm("পরীক্ষা শুরু করবে?", "শুরু করলে সময় চলতে থাকবে।", new MainActivity$$ExternalSyntheticLambda42(this, i));
    }

    private /* synthetic */ void lambda$examCard$19(int i) {
        startLive(i);
    }

    private /* synthetic */ void lambda$examCard$20(int i, View view) {
        confirm("অনলাইনে পরীক্ষা দেবে?", "এই পরীক্ষা অনলাইনেই দিতে হবে, OMR-এ নয়।", new MainActivity$$ExternalSyntheticLambda3(this, i));
    }

    private /* synthetic */ void lambda$examCard$21(int i) {
        chooseOmr(i);
    }

    private /* synthetic */ void lambda$examCard$22(int i, View view) {
        confirm("OMR-এ পরীক্ষা দেবে?", "উত্তর কাগজের OMR শিটে দিয়ে ছবি তুলে জমা দিতে হবে।", new MainActivity$$ExternalSyntheticLambda18(this, i));
    }

    private /* synthetic */ void lambda$examCard$23(int i, View view) {
        startLive(i);
    }

    private /* synthetic */ void lambda$examCard$24(int i, View view) {
        showPaper(i);
    }

    private /* synthetic */ void lambda$examCard$25(int i, View view) {
        pickOmrImage(i);
    }

    private /* synthetic */ void lambda$examCard$26(int i, boolean z, View view) {
        openReview(i, z);
    }

    private /* synthetic */ void lambda$examCard$27(View view) {
        showMain("batches");
    }

    private /* synthetic */ void lambda$loadBatches$44(JSONObject jSONObject) throws Exception {
        toast(jSONObject.optString("message", "যুক্ত হয়েছো"));
        showMain("batches");
    }

    private /* synthetic */ void lambda$loadBatches$45(double d, int i, View view) {
        if (d > 0.0d) {
            paymentDialog(i);
        } else {
            busy("অপেক্ষা করো…");
            Api.call("POST", "/omr/batches/" + i + "/join", new JSONObject(), actCb(new MainActivity$$ExternalSyntheticLambda0(this)));
        }
    }

    private void joinBatch(int id, String name, double price) {
        if (price > 0.0d) {
            paymentSheet(id, name, price);
        } else {
            lambda$loadBatches$45(0.0d, id, null);
        }
    }

    private void paymentDialog(int i) {
        paymentSheet(i, "ব্যাচের ফি", -1.0d);
    }

    private void styleMethod(TextView[] mt, String sel) {
        String[] names = {"bKash", "Nagad"};
        for (int i = 0; i < 2; i++) {
            boolean on = names[i].equals(sel);
            mt[i].setBackground(Ui.box(this, on ? Ui.SOFT : Ui.WHITE, on ? Ui.INDIGO : Ui.LINE, 16.0f));
        }
    }

    private void paymentSheet(final int id, String name, double price) {
        final Dialog[] hold = new Dialog[1];
        final String[] method = {"bKash"};
        LinearLayout c = sheetBody();
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.tv(this, "পেমেন্ট করো", 22.0f, Ui.INK, true), new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView x = Ui.tv(this, "✕", 18.0f, Ui.INK, true);
        x.setGravity(Gravity.CENTER);
        x.setBackground(Ui.box(this, Ui.BG, 0, 14.0f));
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hold[0].dismiss();
            }
        });
        head.addView(x, new LinearLayout.LayoutParams(dp(44.0f), dp(44.0f)));
        Ui.add(c, head, 10);
        if (price >= 0.0d) {
            LinearLayout fee = Ui.hbox(this);
            fee.setBackground(Ui.box(this, Ui.BG, 0, 20.0f));
            fee.setPadding(dp(16.0f), dp(14.0f), dp(16.0f), dp(14.0f));
            fee.addView(Ui.tv(this, name, 14.0f, Ui.MUTED, false), new LinearLayout.LayoutParams(0, -2, 1.0f));
            fee.addView(Ui.tv(this, "৳ " + bn(num(price)), 22.0f, Ui.INK, true));
            Ui.add(c, fee, 14);
        }
        final TextView[] mt = new TextView[2];
        final String[] names = {"bKash", "Nagad"};
        final TextView step1 = Ui.tv(this, "১. bKash অ্যাপ থেকে ফি পাঠাও (Send Money)", 14.0f, 0xFF3D3A66, false);
        LinearLayout mrow = Ui.hbox(this);
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            TextView m = Ui.tv(this, names[i], 16.0f, Ui.INK, true);
            m.setGravity(Gravity.CENTER);
            m.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    method[0] = names[idx];
                    styleMethod(mt, method[0]);
                    step1.setText("১. " + method[0] + " অ্যাপ থেকে ফি পাঠাও (Send Money)");
                }
            });
            Ui.press(m);
            mt[i] = m;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52.0f), 1.0f);
            if (i == 0) {
                lp.rightMargin = dp(8.0f);
            }
            mrow.addView(m, lp);
        }
        styleMethod(mt, method[0]);
        Ui.add(c, mrow, 14);
        Ui.add(c, step1, 6);
        Ui.add(c, Ui.tv(this, price >= 0.0d ? "২. পরিমাণ লেখো ৳ " + bn(num(price)) : "২. ব্যাচের ফির পরিমাণ লেখো", 14.0f, 0xFF3D3A66, false), 6);
        Ui.add(c, Ui.tv(this, "৩. নিচে তোমার নম্বর আর Transaction ID দাও", 14.0f, 0xFF3D3A66, false), 14);
        final EditText sender = Ui.input(this, "01XXXXXXXXX", 3);
        final EditText trx = Ui.input(this, "যেমন: 8N7A6D5E4C", 1);
        Ui.add(c, labeled("যে নম্বর থেকে পাঠিয়েছো", sender), 12);
        Ui.add(c, labeled("Transaction ID", trx), 18);
        Ui.add(c, Ui.btn(this, "পেমেন্ট জমা দাও", Ui.ACCENT, Ui.INK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sender.getText().toString().trim().isEmpty() || trx.getText().toString().trim().isEmpty()) {
                    toast("নম্বর আর Transaction ID দুটোই দাও");
                    return;
                }
                EditText methodEdit = new EditText(MainActivity.this);
                methodEdit.setText(method[0]);
                hold[0].dismiss();
                lambda$paymentDialog$48(id, methodEdit, sender, trx, null, 0);
            }
        }), 0);
        hold[0] = sheet(c);
    }

    private void showBatchDetail(final JSONObject b) {
        final int id = b.optInt("id");
        final double price = b.optDouble("price");
        final String name = b.optString("name");
        String st = b.optString("state");
        boolean active = "active".equals(st);
        LinearLayout box = pageBox();
        LinearLayout hero = Ui.vbox(this);
        hero.setBackground(Ui.box(this, Ui.INK, 0, 30.0f));
        hero.setPadding(dp(20.0f), dp(20.0f), dp(20.0f), dp(20.0f));
        String badge = active ? "✓ চালু আছে" : "pending".equals(st) ? "অপেক্ষায়" : "ভর্তি চলছে";
        hero.addView(Ui.pill(this, badge, 0x29FFB020, 0xFFFFC95C), new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-1, -2);
        nl.topMargin = dp(12.0f);
        hero.addView(Ui.tv(this, name, 25.0f, -1, true), nl);
        LinearLayout stats = Ui.hbox(this);
        stats.setGravity(Gravity.TOP);
        LinearLayout t1 = Ui.vbox(this);
        t1.setBackground(Ui.box(this, 0x17FFFFFF, 0, 18.0f));
        t1.setPadding(dp(14.0f), dp(12.0f), dp(14.0f), dp(12.0f));
        t1.addView(Ui.tv(this, bn(b.optInt("exams")) + "টি", 22.0f, -1, true));
        t1.addView(Ui.tv(this, "পরীক্ষা", 12.0f, Ui.ON_INK, false));
        LinearLayout.LayoutParams t1l = new LinearLayout.LayoutParams(0, -2, 1.0f);
        t1l.rightMargin = dp(10.0f);
        stats.addView(t1, t1l);
        LinearLayout t2 = Ui.vbox(this);
        t2.setBackground(Ui.box(this, 0x29FFB020, 0, 18.0f));
        t2.setPadding(dp(14.0f), dp(12.0f), dp(14.0f), dp(12.0f));
        t2.addView(Ui.tv(this, price > 0.0d ? "৳ " + bn(num(price)) : "ফ্রি", 22.0f, 0xFFFFC95C, true));
        t2.addView(Ui.tv(this, "ফি", 12.0f, Ui.ON_INK, false));
        stats.addView(t2, new LinearLayout.LayoutParams(0, -2, 1.0f));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
        sl.topMargin = dp(18.0f);
        hero.addView(stats, sl);
        Ui.add(box, hero, 14);

        LinearLayout perks = Ui.card(this);
        perks.setBackground(Ui.box(this, Ui.WHITE, 0, 28.0f));
        perks.setPadding(dp(18.0f), dp(18.0f), dp(18.0f), dp(8.0f));
        LinearLayout.LayoutParams ph = new LinearLayout.LayoutParams(-1, -2);
        ph.bottomMargin = dp(12.0f);
        perks.addView(Ui.tv(this, "এই ব্যাচে যা পাবে", 18.0f, Ui.INK, true), ph);
        String[][] pk = {
                {"ic_live", "লাইভ পরীক্ষা", "নির্দিষ্ট সময়ে সবার সাথে", "E4E1FF", "4A3FD1"},
                {"ic_practice", "প্র্যাকটিস প্রশ্ন", "যেকোনো সময়, যতবার ইচ্ছা", "D9F5EA", "0B6B4B"},
                {"ic_omr", "OMR পরীক্ষা", "ছবি তুলে শিট জমা", "DDEBFF", "1F5FBF"},
                {"ic_result", "ফলাফল ও র\u200d্যাঙ্কিং", "বিষয় অনুযায়ী বিশ্লেষণ", "FFE1DC", "B4321F"}};
        for (String[] p : pk) {
            LinearLayout pr = Ui.hbox(this);
            pr.addView(iconTile(p[0], 0xFF000000 | Integer.parseInt(p[3], 16), 0xFF000000 | Integer.parseInt(p[4], 16), 40, 20, 13.0f));
            LinearLayout px = Ui.vbox(this);
            px.setPadding(dp(12.0f), 0, 0, 0);
            px.addView(Ui.tv(this, p[1], 15.0f, Ui.INK, true));
            px.addView(Ui.tv(this, p[2], 12.0f, Ui.MUTED, false));
            pr.addView(px, new LinearLayout.LayoutParams(0, -2, 1.0f));
            Ui.add(perks, pr, 12);
        }
        Ui.add(box, perks, 14);

        JSONArray list = arr(b, "exam_list");
        if (list.length() > 0) {
            LinearLayout sc = Ui.card(this);
            sc.setBackground(Ui.box(this, Ui.WHITE, 0, 28.0f));
            sc.setPadding(dp(18.0f), dp(18.0f), dp(18.0f), dp(8.0f));
            LinearLayout.LayoutParams sh = new LinearLayout.LayoutParams(-1, -2);
            sh.bottomMargin = dp(12.0f);
            sc.addView(Ui.tv(this, "পরীক্ষার তালিকা", 18.0f, Ui.INK, true), sh);
            for (int k = 0; k < list.length(); k++) {
                TextView row = Ui.tv(this, at(list, k).optString("title"), 14.0f, Ui.INK, true);
                row.setBackground(Ui.box(this, Ui.BG, 0, 18.0f));
                row.setPadding(dp(14.0f), dp(12.0f), dp(14.0f), dp(12.0f));
                Ui.add(sc, row, 10);
            }
            Ui.add(box, sc, 14);
        }
        if (active) {
            note(box, "✓ তুমি এই ব্যাচে আছো।", Ui.GREEN, true);
        } else if ("pending".equals(st)) {
            note(box, "⏳ পেমেন্ট অ্যাডমিনের অনুমোদনের অপেক্ষায় আছে।", Ui.AMBER, true);
        } else {
            if ("rejected".equals(st)) {
                note(box, "আগের পেমেন্ট গ্রহণ করা হয়নি। আবার চেষ্টা করো।", Ui.RED, true);
            }
            act(box, Ui.primary(this, price > 0.0d ? "ভর্তি হও, ৳ " + bn(num(price)) : "ভর্তি হও", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    joinBatch(id, name, price);
                }
            }));
        }
        setScreen("ব্যাচের বিস্তারিত", scroll(box), false, new Runnable() {
            @Override
            public void run() {
                showMain("batches");
            }
        }, null);
    }

    private /* synthetic */ void lambda$loadBatches$46(JSONObject jSONObject) throws Exception {
        LinearLayout box = pageBox();
        JSONArray arr = arr(jSONObject, "batches");
        if (arr.length() == 0) {
            Ui.add(box, Ui.tv(this, "এখনও কোনো ব্যাচ নেই।", 15.0f, Ui.MUTED, false));
        }
        for (int i = 0; i < arr.length(); i++) {
            final JSONObject b = at(arr, i);
            final int id = b.optInt("id");
            final double price = b.optDouble("price");
            String st = b.optString("state");
            boolean active = "active".equals(st);
            LinearLayout card = Ui.vbox(this);
            card.setBackground(Ui.box(this, active ? Ui.INK : Ui.WHITE, 0, 26.0f));
            card.setPadding(dp(18.0f), dp(18.0f), dp(18.0f), dp(18.0f));
            String badge = active ? "✓ চালু আছে" : "pending".equals(st) ? "অপেক্ষায়" : "rejected".equals(st) ? "আবার চেষ্টা করো" : "ভর্তি চলছে";
            int badgeBg = active ? 0x332EC4A6 : "pending".equals(st) ? Ui.AMBER_BG : "rejected".equals(st) ? Ui.RED_BG : Ui.SOFT;
            int badgeFg = active ? 0xFF5FE0C4 : "pending".equals(st) ? 0xFF7A4E00 : "rejected".equals(st) ? 0xFF8E2415 : Ui.INDIGO;
            card.addView(Ui.pill(this, badge, badgeBg, badgeFg), new LinearLayout.LayoutParams(-2, -2));
            LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-1, -2);
            nl.topMargin = dp(12.0f);
            card.addView(Ui.tv(this, b.optString("name"), 19.0f, active ? -1 : Ui.INK, true), nl);
            LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
            ml.topMargin = dp(4.0f);
            card.addView(Ui.tv(this, bn(b.optInt("exams")) + " টি পরীক্ষা, " + (price > 0.0d ? "৳" + bn(num(price)) : "ফ্রি"), 13.0f, active ? Ui.ON_INK : Ui.MUTED, false), ml);
            if (active) {
                JSONArray list = arr(b, "exam_list");
                for (int k = 0; k < list.length(); k++) {
                    LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-1, -2);
                    ll.topMargin = dp(8.0f);
                    card.addView(Ui.tv(this, "• " + at(list, k).optString("title"), 14.0f, -1, false), ll);
                }
            } else if ("pending".equals(st)) {
                note(card, "⏳ পেমেন্ট অ্যাডমিনের অনুমোদনের অপেক্ষায় আছে।", Ui.AMBER, true);
            } else {
                if ("rejected".equals(st)) {
                    note(card, "আগের পেমেন্ট গ্রহণ করা হয়নি। আবার চেষ্টা করো।", Ui.RED, true);
                }
                act(card, Ui.primary(this, price > 0.0d ? "ভর্তি হও (পেমেন্ট)" : "ভর্তি হও", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        joinBatch(id, b.optString("name"), price);
                    }
                }));
            }
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showBatchDetail(b);
                }
            });
            Ui.add(box, card, 12);
        }
        for (int i = 0; i < box.getChildCount(); i++) {
            Ui.rise(box.getChildAt(i), i * 60);
        }
        setPage(box);
    }

    private void pickOmrImage(int i) {
        showOmr(i);
    }

    private void showOmr(int examId) {
        this.pendingOmrExam = examId;
        LinearLayout box = pageBox();
        String title = "OMR পরীক্ষা";
        String meta = "";
        if (this.lastExams != null) {
            JSONArray all = arr(this.lastExams, "exams");
            for (int i = 0; i < all.length(); i++) {
                JSONObject e = at(all, i);
                if (e.optInt("id") == examId) {
                    title = e.optString("title");
                    meta = bn(e.optInt("questions")) + "টি প্রশ্ন, " + bn(Math.max(1, e.optInt("time_limit_seconds") / 60)) + " মিনিট";
                }
            }
        }
        LinearLayout info = Ui.hbox(this);
        info.setBackground(Ui.box(this, Ui.WHITE, 0, 24.0f));
        info.setPadding(dp(14.0f), dp(14.0f), dp(14.0f), dp(14.0f));
        info.addView(iconTile("ic_omr", 0xFFDDEBFF, 0xFF1F5FBF, 44, 22, 14.0f));
        LinearLayout it = Ui.vbox(this);
        it.setPadding(dp(12.0f), 0, dp(8.0f), 0);
        it.addView(Ui.tv(this, title, 15.0f, Ui.INK, true));
        if (!meta.isEmpty()) {
            it.addView(Ui.tv(this, meta, 12.0f, Ui.MUTED, false));
        }
        info.addView(it, new LinearLayout.LayoutParams(0, -2, 1.0f));
        info.addView(Ui.pill(this, "জমা বাকি", Ui.AMBER_BG, 0xFF7A4E00));
        Ui.add(box, info, 14);

        LinearLayout cap = Ui.vbox(this);
        cap.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setColor(Ui.WHITE);
        d.setCornerRadius(dp(28.0f));
        d.setStroke(dp(2.0f), 0xFFB9B4E6, dp(8.0f), dp(6.0f));
        cap.setBackground(d);
        cap.setPadding(dp(24.0f), dp(24.0f), dp(24.0f), dp(24.0f));
        cap.addView(iconTile("ic_camera", Ui.SOFT, Ui.INDIGO, 64, 30, 20.0f));
        TextView ct = Ui.tv(this, "OMR শিটের ছবি তোলো", 18.0f, Ui.INK, true);
        ct.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ctl = new LinearLayout.LayoutParams(-1, -2);
        ctl.topMargin = dp(14.0f);
        cap.addView(ct, ctl);
        TextView cs = Ui.tv(this, "শিটের চারটি কোণ যেন ছবির ভেতরে থাকে", 14.0f, Ui.MUTED, false);
        cs.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams csl = new LinearLayout.LayoutParams(-1, -2);
        csl.topMargin = dp(6.0f);
        cap.addView(cs, csl);
        Ui.add(box, cap, 14);

        LinearLayout btns = Ui.hbox(this);
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        b1.rightMargin = dp(10.0f);
        btns.addView(Ui.primary(this, "ক্যামেরা", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lambda$pickOmrImage$64(null, 0);
            }
        }), b1);
        btns.addView(Ui.btn(this, "গ্যালারি", Ui.WHITE, Ui.INK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lambda$pickOmrImage$64(null, 1);
            }
        }), new LinearLayout.LayoutParams(0, -2, 1.0f));
        Ui.add(box, btns, 18);
        String[] tips = {"ভালো আলোতে ছবি তোলো", "শিট সমতল টেবিলে রাখো", "ছবি যেন ঝাপসা না হয়"};
        for (String tip : tips) {
            LinearLayout tr = Ui.hbox(this);
            tr.addView(Ui.tv(this, "✓", 16.0f, Ui.GREEN, true), new LinearLayout.LayoutParams(dp(24.0f), -2));
            tr.addView(Ui.tv(this, tip, 14.0f, 0xFF3D3A66, false));
            Ui.add(box, tr, 10);
        }
        setScreen("OMR শিট জমা", scroll(box), false, new Runnable() {
            @Override
            public void run() {
                showMain("exams");
            }
        }, null);
    }

    private void showOmrPreview(final Uri uri) {
        LinearLayout box = pageBox();
        LinearLayout card = Ui.vbox(this);
        card.setBackground(Ui.box(this, Ui.WHITE, Ui.INDIGO, 28.0f));
        card.setPadding(dp(16.0f), dp(16.0f), dp(16.0f), dp(16.0f));
        card.addView(Ui.tv(this, "ছবির প্রিভিউ", 14.0f, Ui.MUTED, true));
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try {
            android.graphics.ImageDecoder.Source src = android.graphics.ImageDecoder.createSource(getContentResolver(), uri);
            iv.setImageBitmap(android.graphics.ImageDecoder.decodeBitmap(src, new android.graphics.ImageDecoder.OnHeaderDecodedListener() {
                @Override
                public void onHeaderDecoded(android.graphics.ImageDecoder decoder, android.graphics.ImageDecoder.ImageInfo info, android.graphics.ImageDecoder.Source source) {
                    decoder.setTargetSampleSize(4);
                    decoder.setAllocator(1);
                }
            }));
        } catch (Exception e) {
            iv.setImageURI(uri);
        }
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.topMargin = dp(10.0f);
        card.addView(iv, ilp);
        Ui.add(box, card, 12);
        LinearLayout ok = Ui.hbox(this);
        ok.addView(Ui.tv(this, "✓", 16.0f, Ui.GREEN, true), new LinearLayout.LayoutParams(dp(24.0f), -2));
        ok.addView(Ui.tv(this, "ছবি পরিষ্কার আছে কিনা দেখে নাও", 14.0f, 0xFF0B5C40, true));
        Ui.add(box, ok, 16);
        Ui.add(box, Ui.btn(this, "শিট জমা দাও", Ui.ACCENT, Ui.INK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadOmr(uri);
            }
        }), 10);
        Ui.add(box, Ui.btn(this, "আবার তোলো", Ui.WHITE, Ui.INK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOmr(MainActivity.this.pendingOmrExam);
            }
        }), 0);
        setScreen("OMR শিট জমা", scroll(box), false, new Runnable() {
            @Override
            public void run() {
                showOmr(MainActivity.this.pendingOmrExam);
            }
        }, null);
    }

    private /* synthetic */ void lambda$loadDashboard$43(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        LinearLayout card = Ui.card(this);
        int i = 0xFF17153B;
        Ui.add(card, Ui.tv(this, "তোমার অগ্রগতি", 17.0f, 0xFF17153B, true), 6);
        float f = 15.0f;
        Ui.add(card, Ui.tv(this, "পরীক্ষা দিয়েছো: " + jSONObject.optInt("exams_completed"), 15.0f, 0xFF4A3FD1, true), 4);
        Ui.add(card, Ui.tv(this, jSONObject.optBoolean("adaptive_ready") ? "🧠 Adaptive Exam প্রস্তুত — 'প্র্যাকটিস' ট্যাবে যাও।" : "Adaptive Exam পেতে আরও " + jSONObject.optInt("exams_needed") + " টি পরীক্ষা দাও।", 13.0f, 0xFF55527A, false), 0);
        Ui.add(pageBox, card, 14);
        JSONArray arr = arr(jSONObject, "topic_performance");
        if (arr.length() == 0) {
            Ui.add(pageBox, Ui.tv(this, "এখনও কোনো ফলাফল নেই। পরীক্ষা দিলে এখানে দেখা যাবে।", 14.0f, 0xFF55527A, false));
        }
        int i2 = 0;
        while (i2 < arr.length()) {
            JSONObject at = at(arr, i2);
            String optString = at.optString("level");
            int i3 = "strong".equals(optString) ? 0xFF0B8A63 : "weak".equals(optString) ? 0xFFD6393F : 0xFFB7791F;
            String str = "strong".equals(optString) ? "ভালো" : "weak".equals(optString) ? "দুর্বল" : "উন্নতি দরকার";
            LinearLayout card2 = Ui.card(this);
            Ui.add(card2, Ui.tv(this, at.optString("topic_name"), f, i, true), 2);
            Ui.add(card2, Ui.tv(this, "সঠিক " + at.optInt("correct_count") + " / " + at.optInt("total_attempts") + " · " + Math.round(at.optDouble("accuracy") * 100.0d) + "% · " + str, 13.0f, i3, true), 8);
            Ui.add(card2, Ui.bar(this, at.optDouble("accuracy"), i3), 0);
            Ui.add(pageBox, card2, 10);
            i2++;
            i = 0xFF17153B;
            f = 15.0f;
        }
        setPage(pageBox);
    }

    private /* synthetic */ void lambda$loadExams$16(JSONObject jSONObject) throws Exception {
        renderExams(jSONObject);
    }

    private /* synthetic */ void lambda$loadPractice$38(View view) {
        busy("প্রশ্ন তৈরি হচ্ছে…");
        Api.call("POST", "/exam/generate", json("count", Integer.valueOf(this.practiceCount)), actCb(new MainActivity$$ExternalSyntheticLambda34(this)));
    }

    private /* synthetic */ void lambda$loadPractice$39(View view) {
        busy("তোমার জন্য প্রশ্ন তৈরি হচ্ছে… একটু সময় লাগতে পারে।");
        Api.call("POST", "/exam/generate-adaptive", null, actCb(new MainActivity$$ExternalSyntheticLambda34(this)));
    }

    private /* synthetic */ void lambda$loadPractice$40(JSONObject jSONObject, View view) {
        busy("প্রশ্ন তৈরি হচ্ছে…");
        Api.call("POST", "/exam/generate", json("panel_exam_id", Integer.valueOf(jSONObject.optInt("id"))), actCb(new MainActivity$$ExternalSyntheticLambda34(this)));
    }

    private /* synthetic */ void lambda$loadPractice$41(final JSONObject jSONObject) throws Exception {
        fetchSoft("/exam/performance", new java.util.function.Consumer<JSONObject>() {
            @Override
            public void accept(JSONObject perf) {
                try {
                    renderPractice(jSONObject, perf);
                } catch (Exception e) {
                    showError("দেখাতে সমস্যা হয়েছে: " + e.getMessage());
                }
            }
        });
    }

    private void renderPractice(final JSONObject jSONObject, final JSONObject perf) throws Exception {
        LinearLayout box = tabBox("নিজের মতো করে অনুশীলন", "প্র্যাকটিস");
        boolean ready = perf.optBoolean("adaptive_ready");
        int completed = perf.optInt("exams_completed");
        int needed = perf.optInt("exams_needed");
        LinearLayout hero = Ui.vbox(this);
        hero.setBackground(Ui.box(this, Ui.INK, 0, 30.0f));
        hero.setPadding(dp(20.0f), dp(20.0f), dp(20.0f), dp(20.0f));
        LinearLayout hr = Ui.hbox(this);
        hr.addView(iconTile("ic_adaptive", 0x2EFFB020, 0xFFFFC95C, 46, 24, 15.0f));
        LinearLayout ht = Ui.vbox(this);
        ht.setPadding(dp(12.0f), 0, 0, 0);
        ht.addView(Ui.tv(this, "অ্যাডাপটিভ এক্সাম", 22.0f, -1, true));
        ht.addView(Ui.tv(this, "তোমার দুর্বল বিষয় বুঝে প্রশ্ন সাজানো হয়", 13.0f, Ui.ON_INK, false));
        hr.addView(ht, new LinearLayout.LayoutParams(0, -2, 1.0f));
        hero.addView(hr, new LinearLayout.LayoutParams(-1, -2));
        if (!ready) {
            LinearLayout lock = Ui.vbox(this);
            lock.setBackground(Ui.box(this, 0x17FFFFFF, 0, 20.0f));
            lock.setPadding(dp(14.0f), dp(14.0f), dp(14.0f), dp(14.0f));
            lock.addView(Ui.tv(this, "🔒 আনলক করতে আরও " + bn(needed) + "টি লাইভ পরীক্ষা দাও", 14.0f, -1, false));
            double total = completed + needed;
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
            bl.topMargin = dp(10.0f);
            lock.addView(Ui.bar(this, total == 0 ? 0 : completed / total, Ui.ACCENT), bl);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
            tl.topMargin = dp(6.0f);
            lock.addView(Ui.tv(this, bn(completed) + "/" + bn((int) total) + "টি পরীক্ষা সম্পন্ন", 12.0f, Ui.ON_INK, false), tl);
            LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-1, -2);
            ll.topMargin = dp(16.0f);
            hero.addView(lock, ll);
        } else {
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-2, -2);
            pl.topMargin = dp(14.0f);
            hero.addView(Ui.pill(this, "✓ প্রস্তুত", 0x332EC4A6, 0xFF5FE0C4), pl);
        }
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
        cl.topMargin = dp(16.0f);
        hero.addView(Ui.tv(this, "র\u200d্যান্ডম প্র্যাকটিসে প্রশ্ন সংখ্যা", 13.0f, Ui.ON_INK, false), cl);
        LinearLayout counts = Ui.hbox(this);
        int[] opts = {10, 20, 30};
        for (int k = 0; k < 3; k++) {
            final int cnt = opts[k];
            boolean on = this.practiceCount == cnt;
            TextView c = Ui.tv(this, bn(cnt), 17.0f, on ? Ui.INK : -1, true);
            c.setGravity(Gravity.CENTER);
            c.setBackground(Ui.box(this, on ? Ui.WHITE : 0x1AFFFFFF, 0, 16.0f));
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MainActivity.this.practiceCount = cnt;
                    try {
                        renderPractice(jSONObject, perf);
                    } catch (Exception e) {
                        showError(e.getMessage());
                    }
                }
            });
            Ui.press(c);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48.0f), 1.0f);
            if (k < 2) {
                lp.rightMargin = dp(8.0f);
            }
            counts.addView(c, lp);
        }
        LinearLayout.LayoutParams cwl = new LinearLayout.LayoutParams(-1, -2);
        cwl.topMargin = dp(8.0f);
        hero.addView(counts, cwl);
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(-1, -2);
        b1.topMargin = dp(16.0f);
        hero.addView(Ui.btn(this, "র\u200d্যান্ডম প্র্যাকটিস শুরু করো", Ui.ACCENT, Ui.INK, new MainActivity$$ExternalSyntheticLambda39(this)), b1);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(-1, -2);
        b2.topMargin = dp(10.0f);
        if (ready) {
            hero.addView(Ui.btn(this, "🧠 Adaptive Exam শুরু করো", 0x24FFFFFF, -1, new MainActivity$$ExternalSyntheticLambda40(this)), b2);
        } else {
            hero.addView(Ui.btn(this, "লাইভ পরীক্ষা দেখো", 0x24FFFFFF, -1, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MainActivity.this.examFilter = "online";
                    showMain("exams");
                }
            }), b2);
        }
        Ui.add(box, hero, 6);
        JSONArray list = arr(jSONObject, "exams");
        if (list.length() > 0) {
            box.addView(sectionTitle("প্র্যাকটিস পরীক্ষা"));
        }
        for (int i = 0; i < list.length(); i++) {
            JSONObject at = at(list, i);
            LinearLayout card = Ui.card(this);
            card.setPadding(dp(14.0f), dp(14.0f), dp(14.0f), dp(14.0f));
            LinearLayout head = Ui.hbox(this);
            head.addView(iconTile("ic_practice", 0xFFD9F5EA, 0xFF0B6B4B, 44, 22, 14.0f));
            LinearLayout tx = Ui.vbox(this);
            tx.setPadding(dp(12.0f), 0, dp(8.0f), 0);
            tx.addView(Ui.tv(this, at.optString("title"), 16.0f, Ui.INK, true));
            String sub = bn(at.optInt("questions")) + " টি প্রশ্ন" + (str(at, "batch_name").isEmpty() ? "" : ", " + str(at, "batch_name"));
            tx.addView(Ui.tv(this, sub, 12.0f, Ui.MUTED, false));
            head.addView(tx, new LinearLayout.LayoutParams(0, -2, 1.0f));
            if (at.optBoolean("participated")) {
                head.addView(Ui.pill(this, "পরীক্ষা দিয়েছো", Ui.GREEN_BG, 0xFF0B5C40));
            }
            card.addView(head, new LinearLayout.LayoutParams(-1, -2));
            if (at.optBoolean("practice_open")) {
                act(card, Ui.secondary(this, "এই পরীক্ষা প্র্যাকটিস করো", new MainActivity$$ExternalSyntheticLambda41(this, at)));
            } else {
                note(card, "পরীক্ষা শেষ হলে প্র্যাকটিস খুলবে।", Ui.AMBER, false);
            }
            Ui.add(box, card, 10);
        }
        setPage(box);
    }

    private /* synthetic */ void lambda$onCreate$1() {
        clearLogin();
        toast("আবার লগইন করো।");
        route();
    }

    private /* synthetic */ void lambda$openLive$29(int i, JSONArray jSONArray, Runnable runnable) {
        Api.call("POST", "/online/exams/" + i + "/submit", json("answers", jSONArray), new AnonymousClass5(runnable));
    }

    private /* synthetic */ void lambda$openPractice$42(int i, JSONArray jSONArray, JSONArray jSONArray2, Runnable runnable) {
        Api.call("POST", "/exam/" + i + "/submit", json("answers", jSONArray2), new AnonymousClass6(jSONArray, runnable));
    }

    private /* synthetic */ void lambda$openReview$34(JSONObject jSONObject) throws Exception {
        showResult("ফলাফল", jSONObject, arr(jSONObject, "results"));
    }

    private /* synthetic */ void lambda$openReview$35(JSONObject jSONObject) throws Exception {
        JSONArray arr = arr(jSONObject, "answers");
        JSONArray jSONArray = new JSONArray();
        Object[] objArr = {"a", "b", "c", "d"};
        for (int i = 0; i < arr.length(); i++) {
            JSONObject at = at(arr, i);
            int optInt = at.isNull("selected_option") ? 0 : at.optInt("selected_option");
            int optInt2 = at.optInt("correct_option");
            jSONArray.put(json("question_text", at.optString("question"), "options", json("a", at.optString("option1"), "b", at.optString("option2"), "c", at.optString("option3"), "d", at.optString("option4")), "your_answer", (optInt < 1 || optInt > 4) ? JSONObject.NULL : objArr[optInt - 1], "correct_answer", (optInt2 < 1 || optInt2 > 4) ? "" : objArr[optInt2 - 1], "is_correct", Boolean.valueOf(optInt == optInt2 && optInt != 0), "explanation", ""));
        }
        showResult("ফলাফল", new JSONObject(), jSONArray);
    }

    private /* synthetic */ void lambda$paymentDialog$47(JSONObject jSONObject) throws Exception {
        showReceipt(jSONObject.optString("message", "পেমেন্ট জমা হয়েছে। অ্যাডমিন যাচাই করলে ব্যাচ চালু হবে।"));
    }

    private /* synthetic */ void lambda$paymentDialog$48(int i, EditText editText, EditText editText2, EditText editText3, DialogInterface dialogInterface, int i2) {
        busy("অপেক্ষা করো…");
        Api.call("POST", "/omr/batches/" + i + "/join", json("method", editText.getText().toString(), "sender_number", editText2.getText().toString(), "transaction_id", editText3.getText().toString()), actCb(new MainActivity$$ExternalSyntheticLambda36(this)));
    }

    private /* synthetic */ void lambda$pickOmrImage$64(DialogInterface dialogInterface, int i) {
        if (i != 0) {
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            startActivityForResult(Intent.createChooser(intent, "ছবি বেছে নাও"), 22);
        } else if (checkSelfPermission("android.permission.CAMERA") == 0) {
            launchCamera();
        } else {
            requestPermissions(new String[]{"android.permission.CAMERA"}, 24);
        }
    }

    private /* synthetic */ void lambda$showAdminNote$12(View view) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(Api.base + "/admin")));
    }

    private /* synthetic */ void lambda$showAdminNote$13(View view) {
        clearLogin();
        route();
    }

    private /* synthetic */ void lambda$showAuth$10(boolean z, View view) {
        showAuth(!z);
    }

    private /* synthetic */ void lambda$showAuth$11(View view) {
        showServerSetup(false);
    }

    private /* synthetic */ void lambda$showAuth$8(JSONObject jSONObject) throws Exception {
        saveLogin(jSONObject);
        this.tab = "exams";
        route();
    }

    private /* synthetic */ void lambda$showAuth$9(EditText editText, EditText editText2, EditText editText3, boolean z, View view) {
        String trim = editText.getText().toString().trim();
        String obj = editText2.getText().toString();
        String trim2 = editText3.getText().toString().trim();
        if (trim.isEmpty() || obj.isEmpty() || (z && trim2.isEmpty())) {
            showError("সব ঘর পূরণ করো।");
        } else {
            busy("অপেক্ষা করো…");
            Api.call("POST", z ? "/auth/register" : "/auth/login", z ? json("name", trim2, "email", trim, "password", obj) : json("email", trim, "password", obj), actCb(new MainActivity$$ExternalSyntheticLambda28(this)));
        }
    }

    private /* synthetic */ void lambda$showFace$57() {
        showMain("more");
    }

    private /* synthetic */ void lambda$showFace$58(CheckBox checkBox, View view) {
        if (checkBox.isChecked()) {
            startFace("enroll", 0, new MainActivity$$ExternalSyntheticLambda22(this));
        } else {
            showError("আগে সম্মতির বক্সে টিক দাও।");
        }
    }

    private /* synthetic */ void lambda$showFace$59(View view) {
        startFace("verify", 0, new MainActivity$$ExternalSyntheticLambda22(this));
    }

    private /* synthetic */ void lambda$showFace$60(JSONObject jSONObject) throws Exception {
        showFace();
    }

    private /* synthetic */ void lambda$showFace$61() {
        busy("অপেক্ষা করো…");
        Api.call("DELETE", "/face/me", null, actCb(new MainActivity$$ExternalSyntheticLambda14(this)));
    }

    private /* synthetic */ void lambda$showFace$62(View view) {
        confirm("ছেড়ে দেবে?", "তোমার ছবি ও ফেস ডেটা মুছে যাবে।", new MainActivity$$ExternalSyntheticLambda19(this));
    }

    private /* synthetic */ void lambda$showFace$63(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        boolean optBoolean = jSONObject.optBoolean("enrolled");
        boolean z = optBoolean && "approved".equals(jSONObject.optString("status"));
        LinearLayout card = Ui.card(this);
        Ui.add(card, Ui.tv(this, !optBoolean ? "তুমি এখনও পার্সোনাল কেয়ারে যুক্ত নও।" : z ? "✅ তুমি পার্সোনাল কেয়ারে যুক্ত আছো।" : "⏳ আবেদন জমা হয়েছে — অ্যাডমিনের অনুমোদনের অপেক্ষায়।", 15.0f, 0xFF17153B, true), 8);
        String str = str(jSONObject, "photo");
        if (str.contains(",")) {
            try {
                byte[] decode = Base64.decode(str.substring(str.indexOf(44) + 1), 0);
                ImageView imageView = new ImageView(this);
                imageView.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(96.0f), dp(96.0f));
                layoutParams.bottomMargin = dp(10.0f);
                card.addView(imageView, layoutParams);
            } catch (Exception e) {
            }
        }
        if (optBoolean) {
            if (z) {
                Ui.add(card, Ui.primary(this, "📷 হাজিরা দাও", new MainActivity$$ExternalSyntheticLambda59(this)), 8);
            }
            Ui.add(card, Ui.btn(this, "পার্সোনাল কেয়ার ছেড়ে দাও", 0xFFFFE1DC, 0xFFD6393F, new MainActivity$$ExternalSyntheticLambda60(this)), 0);
        } else {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText("আমি ফেস ডেটা সংরক্ষণে সম্মতি দিচ্ছি।");
            checkBox.setTextColor(0xFF17153B);
            Ui.add(card, checkBox, 8);
            Ui.add(card, Ui.primary(this, "ক্যামেরায় যুক্ত হও", new MainActivity$$ExternalSyntheticLambda58(this, checkBox)), 0);
        }
        Ui.add(pageBox, card, 14);
        JSONArray arr = arr(jSONObject, "recent");
        if (arr.length() > 0) {
            Ui.add(pageBox, Ui.tv(this, "সাম্প্রতিক হাজিরা", 15.0f, 0xFF17153B, true), 8);
        }
        for (int i = 0; i < arr.length(); i++) {
            JSONObject at = at(arr, i);
            Ui.add(pageBox, Ui.tv(this, ("exam".equals(at.optString("kind")) ? "📝 " + str(at, "title") : "🏫 হাজিরা") + " — " + fmtUtc(at.optString("marked_at")), 13.0f, 0xFF55527A, false), 4);
        }
        setPage(pageBox);
    }

    private /* synthetic */ void lambda$showLeaderboard$55() {
        showMain("more");
    }

    private /* synthetic */ void lambda$showLeaderboard$56(JSONObject jSONObject) throws Exception {
        LinearLayout box = tabBox("সেরাদের তালিকা", "লিডারবোর্ড");
        JSONArray list = arr(jSONObject, "leaderboard");
        int uid = this.prefs.getInt("uid", -1);
        if (list.length() == 0) {
            Ui.add(box, Ui.tv(this, "এখনও কেউ লিডারবোর্ডে নেই (কমপক্ষে ৩টি প্র্যাকটিস exam লাগে)।", 14.0f, Ui.MUTED, false));
            setPage(box);
            return;
        }
        int myIdx = -1;
        for (int i = 0; i < list.length(); i++) {
            if (at(list, i).optInt("student_id") == uid) {
                myIdx = i;
            }
        }
        if (myIdx >= 0) {
            LinearLayout me = Ui.hbox(this);
            me.setBackground(Ui.box(this, Ui.ACCENT, 0, 22.0f));
            me.setPadding(dp(16.0f), dp(12.0f), dp(16.0f), dp(12.0f));
            me.addView(Ui.tv(this, "#" + bn(myIdx + 1), 26.0f, Ui.INK, true));
            LinearLayout mt = Ui.vbox(this);
            mt.setPadding(dp(12.0f), 0, 0, 0);
            mt.addView(Ui.tv(this, "তোমার অবস্থান", 15.0f, Ui.INK, true));
            mt.addView(Ui.tv(this, bn(at(list, myIdx).optInt("exams_completed")) + " টি পরীক্ষা", 12.0f, Ui.INK, false));
            me.addView(mt, new LinearLayout.LayoutParams(0, -2, 1.0f));
            me.addView(Ui.tv(this, bn(num(at(list, myIdx).optDouble("avg_score"))) + "%", 19.0f, Ui.INK, true));
            Ui.add(box, me, 14);
        }
        Ui.add(box, buildPodium(list, uid), 14);
        for (int i = 3; i < list.length(); i++) {
            JSONObject p = at(list, i);
            boolean mine = p.optInt("student_id") == uid;
            LinearLayout row = Ui.hbox(this);
            row.setPadding(dp(14.0f), dp(10.0f), dp(14.0f), dp(10.0f));
            row.setBackground(Ui.box(this, mine ? Ui.SOFT : Ui.WHITE, mine ? Ui.INDIGO : 0, 20.0f));
            TextView rn = Ui.tv(this, bn(i + 1), 17.0f, Ui.MUTED, true);
            rn.setGravity(Gravity.CENTER);
            row.addView(rn, new LinearLayout.LayoutParams(dp(30.0f), -2));
            String nm = p.optString("name");
            TextView av = Ui.tv(this, nm.isEmpty() ? "?" : nm.substring(0, nm.offsetByCodePoints(0, 1)), 15.0f, Ui.INK, true);
            av.setGravity(Gravity.CENTER);
            av.setBackground(Ui.box(this, Ui.BG, 0, 14.0f));
            LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(40.0f), dp(40.0f));
            alp.leftMargin = dp(6.0f);
            row.addView(av, alp);
            LinearLayout tx = Ui.vbox(this);
            tx.setPadding(dp(12.0f), 0, dp(8.0f), 0);
            tx.addView(Ui.tv(this, mine ? "তুমি" : nm, 15.0f, Ui.INK, true));
            tx.addView(Ui.tv(this, bn(p.optInt("exams_completed")) + " টি পরীক্ষা", 12.0f, Ui.MUTED, false));
            row.addView(tx, new LinearLayout.LayoutParams(0, -2, 1.0f));
            row.addView(Ui.tv(this, bn(num(p.optDouble("avg_score"))) + "%", 16.0f, Ui.INDIGO, true));
            Ui.add(box, row, 8);
        }
        setPage(box);
    }

    private /* synthetic */ void lambda$showMain$14(String str) {
        showMain(str);
    }

    private /* synthetic */ void lambda$showMain$15(String str) {
        showMain(str);
    }

    private /* synthetic */ void lambda$showMore$49(View view) {
        showLeaderboard();
    }

    private /* synthetic */ void lambda$showMore$50(View view) {
        showFace();
    }

    private /* synthetic */ void lambda$showMore$51() {
        showServerSetup(true);
    }

    private /* synthetic */ void lambda$showMore$52(View view) {
        confirm("সার্ভার বদলাবে?", "ঠিকানা বদলালে তোমাকে আবার লগইন করতে হবে।", new MainActivity$$ExternalSyntheticLambda8(this));
    }

    private /* synthetic */ void lambda$showMore$53() {
        clearLogin();
        route();
    }

    private /* synthetic */ void lambda$showMore$54(View view) {
        confirm("লগআউট করবে?", "", new MainActivity$$ExternalSyntheticLambda13(this));
    }

    private /* synthetic */ void lambda$showPaper$32(String str) {
        showMain(str);
    }

    private /* synthetic */ void lambda$showPaper$33(JSONObject jSONObject) throws Exception {
        LinearLayout pageBox = pageBox();
        JSONArray arr = arr(jSONObject, "questions");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject at = at(arr, i);
            JSONObject optJSONObject = at.optJSONObject("options");
            if (optJSONObject == null) {
                optJSONObject = new JSONObject();
            }
            LinearLayout card = Ui.card(this);
            Ui.add(card, Ui.tv(this, at.optInt("no") + ". " + at.optString("question"), 16.0f, 0xFF17153B, true), 6);
            String[] strArr = {"a", "b", "c", "d"};
            int i2 = 0;
            for (int i3 = 4; i2 < i3; i3 = 4) {
                String str = strArr[i2];
                Ui.add(card, Ui.tv(this, str.toUpperCase() + ".  " + optJSONObject.optString(str), 15.0f, 0xFF17153B, false), 3);
                i2++;
            }
            Ui.add(pageBox, card, 10);
        }
        setScreen(jSONObject.optString("title", "প্রশ্নপত্র"), scroll(pageBox), false, new MainActivity$$ExternalSyntheticLambda68(this, this.tab), null);
    }

    private /* synthetic */ void lambda$showReceipt$30(View view) {
        showMain("exams");
    }

    private /* synthetic */ void lambda$showReceipt$31() {
        showMain("exams");
    }

    private /* synthetic */ void lambda$showResult$36(View view) {
        showMain(this.tab);
    }

    private /* synthetic */ void lambda$showResult$37() {
        showMain(this.tab);
    }

    private /* synthetic */ void lambda$showServerSetup$6(EditText editText, View view) {
        String trim = editText.getText().toString().trim();
        if (trim.isEmpty()) {
            showError("ঠিকানা লেখো।");
            return;
        }
        if (!trim.matches("(?i)^https?://.*")) {
            trim = "https://" + trim;
        }
        while (trim.endsWith("/")) {
            trim = trim.substring(0, trim.length() - 1);
        }
        String str = trim;
        String str2 = Api.base;
        busy("সংযোগ পরীক্ষা হচ্ছে…");
        Api.base = str;
        Api.call("GET", "/public/home", null, new AnonymousClass3(str, str2));
    }

    private /* synthetic */ void lambda$showServerSetup$7() {
        showMain("more");
    }

    private /* synthetic */ void lambda$uploadOmr$65() {
        showError("ছবিটি পড়া যায়নি। আবার চেষ্টা করো।");
    }

    private /* synthetic */ void lambda$uploadOmr$66(JSONObject jSONObject) throws Exception {
        showReceipt(jSONObject.optString("message", "OMR শিট জমা হয়েছে। মার্কিং শেষ হলে ফলাফলে নম্বর দেখতে পাবে।"));
    }

    private /* synthetic */ void lambda$uploadOmr$67(Uri uri, int i) {
        try {
            Api.upload("/omr/exams/" + i + "/submission", compress(uri), "image/jpeg", actCb(new MainActivity$$ExternalSyntheticLambda32(this)));
        } catch (Exception e) {
            runOnUiThread(new MainActivity$$ExternalSyntheticLambda31(this));
        }
    }

    private void launchCamera() {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", "omr_" + System.currentTimeMillis() + ".jpg");
            contentValues.put("mime_type", "image/jpeg");
            contentValues.put("relative_path", "Pictures/ProttashaOMR");
            this.camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            intent.putExtra("output", this.camUri);
            startActivityForResult(intent, 21);
        } catch (Exception e) {
            showError("ক্যামেরা খোলা যায়নি। গ্যালারি থেকে ছবি নাও।");
        }
    }

    private void loadBatches(Runnable runnable) {
        Api.call("GET", "/omr/batches", null, pageCb(new MainActivity$$ExternalSyntheticLambda67(this), runnable));
    }

    private void loadDashboard(Runnable runnable) {
        Api.call("GET", "/exam/performance", null, pageCb(new MainActivity$$ExternalSyntheticLambda20(this), runnable));
    }

    private void loadExams(Runnable runnable) {
        Api.call("GET", "/online/exams", null, pageCb(new MainActivity$$ExternalSyntheticLambda69(this), runnable));
    }

    private void loadPractice(Runnable runnable) {
        Api.call("GET", "/exam/practice-exams", null, pageCb(new MainActivity$$ExternalSyntheticLambda65(this), runnable));
    }

    private static String num(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.format(Locale.US, "%.2f", Double.valueOf(d));
    }

    private void openLive(JSONObject jSONObject) {
        new ExamSession(jSONObject.optString("title"), arr(jSONObject, "questions"), jSONObject.optInt("remaining_seconds", -1), new MainActivity$$ExternalSyntheticLambda43(this, jSONObject.optInt("exam_id"))).show();
    }

    private void openPractice(JSONObject jSONObject) {
        JSONArray arr = arr(jSONObject, "questions");
        if (arr.length() == 0) {
            showError(str(jSONObject, "message").isEmpty() ? "এখন কোনো প্রশ্ন পাওয়া যায়নি।" : jSONObject.optString("message"));
            return;
        }
        int optInt = jSONObject.optInt("exam_id");
        str(jSONObject, "message").isEmpty();
        new ExamSession("প্র্যাকটিস", arr, -1, new MainActivity$$ExternalSyntheticLambda4(this, optInt, arr)).show();
    }

    private void openReview(int i, boolean z) {
        busy("লোড হচ্ছে…");
        if (z) {
            Api.call("GET", "/omr/results/" + i + "/review", null, actCb(new MainActivity$$ExternalSyntheticLambda64(this)));
        } else {
            Api.call("GET", "/online/results/" + i + "/review", null, actCb(new MainActivity$$ExternalSyntheticLambda63(this)));
        }
    }

    private LinearLayout pageBox() {
        LinearLayout vbox = Ui.vbox(this);
        vbox.setPadding(dp(14.0f), dp(14.0f), dp(14.0f), dp(24.0f));
        return vbox;
    }

    private Api.Callback pageCb(Ok ok, Runnable runnable) {
        return new AnonymousClass2(this.screenToken, ok, runnable);
    }

    private void route() {
        if (Api.base == null || Api.base.isEmpty()) {
            showServerSetup(false);
            return;
        }
        if (Api.token == null) {
            showAuth(false);
        } else if ("admin".equals(this.prefs.getString("role", ""))) {
            showAdminNote();
        } else {
            showMain(this.tab);
        }
    }

    private void saveLogin(JSONObject jSONObject) {
        JSONObject optJSONObject = jSONObject.optJSONObject("user");
        if (optJSONObject == null) {
            optJSONObject = new JSONObject();
        }
        Api.token = jSONObject.optString("token");
        this.prefs.edit().putString("token", Api.token).putInt("uid", optJSONObject.optInt("id")).putString("name", optJSONObject.optString("name")).putString("email", optJSONObject.optString("email")).putString("role", optJSONObject.optString("role")).apply();
    }

    private ScrollView scroll(View view) {
        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(view, new FrameLayout.LayoutParams(-1, -2));
        return scrollView;
    }

    private void setContent(View view) {
        this.content.removeAllViews();
        this.content.addView(view, new FrameLayout.LayoutParams(-1, -1));
    }

    private void setPage(LinearLayout linearLayout) {
        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(linearLayout, new FrameLayout.LayoutParams(-1, -2));
        setContent(scrollView);
    }

    private void setScreen(String str, View view, boolean z, Runnable runnable, Runnable runnable2) {
        statusBar(false);
        this.screenToken++;
        stopTimer();
        this.titleView.setText(str);
        this.onBack = runnable;
        this.refreshAction = runnable2;
        this.backBtn.setVisibility(runnable != null ? 0 : 8);
        this.header.setVisibility(0);
        this.nav.setVisibility(z ? 0 : 8);
        setContent(view);
    }

    private void showAdminNote() {
        LinearLayout pageBox = pageBox();
        pageBox.setPadding(dp(20.0f), dp(40.0f), dp(20.0f), dp(20.0f));
        Ui.add(pageBox, Ui.tv(this, "অ্যাডমিন অ্যাকাউন্ট", 22.0f, 0xFF17153B, true), 8);
        Ui.add(pageBox, Ui.tv(this, "এই অ্যাপ শিক্ষার্থীদের জন্য। অ্যাডমিন প্যানেল ব্রাউজারে খোলো।", 15.0f, 0xFF55527A, false), 16);
        Ui.add(pageBox, Ui.primary(this, "অ্যাডমিন প্যানেল খোলো", new MainActivity$$ExternalSyntheticLambda16(this)), 10);
        Ui.add(pageBox, Ui.secondary(this, "লগআউট", new MainActivity$$ExternalSyntheticLambda17(this)), 10);
        setScreen("অ্যাডমিন", scroll(pageBox), false, null, null);
    }

    private View labeled(String label, View field) {
        LinearLayout l = Ui.vbox(this);
        TextView t = Ui.tv(this, label, 13.0f, Ui.INK, true);
        t.setPadding(dp(2.0f), 0, 0, dp(6.0f));
        l.addView(t);
        l.addView(field, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    private void showAuth(final boolean z) {
        LinearLayout root = Ui.vbox(this);
        root.setBackgroundColor(Ui.INK);
        LinearLayout topArea = Ui.vbox(this);
        topArea.setGravity(Gravity.CENTER_HORIZONTAL);
        topArea.setPadding(dp(28.0f), dp(40.0f), dp(28.0f), dp(24.0f));
        ImageView authLogo = new ImageView(this);
        authLogo.setImageResource(R.mipmap.ic_launcher);
        authLogo.setScaleX(0.7f);
        authLogo.setScaleY(0.7f);
        authLogo.setAlpha(0f);
        authLogo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(new OvershootInterpolator()).start();
        topArea.addView(authLogo, new LinearLayout.LayoutParams(dp(96.0f), dp(96.0f)));
        TextView authName = Ui.tv(this, "প্রত্যাশা একাডেমি", 28.0f, -1, true);
        authName.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
        nl.topMargin = dp(10.0f);
        topArea.addView(authName, nl);
        TextView authSub = Ui.tv(this, z ? "নতুন অ্যাকাউন্ট খুলে শুরু করো" : "পরীক্ষা শুরু করতে লগইন করো", 14.0f, Ui.ON_INK, false);
        authSub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.topMargin = dp(4.0f);
        topArea.addView(authSub, sl);
        root.addView(topArea, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sheetScroll = new ScrollView(this);
        sheetScroll.setFillViewport(true);
        LinearLayout sheet = Ui.vbox(this);
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(Ui.BG);
        float rr = dp(36.0f);
        sbg.setCornerRadii(new float[]{rr, rr, rr, rr, 0f, 0f, 0f, 0f});
        sheet.setBackground(sbg);
        sheet.setPadding(dp(24.0f), dp(24.0f), dp(24.0f), dp(28.0f));
        Ui.add(sheet, segmented(new String[]{"লগইন", "নতুন অ্যাকাউন্ট"}, z ? 1 : 0, new java.util.function.IntConsumer() {
            @Override
            public void accept(int i) {
                if ((i == 1) != z) {
                    showAuth(i == 1);
                }
            }
        }), 20);
        EditText input = Ui.input(this, "তোমার নাম লেখো", 8193);
        EditText input2 = Ui.input(this, "example@email.com", 33);
        EditText input3 = Ui.input(this, "কমপক্ষে ৬ অক্ষর", 129);
        if (z) {
            Ui.add(sheet, labeled("পুরো নাম", input), 14);
        }
        Ui.add(sheet, labeled("ইমেইল", input2), 14);
        Ui.add(sheet, labeled("পাসওয়ার্ড", input3), 22);
        Ui.add(sheet, Ui.primary(this, z ? "অ্যাকাউন্ট খোলো" : "লগইন করো", new MainActivity$$ExternalSyntheticLambda9(this, input2, input3, input, z)), 14);
        LinearLayout note = Ui.hbox(this);
        note.setGravity(Gravity.TOP);
        ImageView ni = new ImageView(this);
        ni.setImageResource(drawableId("ic_face"));
        ni.setColorFilter(Ui.INDIGO);
        note.addView(ni, new LinearLayout.LayoutParams(dp(18.0f), dp(18.0f)));
        TextView nt = Ui.tv(this, "লাইভ পরীক্ষার আগে ক্যামেরায় ফেস যাচাই করতে হতে পারে।", 13.0f, Ui.MUTED, false);
        nt.setPadding(dp(8.0f), 0, 0, 0);
        note.addView(nt, new LinearLayout.LayoutParams(0, -2, 1.0f));
        Ui.add(sheet, note, 12);
        if (!FIXED_SERVER) {
            Ui.add(sheet, Ui.btn(this, "সার্ভারের ঠিকানা: " + Api.base, Ui.WHITE, Ui.MUTED, new MainActivity$$ExternalSyntheticLambda12(this)), 0);
        }
        sheetScroll.addView(sheet, new FrameLayout.LayoutParams(-1, -1));
        root.addView(sheetScroll, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        setScreen("Prottasha Academy", root, false, null, null);
        this.header.setVisibility(8);
        statusBar(true);
    }

    private void showError(String str) {
        hideBusy();
        styled(new AlertDialog.Builder(this).setMessage(str).setPositiveButton("ঠিক আছে", (DialogInterface.OnClickListener) null).show());
    }

    private void showFace() {
        setScreen("ফেস হাজিরা", centered("লোড হচ্ছে…"), false, new MainActivity$$ExternalSyntheticLambda11(this), new MainActivity$$ExternalSyntheticLambda22(this));
        Api.call("GET", "/face/me", null, pageCb(new MainActivity$$ExternalSyntheticLambda33(this), new MainActivity$$ExternalSyntheticLambda22(this)));
    }

    private void showLeaderboard() {
        showMain("rank");
    }

    private void showMain(final String t) {
        this.tab = t;
        styleNav(t);
        boolean isTab = false;
        String title = "ব্যাচ";
        for (String[] x : TABS) {
            if (x[0].equals(t)) {
                isTab = true;
                title = x[2];
            }
        }
        Runnable again = new Runnable() {
            @Override
            public void run() {
                showMain(t);
            }
        };
        Runnable back = isTab ? null : new Runnable() {
            @Override
            public void run() {
                showMain("home");
            }
        };
        setScreen(title, centered("লোড হচ্ছে…"), true, back, again);
        if (isTab) {
            this.header.setVisibility(8);
        }
        if ("home".equals(t)) {
            loadHome(again);
        } else if ("exams".equals(t)) {
            loadExams(again);
        } else if ("practice".equals(t)) {
            loadPractice(again);
        } else if ("rank".equals(t)) {
            Api.call("GET", "/exam/leaderboard", null, pageCb(new MainActivity$$ExternalSyntheticLambda66(this), again));
        } else if ("batches".equals(t)) {
            loadBatches(again);
        } else {
            showMore();
        }
    }

    private void showMore() {
        LinearLayout pageBox = tabBox("তোমার অ্যাকাউন্ট", "আরও");
        LinearLayout profile = Ui.vbox(this);
        profile.setBackground(Ui.box(this, Ui.INK, 0, 30.0f));
        profile.setPadding(dp(20.0f), dp(20.0f), dp(20.0f), dp(20.0f));
        String nm = this.prefs.getString("name", "");
        LinearLayout row = Ui.hbox(this);
        String initial = nm.isEmpty() ? "?" : nm.substring(0, nm.offsetByCodePoints(0, 1));
        TextView av = Ui.tv(this, initial, 26.0f, Ui.INK, true);
        av.setGravity(Gravity.CENTER);
        av.setBackground(Ui.box(this, Ui.ACCENT, 0, 22.0f));
        row.addView(av, new LinearLayout.LayoutParams(dp(62.0f), dp(62.0f)));
        LinearLayout who = Ui.vbox(this);
        who.setPadding(dp(14.0f), 0, 0, 0);
        who.addView(Ui.tv(this, nm, 22.0f, -1, true));
        who.addView(Ui.tv(this, this.prefs.getString("email", ""), 14.0f, Ui.ON_INK, false));
        row.addView(who, new LinearLayout.LayoutParams(0, -2, 1.0f));
        profile.addView(row);
        LinearLayout face = Ui.hbox(this);
        face.setBackground(Ui.box(this, 0x292EC4A6, 0, 20.0f));
        face.setPadding(dp(14.0f), dp(12.0f), dp(14.0f), dp(12.0f));
        ImageView fi = new ImageView(this);
        fi.setImageResource(drawableId("ic_face"));
        fi.setColorFilter(0xFF5FE0C4);
        face.addView(fi, new LinearLayout.LayoutParams(dp(26.0f), dp(26.0f)));
        LinearLayout ft = Ui.vbox(this);
        ft.setPadding(dp(12.0f), 0, dp(8.0f), 0);
        ft.addView(Ui.tv(this, "ফেস হাজিরা", 15.0f, -1, true));
        ft.addView(Ui.tv(this, "লাইভ পরীক্ষার আগে ফেস যাচাই", 12.0f, Ui.ON_INK, false));
        face.addView(ft, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView open = Ui.tv(this, "খোলো", 13.0f, -1, true);
        open.setBackground(Ui.box(this, 0x24FFFFFF, 0, 14.0f));
        open.setPadding(dp(14.0f), dp(10.0f), dp(14.0f), dp(10.0f));
        face.addView(open);
        face.setOnClickListener(new MainActivity$$ExternalSyntheticLambda54(this));
        Ui.press(face);
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(-1, -2);
        fl.topMargin = dp(16.0f);
        profile.addView(face, fl);
        Ui.add(pageBox, profile, 16);
        Ui.add(pageBox, menuRow("ic_batch", "আমার ব্যাচ", "ভর্তি হওয়া ও নতুন ব্যাচ", 0xFFE4E1FF, 0xFF4A3FD1, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMain("batches");
            }
        }), 10);
        Ui.add(pageBox, menuRow("ic_rank", "লিডারবোর্ড", "সেরাদের তালিকা দেখো", 0xFFF1E0FF, 0xFF7A2FBF, new MainActivity$$ExternalSyntheticLambda53(this)), 10);
        Ui.add(pageBox, menuRow("ic_result", "পরীক্ষার ফলাফল", "আগের সব পরীক্ষার ফল", 0xFFFFE1DC, 0xFFB4321F, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.examFilter = "all";
                showMain("exams");
            }
        }), 10);
        if (!FIXED_SERVER) {
            Ui.add(pageBox, menuRow("ic_more", "সার্ভারের ঠিকানা", Api.base, 0xFFD6F4F4, 0xFF0B6F73, new MainActivity$$ExternalSyntheticLambda56(this)), 10);
        }
        Ui.add(pageBox, Ui.btn(this, "লগআউট", Ui.RED_BG, Ui.RED, new MainActivity$$ExternalSyntheticLambda57(this)), 10);
        for (int i = 0; i < pageBox.getChildCount(); i++) {
            Ui.rise(pageBox.getChildAt(i), i * 50);
        }
        setPage(pageBox);
    }

    private void showPaper(int i) {
        busy("প্রশ্নপত্র লোড হচ্ছে…");
        Api.call("GET", "/online/exams/" + i + "/paper", null, actCb(new MainActivity$$ExternalSyntheticLambda30(this)));
    }

    private void showReceipt(String str) {
        LinearLayout pageBox = pageBox();
        pageBox.setPadding(dp(20.0f), dp(60.0f), dp(20.0f), dp(20.0f));
        TextView ok = Ui.tv(this, "✓", 44.0f, Ui.GREEN, true);
        ok.setGravity(Gravity.CENTER);
        ok.setBackground(Ui.box(this, Ui.GREEN_BG, 0, 46.0f));
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(dp(92.0f), dp(92.0f));
        ol.gravity = Gravity.CENTER_HORIZONTAL;
        ol.bottomMargin = dp(18.0f);
        pageBox.addView(ok, ol);
        TextView t = Ui.tv(this, "জমা হয়েছে", 24.0f, Ui.INK, true);
        t.setGravity(Gravity.CENTER);
        Ui.add(pageBox, t, 8);
        TextView m = Ui.tv(this, str, 15.0f, Ui.MUTED, false);
        m.setGravity(Gravity.CENTER);
        Ui.add(pageBox, m, 22);
        Ui.add(pageBox, Ui.primary(this, "পরীক্ষার তালিকায় ফিরে যাও", new MainActivity$$ExternalSyntheticLambda61(this)), 0);
        setScreen("জমা", scroll(pageBox), false, new MainActivity$$ExternalSyntheticLambda62(this), null);
    }

    private View optionRow(String letter, String text, int bg, int stroke, int badgeBg, int badgeFg) {
        LinearLayout r = Ui.hbox(this);
        r.setBackground(Ui.box(this, bg, stroke, 16.0f));
        r.setPadding(dp(10.0f), dp(8.0f), dp(12.0f), dp(8.0f));
        TextView b = Ui.tv(this, letter, 14.0f, badgeFg, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.box(this, badgeBg, 0, 11.0f));
        r.addView(b, new LinearLayout.LayoutParams(dp(30.0f), dp(30.0f)));
        TextView t = Ui.tv(this, text, 15.0f, Ui.INK, false);
        t.setPadding(dp(10.0f), 0, 0, 0);
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1.0f));
        return r;
    }

    private View statTile(String number, String label, int bg, int fg) {
        LinearLayout t = Ui.vbox(this);
        t.setBackground(Ui.box(this, bg, 0, 22.0f));
        t.setPadding(dp(14.0f), dp(14.0f), dp(12.0f), dp(12.0f));
        t.addView(Ui.tv(this, number, 26.0f, fg, true));
        t.addView(Ui.tv(this, label, 13.0f, fg, false));
        return t;
    }

    private void showResult(String title, JSONObject r, JSONArray list) {
        this.reviewFilter = "all";
        renderResult(title, r, list, !(r.has("marks") || r.has("score")));
    }

    private void renderResult(final String title, final JSONObject r, final JSONArray list, final boolean review) {
        LinearLayout box = pageBox();
        final boolean hasMarks = r.has("marks");
        boolean hasSummary = hasMarks || r.has("score");
        if (hasSummary) {
            Ui.add(box, segmented(new String[]{"ফলাফল", "উত্তর দেখো"}, review ? 1 : 0, new java.util.function.IntConsumer() {
                @Override
                public void accept(int i) {
                    if ((i == 1) != review) {
                        renderResult(title, r, list, i == 1);
                    }
                }
            }), 14);
        }
        if (!review) {
            LinearLayout hero = Ui.vbox(this);
            hero.setBackground(Ui.box(this, Ui.INK, 0, 30.0f));
            hero.setPadding(dp(20.0f), dp(20.0f), dp(20.0f), dp(20.0f));
            LinearLayout row = Ui.hbox(this);
            RingView ring = new RingView(this);
            double pct = r.has("score") ? r.optInt("score") : (r.optDouble("max_marks") > 0.0d ? r.optDouble("marks") / r.optDouble("max_marks") * 100.0d : 0.0d);
            String big = hasMarks ? bn(num(r.optDouble("marks"))) : bn(r.optInt("score")) + "%";
            String small = hasMarks ? "পূর্ণমান " + bn(num(r.optDouble("max_marks"))) : "স্কোর";
            ring.setData((float) (pct / 100.0d), big, small, 0x24FFFFFF, Ui.ACCENT, -1, Ui.ON_INK);
            row.addView(ring, new LinearLayout.LayoutParams(dp(124.0f), dp(124.0f)));
            LinearLayout right = Ui.vbox(this);
            right.setPadding(dp(16.0f), 0, 0, 0);
            right.addView(Ui.tv(this, pct >= 60.0d ? "ভালো করেছো!" : "চেষ্টা চালিয়ে যাও", 21.0f, -1, true));
            String line = hasMarks
                    ? "স্কোর " + bn(r.optInt("score")) + "%\nর\u200d্যাঙ্ক " + bn(r.optInt("rank")) + " / " + bn(r.optInt("participants"))
                    : "সঠিক " + bn(r.optInt("correct_count")) + " / " + bn(r.optInt("total_questions"));
            LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-1, -2);
            ll.topMargin = dp(6.0f);
            right.addView(Ui.tv(this, line, 14.0f, Ui.ON_INK, false), ll);
            row.addView(right, new LinearLayout.LayoutParams(0, -2, 1.0f));
            hero.addView(row, new LinearLayout.LayoutParams(-1, -2));
            if (!str(r, "message").isEmpty()) {
                LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, -2);
                mlp.topMargin = dp(14.0f);
                hero.addView(Ui.tv(this, r.optString("message"), 13.0f, Ui.ON_INK, false), mlp);
            }
            Ui.add(box, hero, 12);
            if (r.has("wrong_count")) {
                LinearLayout tiles = Ui.hbox(this);
                tiles.setGravity(Gravity.TOP);
                String[] nums = {bn(r.optInt("correct_count")), bn(r.optInt("wrong_count")), bn(r.optInt("skipped_count"))};
                String[] labels = {"সঠিক", "ভুল", "বাদ"};
                int[] bgs = {Ui.GREEN_BG, Ui.RED_BG, 0xFFE8E6F3};
                int[] fgs = {0xFF0B5C40, 0xFF8E2415, 0xFF3D3A66};
                for (int k = 0; k < 3; k++) {
                    LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1.0f);
                    if (k < 2) {
                        tl.rightMargin = dp(10.0f);
                    }
                    tiles.addView(statTile(nums[k], labels[k], bgs[k], fgs[k]), tl);
                }
                Ui.add(box, tiles, 12);
            }
            java.util.LinkedHashMap<String, int[]> byTopic = new java.util.LinkedHashMap<>();
            for (int i = 0; i < list.length(); i++) {
                JSONObject q = at(list, i);
                String tn = str(q, "topic_name");
                if (tn.isEmpty()) {
                    continue;
                }
                int[] c = byTopic.get(tn);
                if (c == null) {
                    c = new int[2];
                    byTopic.put(tn, c);
                }
                c[1]++;
                if (q.optBoolean("is_correct")) {
                    c[0]++;
                }
            }
            if (!byTopic.isEmpty()) {
                LinearLayout card = Ui.card(this);
                card.setBackground(Ui.box(this, Ui.WHITE, 0, 28.0f));
                card.setPadding(dp(18.0f), dp(18.0f), dp(18.0f), dp(8.0f));
                LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
                hl.bottomMargin = dp(12.0f);
                card.addView(Ui.tv(this, "বিষয় অনুযায়ী ফল", 17.0f, Ui.INK, true), hl);
                for (java.util.Map.Entry<String, int[]> en : byTopic.entrySet()) {
                    double acc = en.getValue()[1] == 0 ? 0 : (double) en.getValue()[0] / en.getValue()[1];
                    LinearLayout trow = Ui.hbox(this);
                    trow.addView(Ui.tv(this, en.getKey(), 13.0f, Ui.INK, false), new LinearLayout.LayoutParams(0, -2, 1.0f));
                    trow.addView(Ui.tv(this, bn(Math.round(acc * 100.0d)) + "%", 13.0f, Ui.INK, true));
                    Ui.add(card, trow, 4);
                    Ui.add(card, Ui.bar(this, acc, acc >= 0.7d ? Ui.GREEN : acc >= 0.5d ? Ui.ACCENT : Ui.RED), 12);
                }
                Ui.add(box, card, 14);
            }
            if (list.length() > 0) {
                Ui.add(box, Ui.primary(this, "উত্তর দেখো", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        renderResult(title, r, list, true);
                    }
                }), 10);
            }
            Ui.add(box, Ui.btn(this, "লিডারবোর্ড দেখো", Ui.WHITE, Ui.INK, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMain("rank");
                }
            }), 10);
        } else {
            LinearLayout chips = Ui.hbox(this);
            String[][] fs = {{"all", "সব"}, {"wrong", "ভুল"}, {"skip", "বাদ"}};
            for (final String[] f : fs) {
                boolean on = f[0].equals(this.reviewFilter);
                TextView c = Ui.tv(this, f[1], 14.0f, on ? -1 : Ui.INK, true);
                c.setGravity(Gravity.CENTER);
                c.setPadding(dp(18.0f), dp(11.0f), dp(18.0f), dp(11.0f));
                c.setBackground(Ui.box(this, on ? Ui.INK : Ui.WHITE, 0, 22.0f));
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MainActivity.this.reviewFilter = f[0];
                        renderResult(title, r, list, true);
                    }
                });
                Ui.press(c);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                lp.rightMargin = dp(8.0f);
                chips.addView(c, lp);
            }
            Ui.add(box, chips, 12);
            int shown = 0;
            for (int i = 0; i < list.length(); i++) {
                JSONObject q = at(list, i);
                JSONObject opts = q.optJSONObject("options");
                if (opts == null) {
                    opts = new JSONObject();
                }
                String mine = str(q, "your_answer");
                String right = str(q, "correct_answer");
                boolean skipped = mine.isEmpty();
                boolean correct = q.optBoolean("is_correct");
                if ("wrong".equals(this.reviewFilter) && (skipped || correct)) {
                    continue;
                }
                if ("skip".equals(this.reviewFilter) && !skipped) {
                    continue;
                }
                shown++;
                LinearLayout card = Ui.card(this);
                card.setBackground(Ui.box(this, Ui.WHITE, 0, 28.0f));
                LinearLayout head = Ui.hbox(this);
                head.addView(Ui.tv(this, "প্রশ্ন " + bn(i + 1), 13.0f, Ui.MUTED, true), new LinearLayout.LayoutParams(0, -2, 1.0f));
                if (skipped) {
                    head.addView(Ui.pill(this, "বাদ", 0xFFE8E6F3, 0xFF3D3A66));
                } else if (correct) {
                    head.addView(Ui.pill(this, "সঠিক", Ui.GREEN_BG, 0xFF0B5C40));
                } else {
                    head.addView(Ui.pill(this, "ভুল", Ui.RED_BG, 0xFF8E2415));
                }
                card.addView(head, new LinearLayout.LayoutParams(-1, -2));
                LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(-1, -2);
                qlp.topMargin = dp(8.0f);
                qlp.bottomMargin = dp(10.0f);
                card.addView(Ui.tv(this, q.optString("question_text"), 16.0f, Ui.INK, true), qlp);
                String[] keys = {"a", "b", "c", "d"};
                String[] letters = {"ক", "খ", "গ", "ঘ"};
                for (int k = 0; k < 4; k++) {
                    String key = keys[k];
                    int bg = Ui.WHITE;
                    int stroke = Ui.LINE;
                    int bb = Ui.TRACK;
                    int bf = Ui.INK;
                    if (key.equalsIgnoreCase(right)) {
                        bg = Ui.GREEN_BG;
                        stroke = Ui.GREEN;
                        bb = Ui.GREEN;
                        bf = -1;
                    } else if (key.equalsIgnoreCase(mine)) {
                        bg = Ui.RED_BG;
                        stroke = Ui.RED;
                        bb = Ui.RED;
                        bf = -1;
                    }
                    Ui.add(card, optionRow(letters[k], opts.optString(key, ""), bg, stroke, bb, bf), 6);
                }
                if (skipped) {
                    note(card, "উত্তর দাওনি। সঠিক উত্তর: " + right.toUpperCase(), Ui.AMBER, true);
                } else if (!correct) {
                    note(card, "সঠিক উত্তর: " + right.toUpperCase(), Ui.RED, true);
                }
                if (!str(q, "explanation").isEmpty()) {
                    TextView ex = Ui.tv(this, "ব্যাখ্যা: " + q.optString("explanation"), 13.0f, 0xFF3D3A66, false);
                    ex.setBackground(Ui.box(this, Ui.BG, 0, 14.0f));
                    ex.setPadding(dp(12.0f), dp(10.0f), dp(12.0f), dp(10.0f));
                    LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
                    elp.topMargin = dp(10.0f);
                    card.addView(ex, elp);
                }
                Ui.add(box, card, 10);
            }
            if (shown == 0) {
                Ui.add(box, Ui.tv(this, "এই ফিল্টারে কিছু নেই।", 15.0f, Ui.MUTED, false), 10);
            }
        }
        Ui.add(box, Ui.btn(this, "শেষ", Ui.SOFT, Ui.INDIGO, new MainActivity$$ExternalSyntheticLambda1(this)), 0);
        setScreen(title, scroll(box), false, new MainActivity$$ExternalSyntheticLambda2(this), null);
    }

    private void showServerSetup(boolean z) {
        LinearLayout pageBox = pageBox();
        pageBox.setPadding(dp(20.0f), dp(40.0f), dp(20.0f), dp(20.0f));
        Ui.add(pageBox, Ui.tv(this, "সার্ভারের ঠিকানা", 22.0f, 0xFF17153B, true), 8);
        Ui.add(pageBox, Ui.tv(this, "যে ওয়েবসাইটে পরীক্ষা সিস্টেম চালু আছে তার ঠিকানা দাও। যেমন: https://exam.example.com", 14.0f, 0xFF55527A, false), 16);
        EditText input = Ui.input(this, "https://your-site.com", 17);
        input.setText(Api.base == null ? "" : Api.base);
        Ui.add(pageBox, input, 14);
        Ui.add(pageBox, Ui.primary(this, "সংযোগ করো", new MainActivity$$ExternalSyntheticLambda26(this, input)), 10);
        setScreen("সার্ভার", scroll(pageBox), false, z ? new MainActivity$$ExternalSyntheticLambda27(this) : null, null);
    }

    private void startFace(String str, int i, Runnable runnable) {
        this.afterFace = runnable;
        Intent intent = new Intent(this, (Class<?>) FaceActivity.class);
        intent.putExtra("mode", str);
        intent.putExtra("exam_id", i);
        startActivityForResult(intent, 23);
    }

    private void startLive(int i) {
        busy("পরীক্ষা লোড হচ্ছে…");
        Api.call("POST", "/online/exams/" + i + "/start", null, new AnonymousClass4(i));
    }

    private void stopTimer() {
        if (this.timer != null) {
            this.timer.cancel();
            this.timer = null;
        }
    }

    private static String str(JSONObject jSONObject, String str) {
        return jSONObject.isNull(str) ? "" : jSONObject.optString(str, "");
    }

    private void toast(String str) {
        Toast.makeText(this, str, 1).show();
    }

    private void uploadOmr(Uri uri) {
        int i = this.pendingOmrExam;
        busy("ছবি আপলোড হচ্ছে…");
        Api.POOL.execute(new MainActivity$$ExternalSyntheticLambda29(this, uri, i));
    }

    private static String when(String str) {
        return str == null ? "" : str.replace('T', ' ');
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 21) {
            if (i2 == -1 && this.camUri != null) {
                showOmrPreview(this.camUri);
                return;
            } else {
                if (this.camUri != null) {
                    try {
                        getContentResolver().delete(this.camUri, null, null);
                        return;
                    } catch (Exception e) {
                        return;
                    }
                }
                return;
            }
        }
        if (i == 22) {
            if (i2 != -1 || intent == null || intent.getData() == null) {
                return;
            }
            showOmrPreview(intent.getData());
            return;
        }
        if (i == 23) {
            String stringExtra = intent == null ? "" : intent.getStringExtra("message");
            if (i2 != -1) {
                if (stringExtra == null || stringExtra.isEmpty()) {
                    return;
                }
                showError(stringExtra);
                return;
            }
            if (stringExtra != null && !stringExtra.isEmpty()) {
                toast(stringExtra);
            }
            if (this.afterFace != null) {
                this.afterFace.run();
            }
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        if (this.onBack != null) {
            this.onBack.run();
        } else {
            super.onBackPressed();
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.prefs = getSharedPreferences("exam", 0);
        Api.base = FIXED_SERVER ? "https://prottashaacademy.com" : this.prefs.getString("server", "https://prottashaacademy.com");
        Api.token = this.prefs.getString("token", null);
        Api.onUnauthorized = new MainActivity$$ExternalSyntheticLambda38(this);
        buildChrome();
        route();
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 24) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                showError("ক্যামেরার অনুমতি দাও, অথবা গ্যালারি থেকে ছবি নাও।");
            } else {
                launchCamera();
            }
        }
    }

    // ---------------------------------------------------------------- Home screen

    private void fetchSoft(String path, final java.util.function.Consumer<JSONObject> done) {
        final int tok = this.screenToken;
        Api.call("GET", path, null, new Api.Callback() {
            @Override
            public void onOk(JSONObject j) {
                if (tok == MainActivity.this.screenToken) {
                    done.accept(j);
                }
            }

            @Override
            public void onErr(String m, String c, int s) {
                if (tok == MainActivity.this.screenToken) {
                    done.accept(new JSONObject());
                }
            }
        });
    }

    private void loadHome(final Runnable retry) {
        final int tok = this.screenToken;
        Api.call("GET", "/online/exams", null, pageCb(new Ok() {
            @Override
            public void run(final JSONObject ex) throws Exception {
                final JSONObject[] res = new JSONObject[3];
                final int[] left = {3};
                String[] paths = {"/exam/performance", "/omr/batches", "/exam/leaderboard"};
                for (int k = 0; k < 3; k++) {
                    final int idx = k;
                    fetchSoft(paths[k], new java.util.function.Consumer<JSONObject>() {
                        @Override
                        public void accept(JSONObject j) {
                            res[idx] = j;
                            left[0]--;
                            if (left[0] == 0 && tok == MainActivity.this.screenToken) {
                                try {
                                    buildHome(ex, res[0], res[1], res[2]);
                                } catch (Exception e) {
                                    errorPage("দেখাতে সমস্যা হয়েছে: " + e.getMessage(), retry);
                                }
                            }
                        }
                    });
                }
            }
        }, retry));
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.tv(this, s, 19.0f, Ui.INK, true);
        t.setPadding(0, dp(10.0f), 0, dp(10.0f));
        return t;
    }

    private View sectionRow(String title, String link, View.OnClickListener l) {
        LinearLayout r = Ui.hbox(this);
        r.setPadding(0, dp(10.0f), 0, dp(6.0f));
        r.addView(Ui.tv(this, title, 19.0f, Ui.INK, true), new LinearLayout.LayoutParams(0, -2, 1.0f));
        if (link != null) {
            TextView t = Ui.tv(this, link, 13.0f, Ui.INDIGO, true);
            t.setPadding(dp(8.0f), dp(8.0f), dp(4.0f), dp(8.0f));
            t.setOnClickListener(l);
            r.addView(t);
        }
        return r;
    }

    private View iconTile(String icon, int bg, int fg, int boxDp, int iconDp, float radius) {
        FrameLayout ic = new FrameLayout(this);
        ic.setBackground(Ui.box(this, bg, 0, radius));
        ImageView iv = new ImageView(this);
        iv.setImageResource(drawableId(icon));
        iv.setColorFilter(fg);
        ic.addView(iv, new FrameLayout.LayoutParams(dp((float) iconDp), dp((float) iconDp), Gravity.CENTER));
        ic.setLayoutParams(new LinearLayout.LayoutParams(dp((float) boxDp), dp((float) boxDp)));
        return ic;
    }

    private View tile(String label, String icon, int bg, int fg, View.OnClickListener l) {
        LinearLayout t = Ui.vbox(this);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setBackground(Ui.box(this, Ui.WHITE, 0, 20.0f));
        t.setPadding(dp(2.0f), dp(12.0f), dp(2.0f), dp(10.0f));
        t.addView(iconTile(icon, bg, fg, 44, 22, 14.0f));
        TextView tx = Ui.tv(this, label, 12.0f, Ui.INK, true);
        tx.setGravity(Gravity.CENTER);
        tx.setPadding(dp(2.0f), dp(8.0f), dp(2.0f), 0);
        t.addView(tx, new LinearLayout.LayoutParams(-1, -2));
        t.setOnClickListener(l);
        Ui.press(t);
        return t;
    }

    private View menuRow(String icon, String title, String sub, int bg, int fg, View.OnClickListener l) {
        LinearLayout r = Ui.hbox(this);
        r.setBackground(Ui.box(this, Ui.WHITE, 0, 20.0f));
        r.setPadding(dp(14.0f), dp(12.0f), dp(14.0f), dp(12.0f));
        r.addView(iconTile(icon, bg, fg, 42, 22, 13.0f));
        LinearLayout tx = Ui.vbox(this);
        tx.setPadding(dp(12.0f), 0, dp(8.0f), 0);
        tx.addView(Ui.tv(this, title, 15.0f, Ui.INK, true));
        tx.addView(Ui.tv(this, sub, 12.0f, Ui.MUTED, false));
        r.addView(tx, new LinearLayout.LayoutParams(0, -2, 1.0f));
        r.addView(Ui.tv(this, "›", 22.0f, Ui.MUTED, true));
        r.setOnClickListener(l);
        Ui.press(r);
        return r;
    }

    private void heroCta(LinearLayout hero, View cta, LinearLayout.LayoutParams lp) {
        LinearLayout row = Ui.hbox(this);
        row.addView(cta, new LinearLayout.LayoutParams(0, -2, 1.0f));
        FrameLayout f = new FrameLayout(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0);
        g.setCornerRadius(dp(18.0f));
        g.setStroke(dp(1.5f), 0x4DFFFFFF);
        f.setBackground(g);
        ImageView iv = new ImageView(this);
        iv.setImageResource(drawableId("ic_face"));
        iv.setColorFilter(-1);
        f.addView(iv, new FrameLayout.LayoutParams(dp(24.0f), dp(24.0f), Gravity.CENTER));
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFace();
            }
        });
        Ui.press(f);
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(dp(54.0f), dp(54.0f));
        fl.leftMargin = dp(10.0f);
        row.addView(f, fl);
        hero.addView(row, lp);
    }

    private TextView digitBox(LinearLayout row, String label, boolean last) {
        LinearLayout b = Ui.vbox(this);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        b.setBackground(Ui.box(this, 0x17FFFFFF, 0, 18.0f));
        b.setPadding(0, dp(10.0f), 0, dp(8.0f));
        TextView n = Ui.tv(this, "০০", 36.0f, -1, true);
        n.setGravity(Gravity.CENTER);
        b.addView(n);
        TextView l = Ui.tv(this, label, 12.0f, Ui.ON_INK, false);
        l.setGravity(Gravity.CENTER);
        b.addView(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        if (!last) {
            lp.rightMargin = dp(10.0f);
        }
        row.addView(b, lp);
        return n;
    }

    private String two(int v) {
        return bn(v < 10 ? "0" + v : String.valueOf(v));
    }

    private String examWhen(JSONObject e) {
        String st = e.optString("state");
        if ("in_progress".equals(st)) {
            return "চলছে, বাকি " + clock(e.optInt("remaining_seconds"));
        }
        if ("upcoming".equals(st) && !str(e, "start_time").isEmpty()) {
            return "শুরু: " + when(e.optString("start_time"));
        }
        if ("done".equals(st) && e.optJSONObject("result") != null) {
            return "নম্বর " + bn(num(e.optJSONObject("result").optDouble("marks"))) + " / " + bn(num(e.optJSONObject("result").optDouble("max_marks")));
        }
        if (!str(e, "end_time").isEmpty()) {
            return "শেষ সময়: " + when(e.optString("end_time"));
        }
        return bn(e.optInt("questions")) + " টি প্রশ্ন";
    }

    private View buildPodium(JSONArray list, int uid) {
        LinearLayout pod = Ui.card(this);
        pod.setPadding(dp(16.0f), dp(22.0f), dp(16.0f), 0);
        pod.setClipToOutline(true);
        LinearLayout cols = new LinearLayout(this);
        cols.setOrientation(LinearLayout.HORIZONTAL);
        cols.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        int[] order = {1, 0, 2};
        int[] heights = {132, 100, 76};
        int[] colors = {0xFFFFB020, 0xFFCFCBF5, 0xFFF7C9AE};
        for (int o = 0; o < 3; o++) {
            int rank = order[o];
            if (rank >= list.length()) {
                continue;
            }
            JSONObject p = at(list, rank);
            boolean mine = p.optInt("student_id") == uid;
            String nm = p.optString("name");
            LinearLayout col = Ui.vbox(this);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView av = Ui.tv(this, nm.isEmpty() ? "?" : nm.substring(0, nm.offsetByCodePoints(0, 1)), 17.0f, mine ? Ui.ACCENT : Ui.INK, true);
            av.setGravity(Gravity.CENTER);
            av.setBackground(Ui.box(this, mine ? Ui.INK : Ui.BG, 0, 16.0f));
            col.addView(av, new LinearLayout.LayoutParams(dp(46.0f), dp(46.0f)));
            TextView nt = Ui.tv(this, mine ? "তুমি" : nm, 13.0f, Ui.INK, true);
            nt.setSingleLine(true);
            nt.setEllipsize(android.text.TextUtils.TruncateAt.END);
            nt.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
            nlp.topMargin = dp(4.0f);
            col.addView(nt, nlp);
            col.addView(Ui.tv(this, bn(num(p.optDouble("avg_score"))) + "%", 13.0f, Ui.MUTED, false));
            TextView bar = Ui.tv(this, bn(rank + 1), 28.0f, Ui.INK, true);
            bar.setGravity(Gravity.CENTER_HORIZONTAL);
            bar.setPadding(0, dp(12.0f), 0, 0);
            GradientDrawable g = new GradientDrawable();
            g.setColor(colors[rank]);
            float r = dp(16.0f);
            g.setCornerRadii(new float[]{r, r, r, r, 0f, 0f, 0f, 0f});
            bar.setBackground(g);
            int hpx = dp((float) heights[rank]);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, hpx);
            blp.topMargin = dp(6.0f);
            col.addView(bar, blp);
            bar.setPivotY((float) hpx);
            bar.setScaleY(0f);
            bar.animate().scaleY(1f).setStartDelay(300L).setDuration(800L).setInterpolator(new DecelerateInterpolator()).start();
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            if (o < 2) {
                clp.rightMargin = dp(10.0f);
            }
            cols.addView(col, clp);
        }
        pod.addView(cols, new LinearLayout.LayoutParams(-1, -2));
        return pod;
    }

    private void buildHome(JSONObject ex, JSONObject perf, JSONObject batchesJson, JSONObject lbJson) throws Exception {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(dp(18.0f), dp(26.0f), dp(18.0f), dp(24.0f));
        int uid = this.prefs.getInt("uid", -1);

        // greeting
        LinearLayout top = Ui.hbox(this);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        top.addView(logo, new LinearLayout.LayoutParams(dp(50.0f), dp(50.0f)));
        LinearLayout who = Ui.vbox(this);
        who.setPadding(dp(12.0f), 0, 0, 0);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String hello = hour < 5 ? "শুভ রাত্রি" : hour < 12 ? "শুভ সকাল" : hour < 16 ? "শুভ দুপুর" : hour < 19 ? "শুভ বিকাল" : "শুভ সন্ধ্যা";
        who.addView(Ui.tv(this, hello, 13.0f, Ui.MUTED, false));
        String nm = this.prefs.getString("name", "");
        who.addView(Ui.tv(this, nm.isEmpty() ? "শিক্ষার্থী" : nm, 21.0f, Ui.INK, true));
        top.addView(who, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView ref = Ui.tv(this, "↻", 20.0f, Ui.INK, true);
        ref.setGravity(Gravity.CENTER);
        ref.setBackground(Ui.box(this, Ui.WHITE, 0, 16.0f));
        ref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMain("home");
            }
        });
        Ui.press(ref);
        top.addView(ref, new LinearLayout.LayoutParams(dp(46.0f), dp(46.0f)));
        Ui.add(box, top, 18);

        // featured exam
        JSONArray exams = arr(ex, "exams");
        JSONObject feat = null;
        for (int pass = 0; pass < 3 && feat == null; pass++) {
            String want = pass == 0 ? "in_progress" : pass == 1 ? "open" : "upcoming";
            for (int i = 0; i < exams.length(); i++) {
                JSONObject e = at(exams, i);
                if (want.equals(e.optString("state"))) {
                    feat = e;
                    break;
                }
            }
        }
        LinearLayout hero = Ui.vbox(this);
        hero.setBackground(Ui.box(this, Ui.INK, 0, 30.0f));
        hero.setPadding(dp(20.0f), dp(20.0f), dp(20.0f), dp(20.0f));
        if (feat == null) {
            hero.addView(Ui.pill(this, "পরীক্ষা", 0x29FFB020, 0xFFFFC95C), new LinearLayout.LayoutParams(-2, -2));
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
            tl.topMargin = dp(14.0f);
            hero.addView(Ui.tv(this, "এখন কোনো পরীক্ষা নেই", 22.0f, -1, true), tl);
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
            sl.topMargin = dp(6.0f);
            sl.bottomMargin = dp(16.0f);
            hero.addView(Ui.tv(this, "ব্যাচে যোগ দিলে তোমার পরীক্ষা এখানে দেখা যাবে।", 14.0f, Ui.ON_INK, false), sl);
            hero.addView(Ui.btn(this, "ব্যাচ দেখো", Ui.ACCENT, Ui.INK, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMain("batches");
                }
            }), new LinearLayout.LayoutParams(-1, -2));
        } else {
            final int id = feat.optInt("id");
            String st = feat.optString("state");
            String mode = feat.optString("mode", "online");
            String choice = str(feat, "choice");
            LinearLayout chipRow = Ui.hbox(this);
            String chip = "in_progress".equals(st) ? "● পরীক্ষা চলছে" : "open".equals(st) ? "● লাইভ পরীক্ষা" : "আসন্ন পরীক্ষা";
            chipRow.addView(Ui.pill(this, chip, 0x29FFB020, 0xFFFFC95C), new LinearLayout.LayoutParams(0, -2, 1.0f));
            LinearLayout.LayoutParams cll = new LinearLayout.LayoutParams(0, -2, 1.0f);
            cll.leftMargin = 0;
            TextView faceNote = Ui.tv(this, "📷 ফেস যাচাই লাগতে পারে", 12.0f, Ui.ON_INK, false);
            faceNote.setGravity(Gravity.END);
            chipRow.addView(faceNote, new LinearLayout.LayoutParams(0, -2, 1.4f));
            hero.addView(chipRow, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
            tl.topMargin = dp(14.0f);
            hero.addView(Ui.tv(this, feat.optString("title"), 24.0f, -1, true), tl);
            String meta = bn(feat.optInt("questions")) + "টি প্রশ্ন, " + bn(Math.max(1, feat.optInt("time_limit_seconds") / 60)) + " মিনিট";
            if (!str(feat, "batch_name").isEmpty()) {
                meta = meta + "\n" + feat.optString("batch_name");
            }
            LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
            ml.topMargin = dp(6.0f);
            hero.addView(Ui.tv(this, meta, 13.0f, Ui.ON_INK, false), ml);
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
            bl.topMargin = dp(18.0f);
            if ("in_progress".equals(st)) {
                hero.addView(Ui.tv(this, "পরীক্ষা শেষ হতে বাকি", 13.0f, Ui.ON_INK, false), bl);
                LinearLayout digits = Ui.hbox(this);
                digits.setGravity(Gravity.TOP);
                final TextView hh = digitBox(digits, "ঘণ্টা", false);
                final TextView mm = digitBox(digits, "মিনিট", false);
                final TextView ss = digitBox(digits, "সেকেন্ড", true);
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, -2);
                dl.topMargin = dp(8.0f);
                hero.addView(digits, dl);
                stopTimer();
                final int secs = Math.max(1, feat.optInt("remaining_seconds"));
                hh.setText(two(secs / 3600));
                mm.setText(two((secs % 3600) / 60));
                ss.setText(two(secs % 60));
                this.timer = new CountDownTimer(secs * 1000L, 1000L) {
                    @Override
                    public void onTick(long ms) {
                        int s = (int) (ms / 1000L);
                        hh.setText(two(s / 3600));
                        mm.setText(two((s % 3600) / 60));
                        ss.setText(two(s % 60));
                    }

                    @Override
                    public void onFinish() {
                        hh.setText(two(0));
                        mm.setText(two(0));
                        ss.setText(two(0));
                    }
                };
                this.timer.start();
            } else if ("upcoming".equals(st)) {
                String when = str(feat, "start_time").isEmpty() ? "শিগগিরই শুরু হবে" : "শুরু: " + when(feat.optString("start_time"));
                hero.addView(Ui.tv(this, when, 15.0f, 0xFFFFC95C, true), bl);
            }
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
            cl.topMargin = dp(16.0f);
            if ("in_progress".equals(st)) {
                heroCta(hero, Ui.btn(this, "চালিয়ে যাও", Ui.ACCENT, Ui.INK, new MainActivity$$ExternalSyntheticLambda48(this, id)), cl);
            } else if ("open".equals(st) && ("online".equals(mode) || "online".equals(choice))) {
                heroCta(hero, Ui.btn(this, "পরীক্ষায় প্রবেশ করো", Ui.ACCENT, Ui.INK, new MainActivity$$ExternalSyntheticLambda45(this, id)), cl);
            } else {
                heroCta(hero, Ui.btn(this, "বিস্তারিত দেখো", Ui.ACCENT, Ui.INK, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showMain("exams");
                    }
                }), cl);
            }
        }
        Ui.add(box, hero, 8);

        // quick actions (4 x 2)
        box.addView(sectionTitle("দ্রুত শুরু করো"));
        Object[][] quick = {
                {"লাইভ পরীক্ষা", "ic_live", 0xFFE4E1FF, 0xFF4A3FD1, "live"},
                {"প্র্যাকটিস", "ic_practice", 0xFFD9F5EA, 0xFF0B6B4B, "practice"},
                {"অ্যাডাপটিভ", "ic_adaptive", 0xFFFFEFC9, 0xFF8A5A00, "adaptive"},
                {"OMR শিট", "ic_omr", 0xFFDDEBFF, 0xFF1F5FBF, "omr"},
                {"ফলাফল", "ic_result", 0xFFFFE1DC, 0xFFB4321F, "result"},
                {"লিডারবোর্ড", "ic_rank", 0xFFF1E0FF, 0xFF7A2FBF, "rank"},
                {"ফেস যাচাই", "ic_face", 0xFFD6F4F4, 0xFF0B6F73, "face"},
                {"পেমেন্ট", "ic_pay", 0xFFFFE6F0, 0xFFA6245F, "batches"}};
        LinearLayout row = null;
        for (int i = 0; i < quick.length; i++) {
            if (i % 4 == 0) {
                row = Ui.hbox(this);
                row.setGravity(Gravity.TOP);
                Ui.add(box, row, 10);
            }
            final String go = (String) quick[i][4];
            View tile = tile((String) quick[i][0], (String) quick[i][1], (Integer) quick[i][2], (Integer) quick[i][3], new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if ("adaptive".equals(go)) {
                        lambda$loadPractice$39(v);
                    } else if ("face".equals(go)) {
                        showFace();
                    } else if ("omr".equals(go)) {
                        MainActivity.this.examFilter = "omr";
                        showMain("exams");
                    } else if ("live".equals(go)) {
                        MainActivity.this.examFilter = "online";
                        showMain("exams");
                    } else if ("result".equals(go)) {
                        MainActivity.this.examFilter = "all";
                        showMain("exams");
                    } else {
                        showMain(go);
                    }
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            lp.rightMargin = i % 4 == 3 ? 0 : dp(10.0f);
            row.addView(tile, lp);
        }

        // progress
        JSONArray topics = arr(perf, "topic_performance");
        int completed = perf.optInt("exams_completed");
        int needed = perf.optInt("exams_needed");
        boolean ready = perf.optBoolean("adaptive_ready");
        double sum = 0;
        for (int i = 0; i < topics.length(); i++) {
            sum += at(topics, i).optDouble("accuracy");
        }
        double avg = topics.length() == 0 ? 0 : sum / topics.length();
        box.addView(sectionRow("তোমার অগ্রগতি", "বিস্তারিত", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMain("practice");
            }
        }));
        LinearLayout card = Ui.card(this);
        card.setBackground(Ui.box(this, Ui.WHITE, 0, 28.0f));
        card.setPadding(dp(18.0f), dp(18.0f), dp(18.0f), dp(18.0f));
        LinearLayout prow = Ui.hbox(this);
        RingView ring = new RingView(this);
        ring.setData((float) avg, bn(Math.round(avg * 100.0d)) + "%", "গড় স্কোর", Ui.TRACK, Ui.INDIGO, Ui.INK, Ui.MUTED);
        prow.addView(ring, new LinearLayout.LayoutParams(dp(112.0f), dp(112.0f)));
        LinearLayout right = Ui.vbox(this);
        right.setPadding(dp(18.0f), 0, 0, 0);
        String[][] stats = {{"পরীক্ষা সম্পন্ন", bn(completed)}, {"পরীক্ষা বাকি (Adaptive)", ready ? "প্রস্তুত" : bn(needed)}, {"টপিক", bn(topics.length())}};
        for (String[] sRow : stats) {
            LinearLayout line = Ui.hbox(this);
            line.addView(Ui.tv(this, sRow[0], 13.0f, Ui.MUTED, false), new LinearLayout.LayoutParams(0, -2, 1.0f));
            line.addView(Ui.tv(this, sRow[1], 19.0f, Ui.INK, true));
            Ui.add(right, line, 8);
        }
        prow.addView(right, new LinearLayout.LayoutParams(0, -2, 1.0f));
        card.addView(prow);
        LinearLayout strip = Ui.vbox(this);
        strip.setBackground(Ui.box(this, Ui.BG, 0, 20.0f));
        strip.setPadding(dp(14.0f), dp(14.0f), dp(14.0f), dp(14.0f));
        LinearLayout srow = Ui.hbox(this);
        srow.addView(iconTile("ic_adaptive", Ui.AMBER_BG, 0xFF8A5A00, 36, 20, 12.0f));
        TextView stx = Ui.tv(this, ready ? "অ্যাডাপটিভ এক্সাম প্রস্তুত, এখনই শুরু করো" : "অ্যাডাপটিভ এক্সাম আনলক করতে আরও " + bn(needed) + "টি পরীক্ষা দাও", 13.0f, Ui.INK, true);
        stx.setPadding(dp(10.0f), 0, 0, 0);
        srow.addView(stx, new LinearLayout.LayoutParams(0, -2, 1.0f));
        strip.addView(srow);
        double total = completed + (ready ? 0 : needed);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, -2);
        barLp.topMargin = dp(10.0f);
        strip.addView(Ui.bar(this, ready ? 1.0d : (total == 0 ? 0 : completed / total), ready ? Ui.GREEN : Ui.INDIGO), barLp);
        LinearLayout.LayoutParams sll = new LinearLayout.LayoutParams(-1, -2);
        sll.topMargin = dp(16.0f);
        card.addView(strip, sll);
        if (topics.length() > 0) {
            LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
            hl.topMargin = dp(18.0f);
            hl.bottomMargin = dp(10.0f);
            card.addView(Ui.tv(this, "যে বিষয়ে আরও অনুশীলন দরকার", 15.0f, Ui.INK, true), hl);
            boolean[] used = new boolean[topics.length()];
            int shownTopics = Math.min(3, topics.length());
            for (int n = 0; n < shownTopics; n++) {
                int best = -1;
                for (int i = 0; i < topics.length(); i++) {
                    if (!used[i] && (best < 0 || at(topics, i).optDouble("accuracy") < at(topics, best).optDouble("accuracy"))) {
                        best = i;
                    }
                }
                used[best] = true;
                JSONObject tp = at(topics, best);
                String level = tp.optString("level");
                int col = "strong".equals(level) ? Ui.GREEN : "weak".equals(level) ? Ui.RED : Ui.ACCENT;
                LinearLayout line = Ui.hbox(this);
                line.addView(Ui.tv(this, tp.optString("topic_name"), 13.0f, Ui.INK, false), new LinearLayout.LayoutParams(0, -2, 1.0f));
                line.addView(Ui.tv(this, bn(Math.round(tp.optDouble("accuracy") * 100.0d)) + "%", 13.0f, Ui.INK, true));
                Ui.add(card, line, 4);
                Ui.add(card, Ui.bar(this, tp.optDouble("accuracy"), col), 12);
            }
        } else {
            LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-1, -2);
            nl.topMargin = dp(14.0f);
            card.addView(Ui.tv(this, "এখনও কোনো ফলাফল নেই। পরীক্ষা দিলে এখানে দেখা যাবে।", 13.0f, Ui.MUTED, false), nl);
        }
        Ui.add(box, card, 8);

        // batches carousel
        JSONArray batches = arr(batchesJson, "batches");
        if (batches.length() > 0) {
            box.addView(sectionRow("ব্যাচ", "সব ব্যাচ", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMain("batches");
                }
            }));
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            hs.setClipToPadding(false);
            LinearLayout strip2 = new LinearLayout(this);
            strip2.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = 0; i < batches.length() && i < 6; i++) {
                final JSONObject b = at(batches, i);
                boolean active = "active".equals(b.optString("state"));
                double price = b.optDouble("price");
                LinearLayout bc = Ui.vbox(this);
                bc.setBackground(Ui.box(this, active ? Ui.INK : Ui.WHITE, 0, 26.0f));
                bc.setPadding(dp(16.0f), dp(16.0f), dp(16.0f), dp(16.0f));
                bc.addView(Ui.pill(this, active ? "চালু আছে" : "pending".equals(b.optString("state")) ? "অপেক্ষায়" : "ভর্তি চলছে", active ? 0x24FFFFFF : Ui.AMBER_BG, active ? -1 : 0xFF7A4E00), new LinearLayout.LayoutParams(-2, -2));
                TextView bt = Ui.tv(this, b.optString("name"), 18.0f, active ? -1 : Ui.INK, true);
                bt.setMinLines(2);
                bt.setMaxLines(2);
                bt.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams btl = new LinearLayout.LayoutParams(-1, -2);
                btl.topMargin = dp(10.0f);
                bc.addView(bt, btl);
                String sub = active ? bn(b.optInt("exams")) + " টি পরীক্ষা" : (price > 0.0d ? "৳ " + bn(num(price)) : "ফ্রি");
                LinearLayout.LayoutParams sbl = new LinearLayout.LayoutParams(-1, -2);
                sbl.topMargin = dp(8.0f);
                sbl.bottomMargin = dp(12.0f);
                bc.addView(Ui.tv(this, sub, active ? 13.0f : 22.0f, active ? Ui.ON_INK : Ui.INK, !active), sbl);
                if (active) {
                    bc.addView(Ui.btn(this, "পরীক্ষাগুলো দেখো", Ui.WHITE, Ui.INK, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showMain("exams");
                        }
                    }), new LinearLayout.LayoutParams(-1, -2));
                } else {
                    bc.addView(Ui.btn(this, "ভর্তি হও", Ui.INK, -1, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showBatchDetail(b);
                        }
                    }), new LinearLayout.LayoutParams(-1, -2));
                }
                LinearLayout.LayoutParams cl2 = new LinearLayout.LayoutParams(dp(252.0f), -2);
                cl2.rightMargin = dp(12.0f);
                strip2.addView(bc, cl2);
            }
            hs.addView(strip2);
            Ui.add(box, hs, 8);
        }

        // exams
        int extra = 0;
        for (int i = 0; i < exams.length() && extra < 4; i++) {
            JSONObject e = at(exams, i);
            if (extra == 0) {
                box.addView(sectionRow("পরীক্ষা", "সব দেখো", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showMain("exams");
                    }
                }));
            }
            String es = e.optString("state");
            boolean omrLook = "omr".equals(e.optString("mode")) || "omr".equals(es);
            LinearLayout er = Ui.hbox(this);
            er.setBackground(Ui.box(this, Ui.WHITE, 0, 22.0f));
            er.setPadding(dp(12.0f), dp(12.0f), dp(12.0f), dp(12.0f));
            er.addView(iconTile(omrLook ? "ic_omr" : "ic_live", omrLook ? 0xFFDDEBFF : 0xFFE4E1FF, omrLook ? 0xFF1F5FBF : 0xFF4A3FD1, 44, 22, 14.0f));
            LinearLayout et = Ui.vbox(this);
            et.setPadding(dp(12.0f), 0, dp(8.0f), 0);
            et.addView(Ui.tv(this, e.optString("title"), 15.0f, Ui.INK, true));
            et.addView(Ui.tv(this, examWhen(e), 12.0f, Ui.MUTED, false));
            er.addView(et, new LinearLayout.LayoutParams(0, -2, 1.0f));
            er.addView(Ui.pill(this, stateText(es), stateBg(es), stateFg(es)));
            er.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMain("exams");
                }
            });
            Ui.press(er);
            Ui.add(box, er, 10);
            extra++;
        }

        // leaderboard
        JSONArray lb = arr(lbJson, "leaderboard");
        if (lb.length() > 0) {
            box.addView(sectionRow("লিডারবোর্ড", "পুরো তালিকা", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMain("rank");
                }
            }));
            Ui.add(box, buildPodium(lb, uid), 8);
        }

        for (int i = 0; i < box.getChildCount(); i++) {
            Ui.rise(box.getChildAt(i), Math.min(i, 8) * 60);
        }
        setPage(box);
    }
}
